// unopinionated extensable tslint configuration
// loads rules for extending packages, but does not enable any
module.exports = {
    rulesDirectory: "./dist/rules",
};
