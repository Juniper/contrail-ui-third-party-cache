# Installation
> `npm install --save @types/d3-shape`

# Summary
This package contains type definitions for D3JS d3-shape module ( https://github.com/d3/d3-shape/ ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-shape

Additional Details
 * Last updated: Wed, 13 Feb 2019 18:07:34 GMT
 * Dependencies: @types/d3-path
 * Global values: none

# Credits
These definitions were written by Tom Wanzek <https://github.com/tomwanzek>, Alex Ford <https://github.com/gustavderdrache>, Boris Yankov <https://github.com/borisyankov>, denisname <https://github.com/denisname>.
