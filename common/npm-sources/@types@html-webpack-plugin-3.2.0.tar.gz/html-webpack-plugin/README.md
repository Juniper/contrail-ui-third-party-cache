# Installation
> `npm install --save @types/html-webpack-plugin`

# Summary
This package contains type definitions for html-webpack-plugin (https://github.com/jantimon/html-webpack-plugin).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/html-webpack-plugin

Additional Details
 * Last updated: Mon, 23 Jul 2018 23:44:11 GMT
 * Dependencies: webpack, tapable, html-minifier
 * Global values: none

# Credits
These definitions were written by Simon Hartcher <https://github.com/deevus>, Benjamin Lim <https://github.com/bumbleblym>, Tomek Łaziuk <https://github.com/tlaziuk>.
