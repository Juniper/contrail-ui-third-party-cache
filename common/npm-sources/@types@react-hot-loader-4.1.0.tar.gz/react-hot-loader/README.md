# Installation
> `npm install --save @types/react-hot-loader`

# Summary
This package contains type definitions for react-hot-loader (https://github.com/gaearon/react-hot-loader).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-hot-loader

Additional Details
 * Last updated: Thu, 26 Apr 2018 22:15:53 GMT
 * Dependencies: react, node
 * Global values: none

# Credits
These definitions were written by Jacek Jagiello <https://github.com/jacekjagiello>, MartynasZilinskas <https://github.com/MartynasZilinskas>, Dovydas Navickas <https://github.com/DovydasNavickas>.
