# Installation
> `npm install --save @types/react-json-tree`

# Summary
This package contains type definitions for react-json-tree (https://github.com/alexkuz/react-json-tree/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-json-tree

Additional Details
 * Last updated: Mon, 28 Aug 2017 15:52:08 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Grant Nestor <https://github.com/gnestor>.
