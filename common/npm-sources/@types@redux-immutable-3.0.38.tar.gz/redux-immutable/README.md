# Installation
> `npm install --save @types/redux-immutable`

# Summary
This package contains type definitions for redux-immutable (https://github.com/gajus/redux-immutable).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/redux-immutable

Additional Details
 * Last updated: Wed, 25 Oct 2017 18:38:04 GMT
 * Dependencies: redux, immutable
 * Global values: none

# Credits
These definitions were written by Pedro Pereira <https://github.com/oizie>, Sebastian Sebald <https://github.com/sebald>, Gavin Gregory <https://github.com/gavingregory>.
