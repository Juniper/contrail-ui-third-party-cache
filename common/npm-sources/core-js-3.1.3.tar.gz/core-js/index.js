require('./es');
require('./proposals');
require('./web');

module.exports = require('./internals/path');
