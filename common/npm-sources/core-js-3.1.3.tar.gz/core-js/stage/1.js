require('../proposals/array-last');
require('../proposals/collection-methods');
require('../proposals/collection-of-from');
require('../proposals/math-extensions');
require('../proposals/math-signbit');
require('../proposals/number-from-string');
require('../proposals/observable');
require('../proposals/pattern-matching');
require('../proposals/promise-try');
require('../proposals/keys-composition');
require('../proposals/seeded-random');
require('../proposals/string-code-points');
require('../proposals/using-statement');
require('../proposals/promise-any');

module.exports = require('./2');
