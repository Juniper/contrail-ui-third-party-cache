require('../proposals/string-match-all');

module.exports = require('../internals/path');
