require('../proposals/global-this');
require('../proposals/promise-all-settled');

module.exports = require('./4');
