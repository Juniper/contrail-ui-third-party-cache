require('../proposals/reflect-metadata');

module.exports = require('./0');
