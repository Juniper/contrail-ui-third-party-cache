require('../proposals/set-methods');
require('../proposals/string-replace-all');

module.exports = require('./3');
