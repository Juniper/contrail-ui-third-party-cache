module.exports = require('../../es/weak-set');
