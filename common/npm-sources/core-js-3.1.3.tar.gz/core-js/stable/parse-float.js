module.exports = require('../es/parse-float');
