module.exports = require('../../es/object/set-prototype-of');
