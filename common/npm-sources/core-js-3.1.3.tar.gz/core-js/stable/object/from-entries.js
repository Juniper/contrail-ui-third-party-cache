module.exports = require('../../es/object/from-entries');
