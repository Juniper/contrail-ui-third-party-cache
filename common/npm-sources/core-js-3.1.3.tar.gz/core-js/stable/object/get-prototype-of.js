module.exports = require('../../es/object/get-prototype-of');
