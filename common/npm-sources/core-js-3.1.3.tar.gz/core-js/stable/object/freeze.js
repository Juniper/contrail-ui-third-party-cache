module.exports = require('../../es/object/freeze');
