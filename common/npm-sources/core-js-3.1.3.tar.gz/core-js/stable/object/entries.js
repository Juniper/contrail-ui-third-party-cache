module.exports = require('../../es/object/entries');
