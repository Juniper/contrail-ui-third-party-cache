module.exports = require('../../es/object/define-property');
