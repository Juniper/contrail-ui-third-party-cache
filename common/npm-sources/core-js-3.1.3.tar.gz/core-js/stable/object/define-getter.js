module.exports = require('../../es/object/define-getter');
