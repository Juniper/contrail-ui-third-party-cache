module.exports = require('../../es/object/to-string');
