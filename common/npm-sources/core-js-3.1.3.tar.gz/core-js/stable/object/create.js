module.exports = require('../../es/object/create');
