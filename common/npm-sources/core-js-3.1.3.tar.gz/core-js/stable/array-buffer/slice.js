module.exports = require('../../es/array-buffer/slice');
