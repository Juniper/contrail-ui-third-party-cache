require('../modules/web.timers');

module.exports = require('../internals/path').setInterval;
