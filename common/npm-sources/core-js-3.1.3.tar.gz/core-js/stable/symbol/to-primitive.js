module.exports = require('../../es/symbol/to-primitive');
