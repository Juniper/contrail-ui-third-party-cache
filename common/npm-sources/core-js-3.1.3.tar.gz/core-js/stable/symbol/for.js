module.exports = require('../../es/symbol/for');
