module.exports = require('../../es/symbol/is-concat-spreadable');
