module.exports = require('../../es/symbol/async-iterator');
