module.exports = require('../../es/symbol/has-instance');
