module.exports = require('../../es/symbol/search');
