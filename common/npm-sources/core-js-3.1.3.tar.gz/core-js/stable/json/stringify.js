module.exports = require('../../es/json/stringify');
