module.exports = require('../../es/string');
