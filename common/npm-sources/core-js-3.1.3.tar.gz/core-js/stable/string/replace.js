module.exports = require('../../es/string/replace');
