module.exports = require('../../es/string/sub');
