module.exports = require('../../es/string/italics');
