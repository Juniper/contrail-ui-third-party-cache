module.exports = require('../../es/string/match-all');
