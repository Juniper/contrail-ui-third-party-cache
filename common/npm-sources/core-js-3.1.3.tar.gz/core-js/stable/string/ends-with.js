module.exports = require('../../es/string/ends-with');
