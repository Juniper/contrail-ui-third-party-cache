module.exports = require('../../es/string/raw');
