module.exports = require('../../es/string/big');
