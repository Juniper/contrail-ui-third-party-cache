module.exports = require('../../es/string/split');
