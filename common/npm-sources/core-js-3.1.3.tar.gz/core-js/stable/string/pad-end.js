module.exports = require('../../es/string/pad-end');
