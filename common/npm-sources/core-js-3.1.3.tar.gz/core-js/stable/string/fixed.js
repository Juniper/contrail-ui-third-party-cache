module.exports = require('../../es/string/fixed');
