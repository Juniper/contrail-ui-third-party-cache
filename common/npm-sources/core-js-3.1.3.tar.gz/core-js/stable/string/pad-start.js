module.exports = require('../../es/string/pad-start');
