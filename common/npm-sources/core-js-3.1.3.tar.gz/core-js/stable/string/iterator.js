module.exports = require('../../es/string/iterator');
