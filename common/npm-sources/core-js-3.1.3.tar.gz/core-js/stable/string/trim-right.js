module.exports = require('../../es/string/trim-right');
