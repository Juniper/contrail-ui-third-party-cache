module.exports = require('../../../es/string/virtual/blink');
