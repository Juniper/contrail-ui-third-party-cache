module.exports = require('../../../es/string/virtual/starts-with');
