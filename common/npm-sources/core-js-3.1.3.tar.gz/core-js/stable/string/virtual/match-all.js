module.exports = require('../../../es/string/virtual/match-all');
