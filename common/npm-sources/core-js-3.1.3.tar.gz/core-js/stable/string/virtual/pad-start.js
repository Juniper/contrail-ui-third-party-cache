module.exports = require('../../../es/string/virtual/pad-start');
