module.exports = require('../../../es/string/virtual/includes');
