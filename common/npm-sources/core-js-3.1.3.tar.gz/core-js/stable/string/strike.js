module.exports = require('../../es/string/strike');
