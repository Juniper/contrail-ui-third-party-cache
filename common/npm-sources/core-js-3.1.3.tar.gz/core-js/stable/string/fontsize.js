module.exports = require('../../es/string/fontsize');
