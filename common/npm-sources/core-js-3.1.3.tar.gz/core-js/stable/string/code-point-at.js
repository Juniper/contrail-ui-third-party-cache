module.exports = require('../../es/string/code-point-at');
