module.exports = require('../../es/array/from');
