module.exports = require('../../es/array/reverse');
