module.exports = require('../../es/array/last-index-of');
