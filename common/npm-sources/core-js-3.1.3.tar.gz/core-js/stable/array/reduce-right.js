module.exports = require('../../es/array/reduce-right');
