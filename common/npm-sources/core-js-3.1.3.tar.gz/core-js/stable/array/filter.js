module.exports = require('../../es/array/filter');
