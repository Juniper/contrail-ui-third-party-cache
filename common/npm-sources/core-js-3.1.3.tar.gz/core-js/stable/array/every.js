module.exports = require('../../es/array/every');
