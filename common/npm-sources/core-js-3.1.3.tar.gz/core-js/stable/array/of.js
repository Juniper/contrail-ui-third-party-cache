module.exports = require('../../es/array/of');
