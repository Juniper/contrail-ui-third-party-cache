module.exports = require('../../../es/array/virtual/every');
