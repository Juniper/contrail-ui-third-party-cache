module.exports = require('../../../es/array/virtual/last-index-of');
