module.exports = require('../../es/array/splice');
