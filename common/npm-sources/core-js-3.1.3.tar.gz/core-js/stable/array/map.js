module.exports = require('../../es/array/map');
