module.exports = require('../../es/array/some');
