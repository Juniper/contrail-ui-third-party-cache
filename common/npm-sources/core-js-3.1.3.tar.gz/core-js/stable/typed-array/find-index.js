require('../../modules/es.typed-array.find-index');
