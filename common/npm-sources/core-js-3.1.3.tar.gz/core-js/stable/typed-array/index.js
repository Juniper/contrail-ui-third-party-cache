module.exports = require('../../es/typed-array');
