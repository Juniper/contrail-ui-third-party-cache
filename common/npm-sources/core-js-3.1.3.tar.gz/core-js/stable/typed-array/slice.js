require('../../modules/es.typed-array.slice');
