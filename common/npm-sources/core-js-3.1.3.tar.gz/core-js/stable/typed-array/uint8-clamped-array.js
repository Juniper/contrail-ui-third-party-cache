module.exports = require('../../es/typed-array/uint8-clamped-array');
