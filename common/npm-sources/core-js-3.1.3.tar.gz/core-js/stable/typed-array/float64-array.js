module.exports = require('../../es/typed-array/float64-array');
