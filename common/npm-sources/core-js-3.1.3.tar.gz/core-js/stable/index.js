require('../es');
require('../web');

module.exports = require('../internals/path');
