module.exports = require('../../es/reflect/construct');
