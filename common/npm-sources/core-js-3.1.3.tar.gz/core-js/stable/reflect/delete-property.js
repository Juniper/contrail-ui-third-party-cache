module.exports = require('../../es/reflect/delete-property');
