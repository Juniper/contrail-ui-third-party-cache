module.exports = require('../../es/reflect/is-extensible');
