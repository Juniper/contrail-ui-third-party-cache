module.exports = require('../../es/reflect/define-property');
