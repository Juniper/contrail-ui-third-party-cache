module.exports = require('../../es/reflect/prevent-extensions');
