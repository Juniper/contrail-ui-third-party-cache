module.exports = require('../../es/reflect/set-prototype-of');
