module.exports = require('../../es/reflect/get-prototype-of');
