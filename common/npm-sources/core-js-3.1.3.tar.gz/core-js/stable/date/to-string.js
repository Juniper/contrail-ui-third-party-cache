module.exports = require('../../es/date/to-string');
