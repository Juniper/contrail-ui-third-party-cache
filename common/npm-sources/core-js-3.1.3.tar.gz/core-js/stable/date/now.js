module.exports = require('../../es/date/now');
