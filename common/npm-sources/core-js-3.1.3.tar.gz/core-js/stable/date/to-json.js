module.exports = require('../../es/date/to-json');
