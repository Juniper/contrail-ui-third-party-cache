module.exports = require('../../es/date/to-primitive');
