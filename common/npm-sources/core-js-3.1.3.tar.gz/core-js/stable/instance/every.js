module.exports = require('../../es/instance/every');
