module.exports = require('../../es/instance/trim-left');
