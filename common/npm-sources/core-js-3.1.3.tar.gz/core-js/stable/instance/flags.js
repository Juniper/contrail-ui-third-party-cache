module.exports = require('../../es/instance/flags');
