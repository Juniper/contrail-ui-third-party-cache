module.exports = require('../../es/instance/concat');
