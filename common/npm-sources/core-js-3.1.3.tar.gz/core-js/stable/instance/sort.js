module.exports = require('../../es/instance/sort');
