module.exports = require('../../es/instance/some');
