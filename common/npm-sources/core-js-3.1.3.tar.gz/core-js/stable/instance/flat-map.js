module.exports = require('../../es/instance/flat-map');
