module.exports = require('../../es/instance/copy-within');
