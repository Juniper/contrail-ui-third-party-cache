module.exports = require('../../es/instance/starts-with');
