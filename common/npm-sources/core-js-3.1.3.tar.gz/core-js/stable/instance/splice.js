module.exports = require('../../es/instance/splice');
