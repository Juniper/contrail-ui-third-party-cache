module.exports = require('../../es/instance/match-all');
