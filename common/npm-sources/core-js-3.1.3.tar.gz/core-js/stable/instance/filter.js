module.exports = require('../../es/instance/filter');
