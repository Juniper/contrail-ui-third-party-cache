module.exports = require('../../es/instance/ends-with');
