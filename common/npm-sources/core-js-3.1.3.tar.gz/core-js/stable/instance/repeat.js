module.exports = require('../../es/instance/repeat');
