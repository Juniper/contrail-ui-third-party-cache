module.exports = require('../../es/math/to-string-tag');
