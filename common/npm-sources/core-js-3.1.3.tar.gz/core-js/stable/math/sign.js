module.exports = require('../../es/math/sign');
