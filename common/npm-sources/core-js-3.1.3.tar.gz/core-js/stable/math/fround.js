module.exports = require('../../es/math/fround');
