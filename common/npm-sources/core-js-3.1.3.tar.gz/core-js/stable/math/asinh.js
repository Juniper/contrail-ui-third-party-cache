module.exports = require('../../es/math/asinh');
