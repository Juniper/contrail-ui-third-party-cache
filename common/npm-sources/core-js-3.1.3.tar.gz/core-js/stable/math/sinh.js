module.exports = require('../../es/math/sinh');
