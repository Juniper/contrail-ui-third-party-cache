module.exports = require('../../es/math/clz32');
