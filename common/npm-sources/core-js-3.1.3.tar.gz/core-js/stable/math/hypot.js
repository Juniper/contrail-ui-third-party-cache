module.exports = require('../../es/math/hypot');
