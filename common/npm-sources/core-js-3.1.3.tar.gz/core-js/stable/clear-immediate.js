require('../modules/web.immediate');

module.exports = require('../internals/path').clearImmediate;
