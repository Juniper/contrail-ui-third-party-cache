module.exports = require('../../es/function/bind');
