module.exports = require('../../es/function/name');
