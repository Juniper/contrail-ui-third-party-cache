require('../modules/esnext.symbol.pattern-match');
