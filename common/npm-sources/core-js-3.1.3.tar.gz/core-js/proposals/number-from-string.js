require('../modules/esnext.number.from-string');
