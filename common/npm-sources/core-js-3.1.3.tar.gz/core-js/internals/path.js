module.exports = require('../internals/global');
