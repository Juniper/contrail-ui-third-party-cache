exports.f = require('../internals/well-known-symbol');
