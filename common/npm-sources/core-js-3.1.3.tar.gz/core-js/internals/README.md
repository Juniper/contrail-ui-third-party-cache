This folder contains internal parts of `core-js` like helpers.
