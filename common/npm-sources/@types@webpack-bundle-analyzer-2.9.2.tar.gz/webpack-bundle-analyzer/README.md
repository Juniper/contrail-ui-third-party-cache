# Installation
> `npm install --save @types/webpack-bundle-analyzer`

# Summary
This package contains type definitions for webpack-bundle-analyzer (https://github.com/th0r/webpack-bundle-analyzer).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack-bundle-analyzer

Additional Details
 * Last updated: Sat, 10 Mar 2018 02:17:46 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by Michael Strobel <https://github.com/kryops>.
