# 3.0.0

* Updates PostCSS to `5.0.0`.

# 2.1.0

* Adds the option to filter fonts by their weight or style properties.

# 2.0.1

* Fixed crashing when specify a font face url without quote marks

# 2.0.0

* This is a breaking update. The prior behaviour of this module has been moved
  to https://github.com/ben-eb/postcss-discard-unused along with new additions.
* New functionality for removing fonts based on a filter function or array
  (thanks to @TrySound).

# 1.0.1

* Fixed major README typo.

# 1.0.0

* Initial release.
