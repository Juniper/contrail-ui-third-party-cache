# Installation
> `npm install --save @types/react-jsonschema-form`

# Summary
This package contains type definitions for react-jsonschema-form (https://github.com/mozilla-services/react-jsonschema-form).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-jsonschema-form

Additional Details
 * Last updated: Sat, 23 Dec 2017 16:04:56 GMT
 * Dependencies: react, json-schema
 * Global values: none

# Credits
These definitions were written by Dan Fox <https://github.com/iamdanfox>, Jon Surrell <https://github.com/sirreal>, Ivan Jiang <https://github.com/iplus26>, Kurt Preston <https://github.com/KurtPreston>.
