"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ichigojam = require("refractor/lang/ichigojam.js");

var _ichigojam2 = _interopRequireDefault(_ichigojam);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _ichigojam2.default;