"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _docker = require("refractor/lang/docker.js");

var _docker2 = _interopRequireDefault(_docker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _docker2.default;