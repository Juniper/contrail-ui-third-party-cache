"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ini = require("refractor/lang/ini.js");

var _ini2 = _interopRequireDefault(_ini);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _ini2.default;