"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _python = require("refractor/lang/python.js");

var _python2 = _interopRequireDefault(_python);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _python2.default;