"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _flow = require("refractor/lang/flow.js");

var _flow2 = _interopRequireDefault(_flow);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _flow2.default;