"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _perl = require("refractor/lang/perl.js");

var _perl2 = _interopRequireDefault(_perl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _perl2.default;