"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _nginx = require("refractor/lang/nginx.js");

var _nginx2 = _interopRequireDefault(_nginx);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _nginx2.default;