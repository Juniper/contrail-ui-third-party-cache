"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _pug = require("refractor/lang/pug.js");

var _pug2 = _interopRequireDefault(_pug);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _pug2.default;