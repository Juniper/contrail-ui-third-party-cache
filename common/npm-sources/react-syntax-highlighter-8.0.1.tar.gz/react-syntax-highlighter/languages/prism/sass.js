"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _sass = require("refractor/lang/sass.js");

var _sass2 = _interopRequireDefault(_sass);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _sass2.default;