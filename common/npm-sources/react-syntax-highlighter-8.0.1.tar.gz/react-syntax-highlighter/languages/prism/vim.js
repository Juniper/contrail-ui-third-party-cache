"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vim = require("refractor/lang/vim.js");

var _vim2 = _interopRequireDefault(_vim);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _vim2.default;