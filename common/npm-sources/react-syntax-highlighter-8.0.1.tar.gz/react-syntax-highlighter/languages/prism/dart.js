"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dart = require("refractor/lang/dart.js");

var _dart2 = _interopRequireDefault(_dart);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _dart2.default;