"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _rip = require("refractor/lang/rip.js");

var _rip2 = _interopRequireDefault(_rip);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _rip2.default;