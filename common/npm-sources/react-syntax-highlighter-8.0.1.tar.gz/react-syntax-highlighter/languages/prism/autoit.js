"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _autoit = require("refractor/lang/autoit.js");

var _autoit2 = _interopRequireDefault(_autoit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _autoit2.default;