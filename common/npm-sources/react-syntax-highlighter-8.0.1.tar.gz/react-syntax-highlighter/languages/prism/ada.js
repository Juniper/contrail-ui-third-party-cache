"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ada = require("refractor/lang/ada.js");

var _ada2 = _interopRequireDefault(_ada);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _ada2.default;