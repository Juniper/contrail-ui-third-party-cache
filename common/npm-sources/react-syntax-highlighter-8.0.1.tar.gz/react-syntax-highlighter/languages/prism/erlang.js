"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _erlang = require("refractor/lang/erlang.js");

var _erlang2 = _interopRequireDefault(_erlang);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _erlang2.default;