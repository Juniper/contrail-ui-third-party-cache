"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _sas = require("refractor/lang/sas.js");

var _sas2 = _interopRequireDefault(_sas);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _sas2.default;