"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _bash = require("refractor/lang/bash.js");

var _bash2 = _interopRequireDefault(_bash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _bash2.default;