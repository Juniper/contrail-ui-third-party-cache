"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _phpExtras = require("refractor/lang/php-extras.js");

var _phpExtras2 = _interopRequireDefault(_phpExtras);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _phpExtras2.default;