"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _qore = require("refractor/lang/qore.js");

var _qore2 = _interopRequireDefault(_qore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _qore2.default;