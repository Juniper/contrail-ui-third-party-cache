"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _apacheconf = require("refractor/lang/apacheconf.js");

var _apacheconf2 = _interopRequireDefault(_apacheconf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _apacheconf2.default;