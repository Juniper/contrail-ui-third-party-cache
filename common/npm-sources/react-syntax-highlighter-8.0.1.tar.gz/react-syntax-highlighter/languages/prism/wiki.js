"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _wiki = require("refractor/lang/wiki.js");

var _wiki2 = _interopRequireDefault(_wiki);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _wiki2.default;