"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _parigp = require("refractor/lang/parigp.js");

var _parigp2 = _interopRequireDefault(_parigp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _parigp2.default;