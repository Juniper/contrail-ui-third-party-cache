"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _jolie = require("refractor/lang/jolie.js");

var _jolie2 = _interopRequireDefault(_jolie);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _jolie2.default;