"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _csharp = require("refractor/lang/csharp.js");

var _csharp2 = _interopRequireDefault(_csharp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _csharp2.default;