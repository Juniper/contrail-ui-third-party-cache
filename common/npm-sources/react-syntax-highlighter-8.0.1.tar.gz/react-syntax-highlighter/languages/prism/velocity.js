"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _velocity = require("refractor/lang/velocity.js");

var _velocity2 = _interopRequireDefault(_velocity);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _velocity2.default;