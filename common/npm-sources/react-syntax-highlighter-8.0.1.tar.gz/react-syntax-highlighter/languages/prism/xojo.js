"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _xojo = require("refractor/lang/xojo.js");

var _xojo2 = _interopRequireDefault(_xojo);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _xojo2.default;