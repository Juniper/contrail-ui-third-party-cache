"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hpkp = require("refractor/lang/hpkp.js");

var _hpkp2 = _interopRequireDefault(_hpkp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _hpkp2.default;