"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _diff = require("refractor/lang/diff.js");

var _diff2 = _interopRequireDefault(_diff);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _diff2.default;