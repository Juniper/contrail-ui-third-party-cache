"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _properties = require("refractor/lang/properties.js");

var _properties2 = _interopRequireDefault(_properties);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _properties2.default;