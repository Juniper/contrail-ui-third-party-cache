"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hsts = require("refractor/lang/hsts.js");

var _hsts2 = _interopRequireDefault(_hsts);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _hsts2.default;