"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _opencl = require("refractor/lang/opencl.js");

var _opencl2 = _interopRequireDefault(_opencl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _opencl2.default;