"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _fortran = require("refractor/lang/fortran.js");

var _fortran2 = _interopRequireDefault(_fortran);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _fortran2.default;