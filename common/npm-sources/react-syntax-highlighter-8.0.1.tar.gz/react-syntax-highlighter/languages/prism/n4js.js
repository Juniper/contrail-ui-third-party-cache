"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _n4js = require("refractor/lang/n4js.js");

var _n4js2 = _interopRequireDefault(_n4js);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _n4js2.default;