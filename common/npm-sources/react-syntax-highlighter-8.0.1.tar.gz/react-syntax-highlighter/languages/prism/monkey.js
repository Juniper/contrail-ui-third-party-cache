"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _monkey = require("refractor/lang/monkey.js");

var _monkey2 = _interopRequireDefault(_monkey);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _monkey2.default;