"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _renpy = require("refractor/lang/renpy.js");

var _renpy2 = _interopRequireDefault(_renpy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _renpy2.default;