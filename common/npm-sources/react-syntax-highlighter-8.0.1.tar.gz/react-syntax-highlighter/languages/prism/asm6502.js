"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _asm = require("refractor/lang/asm6502.js");

var _asm2 = _interopRequireDefault(_asm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _asm2.default;