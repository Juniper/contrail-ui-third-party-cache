"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _java = require("refractor/lang/java.js");

var _java2 = _interopRequireDefault(_java);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _java2.default;