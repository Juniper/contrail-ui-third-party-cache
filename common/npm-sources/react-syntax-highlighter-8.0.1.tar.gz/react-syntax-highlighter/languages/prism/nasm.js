"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _nasm = require("refractor/lang/nasm.js");

var _nasm2 = _interopRequireDefault(_nasm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _nasm2.default;