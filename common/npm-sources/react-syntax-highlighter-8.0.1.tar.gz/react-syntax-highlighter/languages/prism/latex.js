"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _latex = require("refractor/lang/latex.js");

var _latex2 = _interopRequireDefault(_latex);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _latex2.default;