"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _tsx = require("refractor/lang/tsx.js");

var _tsx2 = _interopRequireDefault(_tsx);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _tsx2.default;