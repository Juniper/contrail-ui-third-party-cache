"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _fsharp = require("refractor/lang/fsharp.js");

var _fsharp2 = _interopRequireDefault(_fsharp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _fsharp2.default;