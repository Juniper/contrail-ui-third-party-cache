"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _q = require("refractor/lang/q.js");

var _q2 = _interopRequireDefault(_q);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _q2.default;