"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _haxe = require("refractor/lang/haxe.js");

var _haxe2 = _interopRequireDefault(_haxe);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _haxe2.default;