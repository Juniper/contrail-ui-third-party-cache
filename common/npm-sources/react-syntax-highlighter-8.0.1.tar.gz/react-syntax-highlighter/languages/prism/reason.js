"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reason = require("refractor/lang/reason.js");

var _reason2 = _interopRequireDefault(_reason);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _reason2.default;