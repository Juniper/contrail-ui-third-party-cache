"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _verilog = require("refractor/lang/verilog.js");

var _verilog2 = _interopRequireDefault(_verilog);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _verilog2.default;