"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _pascal = require("refractor/lang/pascal.js");

var _pascal2 = _interopRequireDefault(_pascal);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _pascal2.default;