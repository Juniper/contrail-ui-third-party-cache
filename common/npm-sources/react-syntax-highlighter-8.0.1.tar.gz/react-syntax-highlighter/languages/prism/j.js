"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _j = require("refractor/lang/j.js");

var _j2 = _interopRequireDefault(_j);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _j2.default;