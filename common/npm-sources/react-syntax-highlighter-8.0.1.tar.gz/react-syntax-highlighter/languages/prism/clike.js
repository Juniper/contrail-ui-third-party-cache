"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _clike = require("refractor/lang/clike.js");

var _clike2 = _interopRequireDefault(_clike);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _clike2.default;