"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _nim = require("refractor/lang/nim.js");

var _nim2 = _interopRequireDefault(_nim);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _nim2.default;