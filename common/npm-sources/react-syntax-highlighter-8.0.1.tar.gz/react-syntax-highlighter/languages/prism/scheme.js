"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scheme = require("refractor/lang/scheme.js");

var _scheme2 = _interopRequireDefault(_scheme);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _scheme2.default;