"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _io = require("refractor/lang/io.js");

var _io2 = _interopRequireDefault(_io);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _io2.default;