"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _arduino = require("refractor/lang/arduino.js");

var _arduino2 = _interopRequireDefault(_arduino);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _arduino2.default;