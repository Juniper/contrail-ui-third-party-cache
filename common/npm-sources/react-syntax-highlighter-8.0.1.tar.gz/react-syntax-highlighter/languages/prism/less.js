"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _less = require("refractor/lang/less.js");

var _less2 = _interopRequireDefault(_less);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _less2.default;