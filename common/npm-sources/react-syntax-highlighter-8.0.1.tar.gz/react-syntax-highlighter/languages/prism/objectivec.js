"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _objectivec = require("refractor/lang/objectivec.js");

var _objectivec2 = _interopRequireDefault(_objectivec);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _objectivec2.default;