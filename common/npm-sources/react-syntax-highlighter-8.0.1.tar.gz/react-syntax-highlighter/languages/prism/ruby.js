"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ruby = require("refractor/lang/ruby.js");

var _ruby2 = _interopRequireDefault(_ruby);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _ruby2.default;