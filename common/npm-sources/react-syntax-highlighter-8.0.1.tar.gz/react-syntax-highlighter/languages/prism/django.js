"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _django = require("refractor/lang/django.js");

var _django2 = _interopRequireDefault(_django);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _django2.default;