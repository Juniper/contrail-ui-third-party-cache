"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _swift = require("refractor/lang/swift.js");

var _swift2 = _interopRequireDefault(_swift);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _swift2.default;