"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _gedcom = require("refractor/lang/gedcom.js");

var _gedcom2 = _interopRequireDefault(_gedcom);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _gedcom2.default;