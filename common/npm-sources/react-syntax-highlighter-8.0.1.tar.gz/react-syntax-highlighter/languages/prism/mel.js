"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mel = require("refractor/lang/mel.js");

var _mel2 = _interopRequireDefault(_mel);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _mel2.default;