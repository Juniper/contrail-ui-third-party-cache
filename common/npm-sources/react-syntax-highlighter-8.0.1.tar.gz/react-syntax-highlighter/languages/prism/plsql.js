"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _plsql = require("refractor/lang/plsql.js");

var _plsql2 = _interopRequireDefault(_plsql);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _plsql2.default;