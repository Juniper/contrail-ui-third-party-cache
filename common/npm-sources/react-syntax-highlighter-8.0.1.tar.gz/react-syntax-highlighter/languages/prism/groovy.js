"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _groovy = require("refractor/lang/groovy.js");

var _groovy2 = _interopRequireDefault(_groovy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _groovy2.default;