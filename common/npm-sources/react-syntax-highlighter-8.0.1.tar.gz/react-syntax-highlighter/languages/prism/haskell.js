"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _haskell = require("refractor/lang/haskell.js");

var _haskell2 = _interopRequireDefault(_haskell);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _haskell2.default;