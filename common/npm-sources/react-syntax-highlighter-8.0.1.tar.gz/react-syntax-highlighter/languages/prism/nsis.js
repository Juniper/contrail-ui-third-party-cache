"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _nsis = require("refractor/lang/nsis.js");

var _nsis2 = _interopRequireDefault(_nsis);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _nsis2.default;