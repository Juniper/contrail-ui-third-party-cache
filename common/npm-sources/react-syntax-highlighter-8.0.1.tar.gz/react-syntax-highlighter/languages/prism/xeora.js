"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _xeora = require("refractor/lang/xeora.js");

var _xeora2 = _interopRequireDefault(_xeora);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _xeora2.default;