"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typescript = require("refractor/lang/typescript.js");

var _typescript2 = _interopRequireDefault(_typescript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _typescript2.default;