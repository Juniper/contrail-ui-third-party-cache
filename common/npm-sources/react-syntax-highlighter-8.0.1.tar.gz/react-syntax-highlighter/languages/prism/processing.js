"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _processing = require("refractor/lang/processing.js");

var _processing2 = _interopRequireDefault(_processing);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _processing2.default;