'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _prismjs = require('prismjs');

var _prismjs2 = _interopRequireDefault(_prismjs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _prismjs2.default.languages.core;