"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _cssExtras = require("refractor/lang/css-extras.js");

var _cssExtras2 = _interopRequireDefault(_cssExtras);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _cssExtras2.default;