"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _cpp = require("refractor/lang/cpp.js");

var _cpp2 = _interopRequireDefault(_cpp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _cpp2.default;