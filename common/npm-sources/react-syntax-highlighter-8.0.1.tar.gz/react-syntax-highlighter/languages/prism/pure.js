"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _pure = require("refractor/lang/pure.js");

var _pure2 = _interopRequireDefault(_pure);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _pure2.default;