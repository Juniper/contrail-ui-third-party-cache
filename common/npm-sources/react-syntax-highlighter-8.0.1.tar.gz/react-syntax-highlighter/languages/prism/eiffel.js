"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _eiffel = require("refractor/lang/eiffel.js");

var _eiffel2 = _interopRequireDefault(_eiffel);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _eiffel2.default;