"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _visualBasic = require("refractor/lang/visual-basic.js");

var _visualBasic2 = _interopRequireDefault(_visualBasic);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _visualBasic2.default;