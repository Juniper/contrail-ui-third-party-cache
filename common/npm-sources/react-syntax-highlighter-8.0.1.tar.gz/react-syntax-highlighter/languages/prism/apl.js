"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _apl = require("refractor/lang/apl.js");

var _apl2 = _interopRequireDefault(_apl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _apl2.default;