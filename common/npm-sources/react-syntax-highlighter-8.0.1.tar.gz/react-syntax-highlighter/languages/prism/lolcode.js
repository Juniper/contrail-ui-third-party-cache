"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lolcode = require("refractor/lang/lolcode.js");

var _lolcode2 = _interopRequireDefault(_lolcode);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _lolcode2.default;