"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _asciidoc = require("refractor/lang/asciidoc.js");

var _asciidoc2 = _interopRequireDefault(_asciidoc);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _asciidoc2.default;