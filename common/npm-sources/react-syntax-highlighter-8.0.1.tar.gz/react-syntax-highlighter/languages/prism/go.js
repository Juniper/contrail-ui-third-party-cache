"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _go = require("refractor/lang/go.js");

var _go2 = _interopRequireDefault(_go);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _go2.default;