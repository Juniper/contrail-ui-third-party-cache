"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _brainfuck = require("refractor/lang/brainfuck.js");

var _brainfuck2 = _interopRequireDefault(_brainfuck);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _brainfuck2.default;