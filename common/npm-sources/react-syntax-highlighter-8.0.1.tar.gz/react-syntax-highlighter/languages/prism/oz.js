"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _oz = require("refractor/lang/oz.js");

var _oz2 = _interopRequireDefault(_oz);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _oz2.default;