"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _d = require("refractor/lang/d.js");

var _d2 = _interopRequireDefault(_d);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _d2.default;