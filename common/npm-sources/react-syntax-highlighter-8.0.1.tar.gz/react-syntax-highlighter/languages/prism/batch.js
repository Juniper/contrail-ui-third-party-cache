"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _batch = require("refractor/lang/batch.js");

var _batch2 = _interopRequireDefault(_batch);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _batch2.default;