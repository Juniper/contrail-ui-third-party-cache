"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _glsl = require("refractor/lang/glsl.js");

var _glsl2 = _interopRequireDefault(_glsl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _glsl2.default;