"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _jsx = require("refractor/lang/jsx.js");

var _jsx2 = _interopRequireDefault(_jsx);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _jsx2.default;