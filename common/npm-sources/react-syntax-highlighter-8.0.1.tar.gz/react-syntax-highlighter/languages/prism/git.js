"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _git = require("refractor/lang/git.js");

var _git2 = _interopRequireDefault(_git);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _git2.default;