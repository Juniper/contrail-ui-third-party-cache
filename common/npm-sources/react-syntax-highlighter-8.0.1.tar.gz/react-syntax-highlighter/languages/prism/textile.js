"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _textile = require("refractor/lang/textile.js");

var _textile2 = _interopRequireDefault(_textile);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _textile2.default;