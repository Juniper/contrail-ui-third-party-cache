"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _c = require("refractor/lang/c.js");

var _c2 = _interopRequireDefault(_c);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _c2.default;