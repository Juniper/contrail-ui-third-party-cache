"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _wasm = require("refractor/lang/wasm.js");

var _wasm2 = _interopRequireDefault(_wasm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _wasm2.default;