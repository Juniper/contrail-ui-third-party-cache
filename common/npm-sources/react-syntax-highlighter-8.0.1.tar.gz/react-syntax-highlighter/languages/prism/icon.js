"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _icon = require("refractor/lang/icon.js");

var _icon2 = _interopRequireDefault(_icon);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _icon2.default;