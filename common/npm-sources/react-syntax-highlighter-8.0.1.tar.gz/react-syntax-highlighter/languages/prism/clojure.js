"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _clojure = require("refractor/lang/clojure.js");

var _clojure2 = _interopRequireDefault(_clojure);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _clojure2.default;