"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keyman = require("refractor/lang/keyman.js");

var _keyman2 = _interopRequireDefault(_keyman);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _keyman2.default;