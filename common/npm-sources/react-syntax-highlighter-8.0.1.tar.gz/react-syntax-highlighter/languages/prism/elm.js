"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _elm = require("refractor/lang/elm.js");

var _elm2 = _interopRequireDefault(_elm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _elm2.default;