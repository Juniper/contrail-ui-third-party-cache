"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mizar = require("refractor/lang/mizar.js");

var _mizar2 = _interopRequireDefault(_mizar);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _mizar2.default;