"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vbnet = require("refractor/lang/vbnet.js");

var _vbnet2 = _interopRequireDefault(_vbnet);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _vbnet2.default;