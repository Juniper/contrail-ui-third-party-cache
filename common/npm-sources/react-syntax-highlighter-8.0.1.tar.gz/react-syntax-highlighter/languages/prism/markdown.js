"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _markdown = require("refractor/lang/markdown.js");

var _markdown2 = _interopRequireDefault(_markdown);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
exports.default = _markdown2.default;