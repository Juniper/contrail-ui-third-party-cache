"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _rsl = require("highlight.js/lib/languages/rsl");

var _rsl2 = _interopRequireDefault(_rsl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _rsl2.default;