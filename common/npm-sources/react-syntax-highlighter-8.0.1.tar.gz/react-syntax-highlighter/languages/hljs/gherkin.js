"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _gherkin = require("highlight.js/lib/languages/gherkin");

var _gherkin2 = _interopRequireDefault(_gherkin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _gherkin2.default;