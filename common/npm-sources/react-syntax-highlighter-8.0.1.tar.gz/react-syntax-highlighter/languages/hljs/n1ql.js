"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _n1ql = require("highlight.js/lib/languages/n1ql");

var _n1ql2 = _interopRequireDefault(_n1ql);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _n1ql2.default;