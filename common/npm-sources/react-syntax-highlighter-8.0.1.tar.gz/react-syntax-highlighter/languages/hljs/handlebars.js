"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _handlebars = require("highlight.js/lib/languages/handlebars");

var _handlebars2 = _interopRequireDefault(_handlebars);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _handlebars2.default;