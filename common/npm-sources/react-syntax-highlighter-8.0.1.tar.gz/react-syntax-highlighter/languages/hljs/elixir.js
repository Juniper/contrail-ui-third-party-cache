"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _elixir = require("highlight.js/lib/languages/elixir");

var _elixir2 = _interopRequireDefault(_elixir);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _elixir2.default;