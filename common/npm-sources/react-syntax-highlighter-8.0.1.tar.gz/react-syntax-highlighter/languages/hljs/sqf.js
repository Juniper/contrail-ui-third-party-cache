"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _sqf = require("highlight.js/lib/languages/sqf");

var _sqf2 = _interopRequireDefault(_sqf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _sqf2.default;