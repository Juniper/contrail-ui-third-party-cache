"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _x86asm = require("highlight.js/lib/languages/x86asm");

var _x86asm2 = _interopRequireDefault(_x86asm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _x86asm2.default;