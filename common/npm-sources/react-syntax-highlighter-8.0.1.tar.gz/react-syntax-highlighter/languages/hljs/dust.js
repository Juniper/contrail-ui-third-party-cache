"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dust = require("highlight.js/lib/languages/dust");

var _dust2 = _interopRequireDefault(_dust);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _dust2.default;