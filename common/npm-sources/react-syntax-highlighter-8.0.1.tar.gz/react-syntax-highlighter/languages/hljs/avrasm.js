"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _avrasm = require("highlight.js/lib/languages/avrasm");

var _avrasm2 = _interopRequireDefault(_avrasm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _avrasm2.default;