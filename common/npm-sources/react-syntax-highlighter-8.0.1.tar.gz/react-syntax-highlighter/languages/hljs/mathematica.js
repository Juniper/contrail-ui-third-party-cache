"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mathematica = require("highlight.js/lib/languages/mathematica");

var _mathematica2 = _interopRequireDefault(_mathematica);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _mathematica2.default;