"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _csp = require("highlight.js/lib/languages/csp");

var _csp2 = _interopRequireDefault(_csp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _csp2.default;