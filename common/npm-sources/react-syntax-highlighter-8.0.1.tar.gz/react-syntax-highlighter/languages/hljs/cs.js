"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _cs = require("highlight.js/lib/languages/cs");

var _cs2 = _interopRequireDefault(_cs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _cs2.default;