"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vhdl = require("highlight.js/lib/languages/vhdl");

var _vhdl2 = _interopRequireDefault(_vhdl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _vhdl2.default;