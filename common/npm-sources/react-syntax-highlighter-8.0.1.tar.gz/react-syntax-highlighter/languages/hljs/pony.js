"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _pony = require("highlight.js/lib/languages/pony");

var _pony2 = _interopRequireDefault(_pony);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _pony2.default;