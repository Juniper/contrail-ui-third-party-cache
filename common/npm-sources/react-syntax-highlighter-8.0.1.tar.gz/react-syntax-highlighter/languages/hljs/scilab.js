"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scilab = require("highlight.js/lib/languages/scilab");

var _scilab2 = _interopRequireDefault(_scilab);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _scilab2.default;