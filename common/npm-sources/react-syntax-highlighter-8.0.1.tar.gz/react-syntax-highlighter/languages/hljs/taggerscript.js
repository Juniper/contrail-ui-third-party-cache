"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _taggerscript = require("highlight.js/lib/languages/taggerscript");

var _taggerscript2 = _interopRequireDefault(_taggerscript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _taggerscript2.default;