"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _kotlin = require("highlight.js/lib/languages/kotlin");

var _kotlin2 = _interopRequireDefault(_kotlin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _kotlin2.default;