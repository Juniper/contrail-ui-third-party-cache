"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _actionscript = require("highlight.js/lib/languages/actionscript");

var _actionscript2 = _interopRequireDefault(_actionscript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _actionscript2.default;