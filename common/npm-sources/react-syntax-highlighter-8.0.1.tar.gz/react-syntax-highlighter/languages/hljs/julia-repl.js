"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _juliaRepl = require("highlight.js/lib/languages/julia-repl");

var _juliaRepl2 = _interopRequireDefault(_juliaRepl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _juliaRepl2.default;