"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _powershell = require("highlight.js/lib/languages/powershell");

var _powershell2 = _interopRequireDefault(_powershell);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _powershell2.default;