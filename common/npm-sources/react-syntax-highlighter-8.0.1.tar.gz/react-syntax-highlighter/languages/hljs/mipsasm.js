"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mipsasm = require("highlight.js/lib/languages/mipsasm");

var _mipsasm2 = _interopRequireDefault(_mipsasm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _mipsasm2.default;