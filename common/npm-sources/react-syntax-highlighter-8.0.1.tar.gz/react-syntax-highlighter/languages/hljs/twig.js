"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _twig = require("highlight.js/lib/languages/twig");

var _twig2 = _interopRequireDefault(_twig);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _twig2.default;