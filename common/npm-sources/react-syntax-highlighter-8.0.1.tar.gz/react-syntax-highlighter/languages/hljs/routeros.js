"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _routeros = require("highlight.js/lib/languages/routeros");

var _routeros2 = _interopRequireDefault(_routeros);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _routeros2.default;