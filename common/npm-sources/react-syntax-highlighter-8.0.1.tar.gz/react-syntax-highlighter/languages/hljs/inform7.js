"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _inform = require("highlight.js/lib/languages/inform7");

var _inform2 = _interopRequireDefault(_inform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _inform2.default;