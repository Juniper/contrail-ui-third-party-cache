"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _zephir = require("highlight.js/lib/languages/zephir");

var _zephir2 = _interopRequireDefault(_zephir);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _zephir2.default;