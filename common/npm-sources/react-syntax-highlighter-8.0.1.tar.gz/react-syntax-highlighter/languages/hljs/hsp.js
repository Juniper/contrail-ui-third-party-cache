"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hsp = require("highlight.js/lib/languages/hsp");

var _hsp2 = _interopRequireDefault(_hsp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _hsp2.default;