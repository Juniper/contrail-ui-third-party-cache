"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _makefile = require("highlight.js/lib/languages/makefile");

var _makefile2 = _interopRequireDefault(_makefile);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _makefile2.default;