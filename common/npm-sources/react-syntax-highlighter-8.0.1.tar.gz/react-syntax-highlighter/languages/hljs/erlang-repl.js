"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _erlangRepl = require("highlight.js/lib/languages/erlang-repl");

var _erlangRepl2 = _interopRequireDefault(_erlangRepl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _erlangRepl2.default;