"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _basic = require("highlight.js/lib/languages/basic");

var _basic2 = _interopRequireDefault(_basic);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _basic2.default;