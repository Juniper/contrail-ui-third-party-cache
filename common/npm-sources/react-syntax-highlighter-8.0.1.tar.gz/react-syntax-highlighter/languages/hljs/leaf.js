"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _leaf = require("highlight.js/lib/languages/leaf");

var _leaf2 = _interopRequireDefault(_leaf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _leaf2.default;