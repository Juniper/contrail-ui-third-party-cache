"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _applescript = require("highlight.js/lib/languages/applescript");

var _applescript2 = _interopRequireDefault(_applescript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _applescript2.default;