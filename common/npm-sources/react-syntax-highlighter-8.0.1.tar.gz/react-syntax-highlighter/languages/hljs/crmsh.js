"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _crmsh = require("highlight.js/lib/languages/crmsh");

var _crmsh2 = _interopRequireDefault(_crmsh);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _crmsh2.default;