"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _coq = require("highlight.js/lib/languages/coq");

var _coq2 = _interopRequireDefault(_coq);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _coq2.default;