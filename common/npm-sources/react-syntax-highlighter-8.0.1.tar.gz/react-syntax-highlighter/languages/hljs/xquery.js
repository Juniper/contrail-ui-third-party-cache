"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _xquery = require("highlight.js/lib/languages/xquery");

var _xquery2 = _interopRequireDefault(_xquery);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _xquery2.default;