"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _r = require("highlight.js/lib/languages/r");

var _r2 = _interopRequireDefault(_r);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _r2.default;