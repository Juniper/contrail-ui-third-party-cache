"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _gauss = require("highlight.js/lib/languages/gauss");

var _gauss2 = _interopRequireDefault(_gauss);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _gauss2.default;