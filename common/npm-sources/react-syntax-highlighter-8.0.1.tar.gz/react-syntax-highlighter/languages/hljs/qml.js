"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _qml = require("highlight.js/lib/languages/qml");

var _qml2 = _interopRequireDefault(_qml);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _qml2.default;