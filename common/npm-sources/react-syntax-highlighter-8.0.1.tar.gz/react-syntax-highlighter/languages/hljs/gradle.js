"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _gradle = require("highlight.js/lib/languages/gradle");

var _gradle2 = _interopRequireDefault(_gradle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _gradle2.default;