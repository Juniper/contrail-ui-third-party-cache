"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _capnproto = require("highlight.js/lib/languages/capnproto");

var _capnproto2 = _interopRequireDefault(_capnproto);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _capnproto2.default;