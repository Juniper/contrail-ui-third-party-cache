"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _nix = require("highlight.js/lib/languages/nix");

var _nix2 = _interopRequireDefault(_nix);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _nix2.default;