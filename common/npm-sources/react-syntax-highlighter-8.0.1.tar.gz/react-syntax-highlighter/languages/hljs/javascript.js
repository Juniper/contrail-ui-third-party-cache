"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _javascript = require("highlight.js/lib/languages/javascript");

var _javascript2 = _interopRequireDefault(_javascript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _javascript2.default;