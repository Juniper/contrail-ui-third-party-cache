"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _tcl = require("highlight.js/lib/languages/tcl");

var _tcl2 = _interopRequireDefault(_tcl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _tcl2.default;