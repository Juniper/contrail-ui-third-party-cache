"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _rib = require("highlight.js/lib/languages/rib");

var _rib2 = _interopRequireDefault(_rib);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _rib2.default;