"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dns = require("highlight.js/lib/languages/dns");

var _dns2 = _interopRequireDefault(_dns);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _dns2.default;