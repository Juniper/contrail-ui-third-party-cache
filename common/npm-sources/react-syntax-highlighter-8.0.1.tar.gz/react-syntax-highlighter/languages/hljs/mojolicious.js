"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mojolicious = require("highlight.js/lib/languages/mojolicious");

var _mojolicious2 = _interopRequireDefault(_mojolicious);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _mojolicious2.default;