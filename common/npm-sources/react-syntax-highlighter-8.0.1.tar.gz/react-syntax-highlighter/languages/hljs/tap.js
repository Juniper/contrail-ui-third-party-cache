"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _tap = require("highlight.js/lib/languages/tap");

var _tap2 = _interopRequireDefault(_tap);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _tap2.default;