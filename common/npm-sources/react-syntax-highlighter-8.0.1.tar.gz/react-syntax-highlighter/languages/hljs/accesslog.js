"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _accesslog = require("highlight.js/lib/languages/accesslog");

var _accesslog2 = _interopRequireDefault(_accesslog);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _accesslog2.default;