"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mercury = require("highlight.js/lib/languages/mercury");

var _mercury2 = _interopRequireDefault(_mercury);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _mercury2.default;