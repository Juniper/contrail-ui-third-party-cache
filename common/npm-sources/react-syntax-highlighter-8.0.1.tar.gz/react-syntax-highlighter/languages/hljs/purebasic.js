"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _purebasic = require("highlight.js/lib/languages/purebasic");

var _purebasic2 = _interopRequireDefault(_purebasic);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _purebasic2.default;