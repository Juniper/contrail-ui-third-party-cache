"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _bash = require("highlight.js/lib/languages/bash");

var _bash2 = _interopRequireDefault(_bash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _bash2.default;