"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _step = require("highlight.js/lib/languages/step21");

var _step2 = _interopRequireDefault(_step);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _step2.default;