"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _python = require("highlight.js/lib/languages/python");

var _python2 = _interopRequireDefault(_python);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _python2.default;