"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _smalltalk = require("highlight.js/lib/languages/smalltalk");

var _smalltalk2 = _interopRequireDefault(_smalltalk);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _smalltalk2.default;