"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _armasm = require("highlight.js/lib/languages/armasm");

var _armasm2 = _interopRequireDefault(_armasm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _armasm2.default;