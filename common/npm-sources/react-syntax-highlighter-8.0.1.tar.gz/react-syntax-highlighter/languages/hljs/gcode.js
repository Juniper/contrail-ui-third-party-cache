"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _gcode = require("highlight.js/lib/languages/gcode");

var _gcode2 = _interopRequireDefault(_gcode);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _gcode2.default;