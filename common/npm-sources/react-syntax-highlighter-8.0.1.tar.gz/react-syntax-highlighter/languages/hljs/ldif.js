"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ldif = require("highlight.js/lib/languages/ldif");

var _ldif2 = _interopRequireDefault(_ldif);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _ldif2.default;