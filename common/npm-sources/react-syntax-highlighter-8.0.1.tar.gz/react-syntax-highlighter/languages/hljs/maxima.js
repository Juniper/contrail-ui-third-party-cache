"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _maxima = require("highlight.js/lib/languages/maxima");

var _maxima2 = _interopRequireDefault(_maxima);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _maxima2.default;