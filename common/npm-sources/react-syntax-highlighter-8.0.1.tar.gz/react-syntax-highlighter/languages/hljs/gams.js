"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _gams = require("highlight.js/lib/languages/gams");

var _gams2 = _interopRequireDefault(_gams);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _gams2.default;