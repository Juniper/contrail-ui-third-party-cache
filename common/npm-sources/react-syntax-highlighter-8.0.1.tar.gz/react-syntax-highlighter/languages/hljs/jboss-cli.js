"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _jbossCli = require("highlight.js/lib/languages/jboss-cli");

var _jbossCli2 = _interopRequireDefault(_jbossCli);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _jbossCli2.default;