"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lua = require("highlight.js/lib/languages/lua");

var _lua2 = _interopRequireDefault(_lua);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _lua2.default;