"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _brainfuck = require("highlight.js/lib/languages/brainfuck");

var _brainfuck2 = _interopRequireDefault(_brainfuck);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _brainfuck2.default;