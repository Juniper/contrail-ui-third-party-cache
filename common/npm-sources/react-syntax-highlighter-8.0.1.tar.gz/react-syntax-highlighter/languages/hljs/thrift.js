"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _thrift = require("highlight.js/lib/languages/thrift");

var _thrift2 = _interopRequireDefault(_thrift);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _thrift2.default;