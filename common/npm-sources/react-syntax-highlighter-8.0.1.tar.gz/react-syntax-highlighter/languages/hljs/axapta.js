"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _axapta = require("highlight.js/lib/languages/axapta");

var _axapta2 = _interopRequireDefault(_axapta);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _axapta2.default;