"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _cos = require("highlight.js/lib/languages/cos");

var _cos2 = _interopRequireDefault(_cos);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _cos2.default;