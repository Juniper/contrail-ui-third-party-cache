"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hy = require("highlight.js/lib/languages/hy");

var _hy2 = _interopRequireDefault(_hy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _hy2.default;