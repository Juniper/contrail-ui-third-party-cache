"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lsl = require("highlight.js/lib/languages/lsl");

var _lsl2 = _interopRequireDefault(_lsl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _lsl2.default;