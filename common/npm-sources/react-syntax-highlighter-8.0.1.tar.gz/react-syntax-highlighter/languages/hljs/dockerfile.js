"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dockerfile = require("highlight.js/lib/languages/dockerfile");

var _dockerfile2 = _interopRequireDefault(_dockerfile);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _dockerfile2.default;