"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dsconfig = require("highlight.js/lib/languages/dsconfig");

var _dsconfig2 = _interopRequireDefault(_dsconfig);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _dsconfig2.default;