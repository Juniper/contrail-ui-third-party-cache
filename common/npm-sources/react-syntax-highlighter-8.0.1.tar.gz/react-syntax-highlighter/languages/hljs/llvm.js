"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _llvm = require("highlight.js/lib/languages/llvm");

var _llvm2 = _interopRequireDefault(_llvm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _llvm2.default;