"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _abnf = require("highlight.js/lib/languages/abnf");

var _abnf2 = _interopRequireDefault(_abnf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _abnf2.default;