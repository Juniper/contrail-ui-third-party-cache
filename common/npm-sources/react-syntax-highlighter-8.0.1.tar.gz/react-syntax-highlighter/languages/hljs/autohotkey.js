"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _autohotkey = require("highlight.js/lib/languages/autohotkey");

var _autohotkey2 = _interopRequireDefault(_autohotkey);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _autohotkey2.default;