"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _livecodeserver = require("highlight.js/lib/languages/livecodeserver");

var _livecodeserver2 = _interopRequireDefault(_livecodeserver);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _livecodeserver2.default;