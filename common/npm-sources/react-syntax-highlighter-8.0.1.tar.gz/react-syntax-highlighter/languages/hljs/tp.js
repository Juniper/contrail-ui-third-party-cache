"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _tp = require("highlight.js/lib/languages/tp");

var _tp2 = _interopRequireDefault(_tp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _tp2.default;