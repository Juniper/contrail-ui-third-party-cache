"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _cal = require("highlight.js/lib/languages/cal");

var _cal2 = _interopRequireDefault(_cal);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _cal2.default;