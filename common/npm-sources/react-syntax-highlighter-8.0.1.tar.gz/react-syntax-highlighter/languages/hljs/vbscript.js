"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vbscript = require("highlight.js/lib/languages/vbscript");

var _vbscript2 = _interopRequireDefault(_vbscript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _vbscript2.default;