"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _nimrod = require("highlight.js/lib/languages/nimrod");

var _nimrod2 = _interopRequireDefault(_nimrod);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _nimrod2.default;