"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _excel = require("highlight.js/lib/languages/excel");

var _excel2 = _interopRequireDefault(_excel);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _excel2.default;