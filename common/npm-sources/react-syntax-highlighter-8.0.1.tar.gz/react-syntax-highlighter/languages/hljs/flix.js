"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _flix = require("highlight.js/lib/languages/flix");

var _flix2 = _interopRequireDefault(_flix);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _flix2.default;