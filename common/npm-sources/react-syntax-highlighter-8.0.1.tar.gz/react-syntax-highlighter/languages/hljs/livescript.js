"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _livescript = require("highlight.js/lib/languages/livescript");

var _livescript2 = _interopRequireDefault(_livescript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _livescript2.default;