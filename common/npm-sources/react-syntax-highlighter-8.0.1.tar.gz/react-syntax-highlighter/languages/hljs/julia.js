"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _julia = require("highlight.js/lib/languages/julia");

var _julia2 = _interopRequireDefault(_julia);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _julia2.default;