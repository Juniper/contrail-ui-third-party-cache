"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _coffeescript = require("highlight.js/lib/languages/coffeescript");

var _coffeescript2 = _interopRequireDefault(_coffeescript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _coffeescript2.default;