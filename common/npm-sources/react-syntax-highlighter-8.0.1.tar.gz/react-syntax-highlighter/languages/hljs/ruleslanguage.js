"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ruleslanguage = require("highlight.js/lib/languages/ruleslanguage");

var _ruleslanguage2 = _interopRequireDefault(_ruleslanguage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _ruleslanguage2.default;