"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _oxygene = require("highlight.js/lib/languages/oxygene");

var _oxygene2 = _interopRequireDefault(_oxygene);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _oxygene2.default;