"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _shell = require("highlight.js/lib/languages/shell");

var _shell2 = _interopRequireDefault(_shell);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _shell2.default;