"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _rust = require("highlight.js/lib/languages/rust");

var _rust2 = _interopRequireDefault(_rust);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _rust2.default;