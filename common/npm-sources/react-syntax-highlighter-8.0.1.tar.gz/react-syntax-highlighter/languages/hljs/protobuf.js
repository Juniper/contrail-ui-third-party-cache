"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _protobuf = require("highlight.js/lib/languages/protobuf");

var _protobuf2 = _interopRequireDefault(_protobuf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _protobuf2.default;