"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _bnf = require("highlight.js/lib/languages/bnf");

var _bnf2 = _interopRequireDefault(_bnf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _bnf2.default;