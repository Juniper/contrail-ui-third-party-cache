"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _css = require("highlight.js/lib/languages/css");

var _css2 = _interopRequireDefault(_css);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _css2.default;