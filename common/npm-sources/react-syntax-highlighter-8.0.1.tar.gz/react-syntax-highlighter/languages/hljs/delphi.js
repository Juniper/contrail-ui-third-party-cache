"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _delphi = require("highlight.js/lib/languages/delphi");

var _delphi2 = _interopRequireDefault(_delphi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _delphi2.default;