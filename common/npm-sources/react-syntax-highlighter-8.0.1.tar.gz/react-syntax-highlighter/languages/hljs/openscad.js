"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _openscad = require("highlight.js/lib/languages/openscad");

var _openscad2 = _interopRequireDefault(_openscad);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _openscad2.default;