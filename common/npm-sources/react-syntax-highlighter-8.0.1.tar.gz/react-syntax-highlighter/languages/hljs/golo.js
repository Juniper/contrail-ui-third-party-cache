"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _golo = require("highlight.js/lib/languages/golo");

var _golo2 = _interopRequireDefault(_golo);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _golo2.default;