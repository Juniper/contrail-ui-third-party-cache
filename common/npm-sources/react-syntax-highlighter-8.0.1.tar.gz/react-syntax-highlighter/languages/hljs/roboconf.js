"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _roboconf = require("highlight.js/lib/languages/roboconf");

var _roboconf2 = _interopRequireDefault(_roboconf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _roboconf2.default;