"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scss = require("highlight.js/lib/languages/scss");

var _scss2 = _interopRequireDefault(_scss);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _scss2.default;