"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ebnf = require("highlight.js/lib/languages/ebnf");

var _ebnf2 = _interopRequireDefault(_ebnf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _ebnf2.default;