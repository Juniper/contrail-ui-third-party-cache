"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _smali = require("highlight.js/lib/languages/smali");

var _smali2 = _interopRequireDefault(_smali);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _smali2.default;