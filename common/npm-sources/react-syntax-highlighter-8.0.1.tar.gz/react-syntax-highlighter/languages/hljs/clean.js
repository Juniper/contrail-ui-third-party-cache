"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _clean = require("highlight.js/lib/languages/clean");

var _clean2 = _interopRequireDefault(_clean);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _clean2.default;