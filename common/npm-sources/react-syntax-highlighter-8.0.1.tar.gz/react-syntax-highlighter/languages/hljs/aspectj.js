"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aspectj = require("highlight.js/lib/languages/aspectj");

var _aspectj2 = _interopRequireDefault(_aspectj);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _aspectj2.default;