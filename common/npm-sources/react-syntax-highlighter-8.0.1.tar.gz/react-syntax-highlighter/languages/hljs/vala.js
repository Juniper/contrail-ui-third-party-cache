"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vala = require("highlight.js/lib/languages/vala");

var _vala2 = _interopRequireDefault(_vala);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _vala2.default;