"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _moonscript = require("highlight.js/lib/languages/moonscript");

var _moonscript2 = _interopRequireDefault(_moonscript);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _moonscript2.default;