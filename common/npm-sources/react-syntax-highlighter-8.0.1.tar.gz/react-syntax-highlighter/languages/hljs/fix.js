"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _fix = require("highlight.js/lib/languages/fix");

var _fix2 = _interopRequireDefault(_fix);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _fix2.default;