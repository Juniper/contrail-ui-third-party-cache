"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stata = require("highlight.js/lib/languages/stata");

var _stata2 = _interopRequireDefault(_stata);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _stata2.default;