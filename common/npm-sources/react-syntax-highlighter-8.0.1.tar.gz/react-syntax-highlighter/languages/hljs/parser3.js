"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _parser = require("highlight.js/lib/languages/parser3");

var _parser2 = _interopRequireDefault(_parser);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _parser2.default;