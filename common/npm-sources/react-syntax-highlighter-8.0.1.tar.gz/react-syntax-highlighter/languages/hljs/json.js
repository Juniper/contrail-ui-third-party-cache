"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _json = require("highlight.js/lib/languages/json");

var _json2 = _interopRequireDefault(_json);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _json2.default;