"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dart = require("highlight.js/lib/languages/dart");

var _dart2 = _interopRequireDefault(_dart);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _dart2.default;