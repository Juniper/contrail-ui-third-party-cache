"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stan = require("highlight.js/lib/languages/stan");

var _stan2 = _interopRequireDefault(_stan);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _stan2.default;