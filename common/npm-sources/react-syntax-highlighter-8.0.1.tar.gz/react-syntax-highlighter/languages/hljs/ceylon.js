"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ceylon = require("highlight.js/lib/languages/ceylon");

var _ceylon2 = _interopRequireDefault(_ceylon);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _ceylon2.default;