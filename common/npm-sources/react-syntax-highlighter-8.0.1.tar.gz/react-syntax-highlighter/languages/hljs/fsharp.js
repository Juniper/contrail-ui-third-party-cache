"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _fsharp = require("highlight.js/lib/languages/fsharp");

var _fsharp2 = _interopRequireDefault(_fsharp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _fsharp2.default;