"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _xml = require("highlight.js/lib/languages/xml");

var _xml2 = _interopRequireDefault(_xml);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _xml2.default;