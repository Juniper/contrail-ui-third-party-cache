"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _haxe = require("highlight.js/lib/languages/haxe");

var _haxe2 = _interopRequireDefault(_haxe);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _haxe2.default;