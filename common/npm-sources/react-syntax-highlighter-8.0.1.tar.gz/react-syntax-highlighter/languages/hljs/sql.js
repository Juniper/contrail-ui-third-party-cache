"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _sql = require("highlight.js/lib/languages/sql");

var _sql2 = _interopRequireDefault(_sql);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _sql2.default;