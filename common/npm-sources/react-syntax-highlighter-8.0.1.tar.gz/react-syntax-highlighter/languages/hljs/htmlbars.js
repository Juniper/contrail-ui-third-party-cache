"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _htmlbars = require("highlight.js/lib/languages/htmlbars");

var _htmlbars2 = _interopRequireDefault(_htmlbars);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _htmlbars2.default;