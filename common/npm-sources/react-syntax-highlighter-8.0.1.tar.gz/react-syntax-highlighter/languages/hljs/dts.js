"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dts = require("highlight.js/lib/languages/dts");

var _dts2 = _interopRequireDefault(_dts);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _dts2.default;