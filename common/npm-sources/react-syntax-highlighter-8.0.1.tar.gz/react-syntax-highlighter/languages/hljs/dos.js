"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dos = require("highlight.js/lib/languages/dos");

var _dos2 = _interopRequireDefault(_dos);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _dos2.default;