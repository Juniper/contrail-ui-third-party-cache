"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vbscriptHtml = require("highlight.js/lib/languages/vbscript-html");

var _vbscriptHtml2 = _interopRequireDefault(_vbscriptHtml);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _vbscriptHtml2.default;