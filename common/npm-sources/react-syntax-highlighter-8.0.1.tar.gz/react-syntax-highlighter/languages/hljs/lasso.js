"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lasso = require("highlight.js/lib/languages/lasso");

var _lasso2 = _interopRequireDefault(_lasso);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _lasso2.default;