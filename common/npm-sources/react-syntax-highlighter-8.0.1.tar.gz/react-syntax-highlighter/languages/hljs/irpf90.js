"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _irpf = require("highlight.js/lib/languages/irpf90");

var _irpf2 = _interopRequireDefault(_irpf);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _irpf2.default;