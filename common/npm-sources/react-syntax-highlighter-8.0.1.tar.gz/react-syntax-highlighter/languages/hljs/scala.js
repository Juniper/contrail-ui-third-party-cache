"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scala = require("highlight.js/lib/languages/scala");

var _scala2 = _interopRequireDefault(_scala);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _scala2.default;