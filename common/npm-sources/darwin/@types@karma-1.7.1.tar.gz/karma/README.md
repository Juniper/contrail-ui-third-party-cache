# Installation
> `npm install --save @types/karma`

# Summary
This package contains type definitions for karma (https://github.com/karma-runner/karma).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/karma

Additional Details
 * Last updated: Tue, 17 Oct 2017 00:14:44 GMT
 * Dependencies: bluebird, https, node
 * Global values: none

# Credits
These definitions were written by Tanguy Krotoff <https://github.com/tkrotoff>.
