# Installation
> `npm install --save @types/react-hot-loader`

# Summary
This package contains type definitions for react-hot-loader (https://github.com/gaearon/react-hot-loader).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-hot-loader

Additional Details
 * Last updated: Wed, 25 Oct 2017 16:18:56 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Jacek Jagiello <https://github.com/jacekjagiello>.
