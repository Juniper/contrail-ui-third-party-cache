# Installation
> `npm install --save @types/keymirror`

# Summary
This package contains type definitions for keymirror (https://github.com/STRML/keyMirror).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/keymirror

Additional Details
 * Last updated: Tue, 10 Jan 2017 19:37:48 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Johannes Fahrenkrug <https://github.com/jfahrenkrug>.
