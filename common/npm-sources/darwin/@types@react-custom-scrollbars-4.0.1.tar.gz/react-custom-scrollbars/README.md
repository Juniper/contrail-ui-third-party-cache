# Installation
> `npm install --save @types/react-custom-scrollbars`

# Summary
This package contains type definitions for react-custom-scrollbars (https://github.com/malte-wessel/react-custom-scrollbars).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-custom-scrollbars

Additional Details
 * Last updated: Fri, 23 Jun 2017 17:35:05 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by  David-LeBlanc-git <https://github.com/David-LeBlanc-git>, kittimiyo <https://github.com/kittimiyo>.
