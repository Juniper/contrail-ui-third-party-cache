import { sortedLastIndexBy } from "./index";
export = sortedLastIndexBy;
