import { sum } from "./index";
export = sum;
