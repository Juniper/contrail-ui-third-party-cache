import { every } from "./index";
export = every;
