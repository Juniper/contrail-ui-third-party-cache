import { isEmpty } from "./index";
export = isEmpty;
