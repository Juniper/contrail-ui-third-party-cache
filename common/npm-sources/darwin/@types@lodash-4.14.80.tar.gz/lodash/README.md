# Installation
> `npm install --save @types/lodash`

# Summary
This package contains type definitions for Lo-Dash (http://lodash.com/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash

Additional Details
 * Last updated: Wed, 25 Oct 2017 18:50:12 GMT
 * Dependencies: none
 * Global values: _

# Credits
These definitions were written by Brian Zengel <https://github.com/bczengel>, Ilya Mochalov <https://github.com/chrootsu>, Stepan Mikhaylyuk <https://github.com/stepancar>, Eric L Anderson <https://github.com/ericanderson>, AJ Richardson <https://github.com/aj-r>, Junyoung Clare Jang <https://github.com/ailrun>, e-cloud <https://github.com/e-cloud>, Georgii Dolzhykov <https://github.com/thorn0>.
