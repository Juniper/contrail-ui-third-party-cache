import { toLength } from "./index";
export = toLength;
