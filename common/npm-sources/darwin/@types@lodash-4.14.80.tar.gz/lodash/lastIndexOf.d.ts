import { lastIndexOf } from "./index";
export = lastIndexOf;
