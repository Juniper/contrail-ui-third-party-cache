import { pullAt } from "./index";
export = pullAt;
