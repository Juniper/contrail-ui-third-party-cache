import { mixin } from "./index";
export = mixin;
