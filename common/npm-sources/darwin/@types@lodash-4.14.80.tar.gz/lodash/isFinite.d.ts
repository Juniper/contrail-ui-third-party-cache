import { isFinite } from "./index";
export = isFinite;
