import { sampleSize } from "./index";
export = sampleSize;
