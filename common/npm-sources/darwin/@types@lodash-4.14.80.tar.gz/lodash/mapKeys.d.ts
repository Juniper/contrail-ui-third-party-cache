import { mapKeys } from "./index";
export = mapKeys;
