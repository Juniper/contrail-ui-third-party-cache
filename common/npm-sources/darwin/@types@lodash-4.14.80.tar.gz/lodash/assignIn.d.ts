import { assignIn } from "./index";
export = assignIn;
