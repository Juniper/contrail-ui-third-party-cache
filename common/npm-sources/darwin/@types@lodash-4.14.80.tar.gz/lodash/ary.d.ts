import { ary } from "./index";
export = ary;
