# Installation
> `npm install --save @types/html-webpack-plugin`

# Summary
This package contains type definitions for html-webpack-plugin (https://github.com/ampedandwired/html-webpack-plugin).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/html-webpack-plugin

Additional Details
 * Last updated: Thu, 13 Apr 2017 16:00:22 GMT
 * Dependencies: webpack, html-minifier
 * Global values: none

# Credits
These definitions were written by Simon Hartcher <https://github.com/deevus>, Benjamin Lim <https://github.com/bumbleblym>.
