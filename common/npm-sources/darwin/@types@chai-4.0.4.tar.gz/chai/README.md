# Installation
> `npm install --save @types/chai`

# Summary
This package contains type definitions for chai (http://chaijs.com/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/chai

Additional Details
 * Last updated: Mon, 21 Aug 2017 21:49:18 GMT
 * Dependencies: none
 * Global values: Chai, chai

# Credits
These definitions were written by Jed Mao <https://github.com/jedmao>, Bart van der Schoor <https://github.com/Bartvds>, Andrew Brown <https://github.com/AGBrown>, Olivier Chevet <https://github.com/olivr70>, Matt Wistrand <https://github.com/mwistrand>, Josh Goldberg <https://github.com/joshuakgoldberg>, Shaun Luttin <https://github.com/shaunluttin>.
