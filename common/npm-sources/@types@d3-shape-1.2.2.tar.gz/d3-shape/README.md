# Installation
> `npm install --save @types/d3-shape`

# Summary
This package contains type definitions for D3JS d3-shape module (https://github.com/d3/d3-shape/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-shape

Additional Details
 * Last updated: Thu, 01 Feb 2018 18:55:41 GMT
 * Dependencies: d3-path
 * Global values: none

# Credits
These definitions were written by Tom Wanzek <https://github.com/tomwanzek>, Alex Ford <https://github.com/gustavderdrache>, Boris Yankov <https://github.com/borisyankov>.
