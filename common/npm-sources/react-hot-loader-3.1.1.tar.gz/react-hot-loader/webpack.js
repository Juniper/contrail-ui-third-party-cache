module.exports = require('./lib/webpack')
