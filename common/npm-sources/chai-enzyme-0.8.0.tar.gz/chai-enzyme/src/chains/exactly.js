export default function exactly ({ flag, arg1 }) {
  flag(this, 'exactlyCount', arg1)
}
