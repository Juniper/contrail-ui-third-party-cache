# Installation
> `npm install --save @types/vis`

# Summary
This package contains type definitions for vis.js (https://github.com/almende/vis).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped.git/tree/master/types/vis

Additional Details
 * Last updated: Tue, 08 May 2018 17:01:00 GMT
 * Dependencies: moment
 * Global values: vis

# Credits
These definitions were written by Michaël Bitard <https://github.com/MichaelBitard>, MacLeod Broad <https://github.com/macleodbroad-wf>, Adrian Caballero <https://github.com/adripanico>, Severin <https://github.com/seveves>, kaktus40 <https://github.com/kaktus40>, Matthieu Maitre <https://github.com/mmaitre314>, Adam Lewis <https://github.com/supercargo>, Alex Soh <https://github.com/takato1314>.
