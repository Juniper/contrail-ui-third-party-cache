import { Col } from '../grid';
export default Col;
