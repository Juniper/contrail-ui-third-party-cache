/// <reference types="react" />
import React from 'react';
export default class Item extends React.Component<any, any> {
    shouldComponentUpdate(...args: any[]): any;
    render(): JSX.Element;
}
