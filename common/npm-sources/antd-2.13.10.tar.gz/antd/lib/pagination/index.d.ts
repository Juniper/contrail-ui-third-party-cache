import Pagination from './Pagination';
export { PaginationProps } from './Pagination';
export default Pagination;
