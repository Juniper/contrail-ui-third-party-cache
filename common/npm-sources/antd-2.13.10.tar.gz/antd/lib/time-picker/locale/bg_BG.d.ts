declare const locale: {
    placeholder: string;
};
export default locale;
