/**
 * Created by Andrey Gayvoronsky on 13/04/16.
 */
declare const locale: {
    placeholder: string;
};
export default locale;
