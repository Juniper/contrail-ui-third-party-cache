declare var _default: "2.13.10";
export default _default;
