import es_ES from '../../date-picker/locale/es_ES';
export default es_ES;
