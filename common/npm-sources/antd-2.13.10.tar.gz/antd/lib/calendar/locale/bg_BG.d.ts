import bg_BG from '../../date-picker/locale/bg_BG';
export default bg_BG;
