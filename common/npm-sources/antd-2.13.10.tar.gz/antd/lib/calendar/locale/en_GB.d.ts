import en_GB from '../../date-picker/locale/en_GB';
export default en_GB;
