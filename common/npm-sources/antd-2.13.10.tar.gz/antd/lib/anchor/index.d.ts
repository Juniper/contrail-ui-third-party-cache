import Anchor from './Anchor';
export default Anchor;
