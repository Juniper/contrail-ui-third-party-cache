# History

## 3.3.0

- Add `onClick` property.

## 3.2.0

- Add  `closeIcon`. [#45](https://github.com/react-component/notification/pull/45) [@HeskeyBaozi](https://github.com/HeskeyBaozi)

## 2.0.0

- [Beack Change] Remove wrapper span element when just single notification. [#17](https://github.com/react-component/notification/pull/17)

## 1.4.0

- Added `getContainer` property.
