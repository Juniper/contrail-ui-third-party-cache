"use strict";
/**
 * @license
 * Copyright 2017 Palantir Technologies, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Lint = require("tslint");
var tsutils_1 = require("tsutils");
var ts = require("typescript");
var Rule = (function (_super) {
    __extends(Rule, _super);
    function Rule() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Rule.prototype.apply = function (sourceFile) {
        return this.applyWithFunction(sourceFile, walk);
    };
    Rule.TRANSLATABLE_ATTRIBUTES = new Set(["placeholder", "title", "alt"]);
    Rule.FAILURE_STRING = "String literals are disallowed as JSX. Use a translation function";
    Rule.FAILURE_STRING_FACTORY = function (text) {
        return "String literal is not allowed for value of " + text + ". Use a translation function";
    };
    return Rule;
}(Lint.Rules.AbstractRule));
exports.Rule = Rule;
function walk(ctx) {
    return ts.forEachChild(ctx.sourceFile, function cb(node) {
        if (tsutils_1.isJsxElement(node)) {
            for (var _i = 0, _a = node.children; _i < _a.length; _i++) {
                var child = _a[_i];
                if (tsutils_1.isJsxText(child) && child.getText().trim() !== "") {
                    ctx.addFailureAtNode(child, Rule.FAILURE_STRING);
                }
                if (tsutils_1.isJsxExpression(child)
                    && child.expression !== undefined
                    && (tsutils_1.isStringLiteral(child.expression)
                        || child.expression.kind === ts.SyntaxKind.FirstTemplateToken)) {
                    ctx.addFailureAtNode(child, Rule.FAILURE_STRING);
                }
            }
        }
        else if (tsutils_1.isJsxAttribute(node)) {
            if (Rule.TRANSLATABLE_ATTRIBUTES.has(node.name.text) && node.initializer !== undefined) {
                if (tsutils_1.isStringLiteral(node.initializer)
                    || (tsutils_1.isJsxExpression(node.initializer) && tsutils_1.isStringLiteral(node.initializer.expression))) {
                    ctx.addFailureAtNode(node.initializer, Rule.FAILURE_STRING_FACTORY(node.name.text));
                }
            }
        }
        return ts.forEachChild(node, cb);
    });
}
