# Installation
> `npm install --save @types/react`

# Summary
This package contains type definitions for React (http://facebook.github.io/react/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react/v15

Additional Details
 * Last updated: Thu, 24 Aug 2017 17:15:34 GMT
 * Dependencies: none
 * Global values: React

# Credits
These definitions were written by Asana <https://asana.com>, AssureSign <http://www.assuresign.com>, Microsoft <https://microsoft.com>, John Reilly <https://github.com/johnnyreilly/>, Benoit Benezech <https://github.com/bbenezech>, Patricio Zavolinsky <https://github.com/pzavolinsky>, Digiguru <https://github.com/digiguru>, Eric Anderson <https://github.com/ericanderson>, Albert Kurniawan <https://github.com/morcerf>, Tanguy Krotoff <https://github.com/tkrotoff>, Dovydas Navickas <https://github.com/DovydasNavickas>, Stéphane Goetz <https://github.com/onigoetz>.
