# Installation
> `npm install --save @types/react-codemirror`

# Summary
This package contains type definitions for React Codemirror (https://github.com/JedWatson/react-codemirror).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-codemirror

Additional Details
 * Last updated: Wed, 09 Aug 2017 14:12:23 GMT
 * Dependencies: react, codemirror
 * Global values: none

# Credits
These definitions were written by Vicky Lai <https://github.com/velveret>, Rudi Chen <https://github.com/rudi-c>.
