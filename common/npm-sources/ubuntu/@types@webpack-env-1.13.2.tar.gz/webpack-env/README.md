# Installation
> `npm install --save @types/webpack-env`

# Summary
This package contains type definitions for webpack (module API) (https://github.com/webpack/webpack).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack-env

Additional Details
 * Last updated: Thu, 07 Sep 2017 22:03:13 GMT
 * Dependencies: none
 * Global values: DEBUG, ___non_webpack_require__, ___resourceQuery, ___webpack_chunk_load__, ___webpack_hash__, ___webpack_modules__, ___webpack_public_path__, ___webpack_require__, module, require

# Credits
These definitions were written by use-strict <https://github.com/use-strict>, rhonsby <https://github.com/rhonsby>.
