# Installation
> `npm install --save @types/react-dom`

# Summary
This package contains type definitions for React (react-dom) (http://facebook.github.io/react/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-dom

Additional Details
 * Last updated: Tue, 26 Sep 2017 23:00:44 GMT
 * Dependencies: react
 * Global values: ReactDOM, ReactDOMNodeStream, ReactDOMServer

# Credits
These definitions were written by Asana <https://asana.com>, AssureSign <http://www.assuresign.com>, Microsoft <https://microsoft.com>, MartynasZilinskas <https://github.com/MartynasZilinskas>.
