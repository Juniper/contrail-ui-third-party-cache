# Installation
> `npm install --save @types/classnames`

# Summary
This package contains type definitions for classnames (https://github.com/JedWatson/classnames).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/classnames

Additional Details
 * Last updated: Mon, 21 Aug 2017 21:49:18 GMT
 * Dependencies: none
 * Global values: classNames

# Credits
These definitions were written by Dave Keen <http://www.keendevelopment.ch>, Adi Dahiya <https://github.com/adidahiya>, Jason Killian <https://github.com/JKillian>, Sean Kelley <https://github.com/seansfkelley>, Michal Adamczyk <https://github.com/mradamczyk>, Marvin Hagemeister <https://github.com/marvinhagemeister>.
