import * as cn from "./index";

export function bind(styles: Record<string, string>): typeof cn;
