import { v1 } from './interfaces';

declare const v1: v1;

export = v1;
