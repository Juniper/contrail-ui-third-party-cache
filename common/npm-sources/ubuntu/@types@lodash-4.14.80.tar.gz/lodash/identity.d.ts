import { identity } from "./index";
export = identity;
