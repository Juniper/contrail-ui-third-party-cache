import { isLength } from "./index";
export = isLength;
