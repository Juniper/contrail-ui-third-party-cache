import { xorWith } from "./index";
export = xorWith;
