import { overSome } from "./index";
export = overSome;
