import { invertBy } from "./index";
export = invertBy;
