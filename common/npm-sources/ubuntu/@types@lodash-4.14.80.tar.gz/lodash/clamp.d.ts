import { clamp } from "./index";
export = clamp;
