import { shuffle } from "./index";
export = shuffle;
