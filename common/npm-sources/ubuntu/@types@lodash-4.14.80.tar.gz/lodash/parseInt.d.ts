import { parseInt } from "./index";
export = parseInt;
