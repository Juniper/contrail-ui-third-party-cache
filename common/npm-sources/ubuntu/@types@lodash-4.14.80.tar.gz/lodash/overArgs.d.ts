import { overArgs } from "./index";
export = overArgs;
