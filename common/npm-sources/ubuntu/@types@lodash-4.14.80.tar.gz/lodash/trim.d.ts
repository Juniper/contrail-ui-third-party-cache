import { trim } from "./index";
export = trim;
