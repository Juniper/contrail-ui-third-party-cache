import { omitBy } from "./index";
export = omitBy;
