import { toPairs } from "./index";
export = toPairs;
