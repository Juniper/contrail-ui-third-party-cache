import { property } from "./index";
export = property;
