import { padEnd } from "./index";
export = padEnd;
