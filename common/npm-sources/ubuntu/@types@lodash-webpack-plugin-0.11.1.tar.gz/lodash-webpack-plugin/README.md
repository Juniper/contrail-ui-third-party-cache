# Installation
> `npm install --save @types/lodash-webpack-plugin`

# Summary
This package contains type definitions for lodash-webpack-plugin (https://github.com/lodash/lodash-webpack-plugin#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/lodash-webpack-plugin

Additional Details
 * Last updated: Tue, 07 Feb 2017 20:53:01 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by Benjamin Lim <https://github.com/bumbleblym>.
