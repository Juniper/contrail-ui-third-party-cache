# Installation
> `npm install --save @types/extract-text-webpack-plugin`

# Summary
This package contains type definitions for extract-text-webpack-plugin (https://github.com/webpack-contrib/extract-text-webpack-plugin).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/extract-text-webpack-plugin

Additional Details
 * Last updated: Mon, 22 May 2017 22:16:25 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by flying-sheep <https://github.com/flying-sheep>, kayo <https://github.com/katyo>.
