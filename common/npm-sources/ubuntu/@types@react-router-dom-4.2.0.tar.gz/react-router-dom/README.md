# Installation
> `npm install --save @types/react-router-dom`

# Summary
This package contains type definitions for React Router (https://github.com/ReactTraining/react-router).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-router-dom

Additional Details
 * Last updated: Tue, 26 Sep 2017 00:11:47 GMT
 * Dependencies: react-router, react, history
 * Global values: none

# Credits
These definitions were written by Tanguy Krotoff <https://github.com/tkrotoff>, Huy Nguyen <https://github.com/huy-nguyen>.
