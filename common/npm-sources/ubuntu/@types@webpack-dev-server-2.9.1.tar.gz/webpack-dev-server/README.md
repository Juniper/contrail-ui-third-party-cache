# Installation
> `npm install --save @types/webpack-dev-server`

# Summary
This package contains type definitions for webpack-dev-server (https://github.com/webpack/webpack-dev-server).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack-dev-server

Additional Details
 * Last updated: Mon, 09 Oct 2017 23:30:01 GMT
 * Dependencies: webpack, express-serve-static-core, serve-static, http, spdy, http-proxy-middleware
 * Global values: none

# Credits
These definitions were written by maestroh <https://github.com/maestroh>, Dave Parslow <https://github.com/daveparslow>, Zheyang Song <https://github.com/ZheyangSong>.
