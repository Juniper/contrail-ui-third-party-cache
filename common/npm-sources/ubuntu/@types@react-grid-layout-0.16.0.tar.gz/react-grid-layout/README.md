# Installation
> `npm install --save @types/react-grid-layout`

# Summary
This package contains type definitions for react-grid-layout (https://github.com/STRML/react-grid-layout).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-grid-layout

Additional Details
 * Last updated: Mon, 09 Oct 2017 21:51:29 GMT
 * Dependencies: react
 * Global values: ReactGridLayout

# Credits
These definitions were written by Andrew Birkholz <https://github.com/abirkholz>, Ali Taheri <https://github.com/alitaheri>, Zheyang Song <https://github.com/ZheyangSong>, Andrew Hathaway <https://github.com/andrewhathaway>.
