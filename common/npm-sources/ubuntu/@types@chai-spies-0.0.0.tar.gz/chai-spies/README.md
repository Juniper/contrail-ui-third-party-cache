# Installation
> `npm install --save @types/chai-spies`

# Summary
This package contains type definitions for chai-spies (https://github.com/chaijs/chai-spies).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/chai-spies

Additional Details
 * Last updated: Tue, 08 Nov 2016 15:08:59 GMT
 * File structure: Mixed
 * Library Dependencies: chai
 * Module Dependencies: none
 * Global values: spies

# Credits
These definitions were written by Ilya Kuznetsov <https://github.com/kuzn-ilya>.
