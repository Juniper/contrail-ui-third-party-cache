# Installation
> `npm install --save @types/webpack-dev-middleware`

# Summary
This package contains type definitions for webpack-dev-middleware (https://github.com/webpack/webpack-dev-middleware).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack-dev-middleware

Additional Details
 * Last updated: Mon, 21 Aug 2017 22:03:22 GMT
 * Dependencies: connect, webpack
 * Global values: none

# Credits
These definitions were written by Benjamin Lim <https://github.com/bumbleblym>.
