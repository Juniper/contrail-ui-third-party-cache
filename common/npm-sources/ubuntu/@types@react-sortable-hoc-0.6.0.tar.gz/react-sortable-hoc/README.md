# Installation
> `npm install --save @types/react-sortable-hoc`

# Summary
This package contains type definitions for nes (https://github.com/clauderic/react-sortable-hoc).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-sortable-hoc

Additional Details
 * Last updated: Tue, 27 Jun 2017 13:51:11 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Ivo Stratev <https://github.com/NoHomey>, Charles Rey <https://github.com/charlesrey>.
