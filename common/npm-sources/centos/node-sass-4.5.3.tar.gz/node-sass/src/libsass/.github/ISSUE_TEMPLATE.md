### Title: Be as meaningful as possible in 60 chars if possible

input.scss
```scss
test {
  content: bar
}
```

[libsass 3.5.5] [1]
```css
test {
  content: bar; }
```

ruby sass 3.4.21
```css
test {
  content: bar; }
```

version info:
```cmd
$ node-sass --version
node-sass       3.3.3   (Wrapper)       [JavaScript]
libsass         3.2.5   (Sass Compiler) [C/C++]
```

[1]: http://libsass.ocbnet.ch/srcmap/#dGVzdCB7CiAgY29udGVudDogYmFyOyB9Cg==
