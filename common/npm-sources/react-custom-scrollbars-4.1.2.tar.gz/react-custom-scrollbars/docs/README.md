# Table of Contents

* [Usage](usage.md)
  * [Auto hide](usage.md#auto-hide)
  * [Auto height](usage.md#auto-height)
  * [Working with events](usage.md#events)
  * [Universal rendering](usage.md#universal-rendering)
* [Customization](customization.md)
* [API](API.md)

## Older versions
* [Upgrade guide from v2.x to v3.x](upgrade-guide-v2-v3.md)
* [v2.x documentation](v2-documentation.md)
