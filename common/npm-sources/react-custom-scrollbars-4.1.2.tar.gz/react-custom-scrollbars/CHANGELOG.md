# Change log

This project adheres to [Semantic Versioning](http://semver.org/).

[Have a look at the releases](https://github.com/malte-wessel/react-custom-scrollbars/releases)
