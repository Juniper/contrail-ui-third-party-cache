import postcssAttributeCaseInsensitive from 'postcss-attribute-case-insensitive';
import postcssColorFunctionalNotation from 'postcss-color-functional-notation';
import postcssColorHexAlpha from 'postcss-color-hex-alpha';
import postcssColorModFunction from 'postcss-color-mod-function';
import postcssColorRebeccapurple from 'postcss-color-rebeccapurple';
import postcssCustomMedia from 'postcss-custom-media';
import postcssCustomProperties from 'postcss-custom-properties';
import postcssCustomSelectors from 'postcss-custom-selectors';
import postcssDirPseudoClass from 'postcss-dir-pseudo-class';
import postcssFocusVisible from 'postcss-focus-visible';
import postcssFocusWithin from 'postcss-focus-within';
import postcssFontVariant from 'postcss-font-variant';
import postcssFontFamilySystemUi from 'postcss-font-family-system-ui';
import postcssGapProperties from 'postcss-gap-properties';
import postcssImageSetPolyfill from 'postcss-image-set-function';
import postcssInitial from 'postcss-initial';
import postcssLabFunction from 'postcss-lab-function';
import postcssLogical from 'postcss-logical';
import postcssMediaMinmax from 'postcss-media-minmax';
import postcssNesting from 'postcss-nesting';
import postcssOverflowShorthand from 'postcss-overflow-shorthand';
import postcssPageBreak from 'postcss-page-break';
import postcssPlace from 'postcss-place';
import postcssPseudoClassAnyLink from 'postcss-pseudo-class-any-link';
import postcssReplaceOverflowWrap from 'postcss-replace-overflow-wrap';
import postcssSelectorMatches from 'postcss-selector-matches';
import postcssSelectorNot from 'postcss-selector-not';
import { features, feature } from 'caniuse-lite';
import autoprefixer from 'autoprefixer';
import browserslist from 'browserslist';
import cssdb from 'cssdb';
import postcss from 'postcss';

// postcss plugins ordered by id
var plugins = {
	'all-property': postcssInitial,
	'any-link-pseudo-class': postcssPseudoClassAnyLink,
	'break-properties': postcssPageBreak,
	'case-insensitive-attributes': postcssAttributeCaseInsensitive,
	'color-functional-notation': postcssColorFunctionalNotation,
	'color-mod-function': postcssColorModFunction,
	'custom-media-queries': postcssCustomMedia,
	'custom-properties': postcssCustomProperties,
	'custom-selectors': postcssCustomSelectors,
	'dir-pseudo-class': postcssDirPseudoClass,
	'focus-visible-pseudo-class': postcssFocusVisible,
	'focus-within-pseudo-class': postcssFocusWithin,
	'font-variant-property': postcssFontVariant,
	'gap-properties': postcssGapProperties,
	'hexadecimal-alpha-notation': postcssColorHexAlpha,
	'image-set-function': postcssImageSetPolyfill,
	'lab-function': postcssLabFunction,
	'logical-properties-and-values': postcssLogical,
	'matches-pseudo-class': postcssSelectorMatches,
	'media-query-ranges': postcssMediaMinmax,
	'nesting-rules': postcssNesting,
	'not-pseudo-class': postcssSelectorNot,
	'overflow-property': postcssOverflowShorthand,
	'overflow-wrap-property': postcssReplaceOverflowWrap,
	'place-properties': postcssPlace,
	'rebeccapurple-color': postcssColorRebeccapurple,
	'system-ui-font-family': postcssFontFamilySystemUi
};

// return a list of features to be inserted before or after cssdb features
function getTransformedInsertions(insertions, placement) {
	return Object.keys(insertions).map(function (id) {
		return [].concat(insertions[id]).map(function (plugin) {
			return {
				[placement]: true,
				plugin,
				id
			};
		});
	}).reduce(function (array, feature$$1) {
		return array.concat(feature$$1);
	}, []);
}

// return a list of browsers that do not support the feature
function getUnsupportedBrowsersByFeature(feature$$1) {
	var caniuseFeature = features[feature$$1];

	// if feature support can be determined
	if (caniuseFeature) {
		var stats = feature(caniuseFeature).stats;

		// return an array of browsers and versions that do not support the feature
		var results = Object.keys(stats).reduce(function (browsers, browser) {
			return browsers.concat(Object.keys(stats[browser]).filter(function (version) {
				return stats[browser][version].indexOf('y') !== 0;
			}).map(function (version) {
				return `${browser} ${version}`;
			}));
		}, []);

		return results;
	} else {
		// otherwise, return that the feature does not work in any browser
		return ['> 0%'];
	}
}

// ids ordered by execution
var idsByExecutionOrder = ['custom-properties', 'custom-property-sets', 'image-set-function', 'logical-properties-and-values', 'nesting-rules', 'custom-media-queries', 'media-query-ranges', 'custom-selectors', 'case-insensitive-attributes', 'rebeccapurple-color', 'hexadecimal-alpha-notation', 'lab-function', 'color-mod-function', 'color-functional-notation', 'system-ui-font-family', 'font-variant-property', 'all-property', 'matches-pseudo-class', 'not-pseudo-class', 'any-link-pseudo-class', 'dir-pseudo-class', 'break-properties', 'gap-properties', 'overflow-property', 'overflow-wrap-property', 'place-properties', 'focus-visible-pseudo-class', 'focus-within-pseudo-class'];

var index = postcss.plugin('postcss-preset-env', function (opts) {
	// initialize options
	var features$$1 = Object(Object(opts).features);
	var insertBefore = Object(Object(opts).insertBefore);
	var insertAfter = Object(Object(opts).insertAfter);
	var browsers = Object(opts).browsers;
	var stage = 'stage' in Object(opts) ? opts.stage === false ? 5 : parseInt(opts.stage) || 0 : 2;
	var autoprefixerOptions = Object(opts).autoprefixer;

	var stagedAutoprefixer = autoprefixer(Object.assign({ browsers }, autoprefixerOptions));

	// polyfillable features (those with an available postcss plugin)
	var polyfillableFeatures = cssdb.concat(
	// additional features to be inserted before cssdb features
	getTransformedInsertions(insertBefore, 'insertBefore'),
	// additional features to be inserted after cssdb features
	getTransformedInsertions(insertAfter, 'insertAfter')).filter(
	// inserted features or features with an available postcss plugin
	function (feature$$1) {
		return feature$$1.insertBefore || feature$$1.id in plugins;
	}).sort(
	// features sorted by execution order and then insertion order
	function (a, b) {
		return idsByExecutionOrder.indexOf(a.id) - idsByExecutionOrder.indexOf(b.id) || (a.insertBefore ? -1 : b.insertBefore ? 1 : 0) || (a.insertAfter ? 1 : b.insertAfter ? -1 : 0);
	}).map(
	// polyfillable features as an object
	function (feature$$1) {
		// target browsers for the polyfill
		var unsupportedBrowsers = getUnsupportedBrowsersByFeature(feature$$1.caniuse);

		return feature$$1.insertBefore || feature$$1.insertAfter ? {
			browsers: unsupportedBrowsers,
			plugin: feature$$1.plugin,
			id: `${feature$$1.insertBefore ? 'before' : 'after'}-${feature$$1.id}`,
			stage: 6
		} : {
			browsers: unsupportedBrowsers,
			plugin: plugins[feature$$1.id],
			id: feature$$1.id,
			stage: feature$$1.stage
		};
	});

	// staged features (those at or above the selected stage)
	var stagedFeatures = polyfillableFeatures.filter(function (feature$$1) {
		return feature$$1.id in features$$1 ? features$$1[feature$$1.id] : feature$$1.stage >= stage;
	}).map(function (feature$$1) {
		return {
			browsers: feature$$1.browsers,
			plugin: typeof feature$$1.plugin.process === 'function' ? features$$1[feature$$1.id] === true ? feature$$1.plugin() : feature$$1.plugin(features$$1[feature$$1.id]) : feature$$1.plugin,
			id: feature$$1.id
		};
	});

	return function (root, result) {
		// browsers supported by the configuration
		var supportedBrowsers = browserslist(browsers, {
			path: result.root.source && result.root.source.input && result.root.source.input.file,
			ignoreUnknownVersions: true
		});

		// features supported by the stage and browsers
		var supportedFeatures = stagedFeatures.filter(function (feature$$1) {
			return supportedBrowsers.some(function (supportedBrowser) {
				return browserslist(feature$$1.browsers, {
					ignoreUnknownVersions: true
				}).some(function (polyfillBrowser) {
					return polyfillBrowser === supportedBrowser;
				});
			});
		});

		// polyfills run in execution order
		var polyfills = supportedFeatures.reduce(function (promise, feature$$1) {
			return promise.then(function () {
				return feature$$1.plugin(result.root, result);
			});
		}, Promise.resolve()).then(function () {
			return stagedAutoprefixer(result.root, result);
		});

		return polyfills;
	};
});

export default index;
