'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var postcssAttributeCaseInsensitive = _interopDefault(require('postcss-attribute-case-insensitive'));
var postcssColorFunctionalNotation = _interopDefault(require('postcss-color-functional-notation'));
var postcssColorHexAlpha = _interopDefault(require('postcss-color-hex-alpha'));
var postcssColorModFunction = _interopDefault(require('postcss-color-mod-function'));
var postcssColorRebeccapurple = _interopDefault(require('postcss-color-rebeccapurple'));
var postcssCustomMedia = _interopDefault(require('postcss-custom-media'));
var postcssCustomProperties = _interopDefault(require('postcss-custom-properties'));
var postcssCustomSelectors = _interopDefault(require('postcss-custom-selectors'));
var postcssDirPseudoClass = _interopDefault(require('postcss-dir-pseudo-class'));
var postcssFocusVisible = _interopDefault(require('postcss-focus-visible'));
var postcssFocusWithin = _interopDefault(require('postcss-focus-within'));
var postcssFontVariant = _interopDefault(require('postcss-font-variant'));
var postcssFontFamilySystemUi = _interopDefault(require('postcss-font-family-system-ui'));
var postcssGapProperties = _interopDefault(require('postcss-gap-properties'));
var postcssImageSetPolyfill = _interopDefault(require('postcss-image-set-function'));
var postcssInitial = _interopDefault(require('postcss-initial'));
var postcssLabFunction = _interopDefault(require('postcss-lab-function'));
var postcssLogical = _interopDefault(require('postcss-logical'));
var postcssMediaMinmax = _interopDefault(require('postcss-media-minmax'));
var postcssNesting = _interopDefault(require('postcss-nesting'));
var postcssOverflowShorthand = _interopDefault(require('postcss-overflow-shorthand'));
var postcssPageBreak = _interopDefault(require('postcss-page-break'));
var postcssPlace = _interopDefault(require('postcss-place'));
var postcssPseudoClassAnyLink = _interopDefault(require('postcss-pseudo-class-any-link'));
var postcssReplaceOverflowWrap = _interopDefault(require('postcss-replace-overflow-wrap'));
var postcssSelectorMatches = _interopDefault(require('postcss-selector-matches'));
var postcssSelectorNot = _interopDefault(require('postcss-selector-not'));
var caniuse = require('caniuse-lite');
var autoprefixer = _interopDefault(require('autoprefixer'));
var browserslist = _interopDefault(require('browserslist'));
var cssdb = _interopDefault(require('cssdb'));
var postcss = _interopDefault(require('postcss'));

// postcss plugins ordered by id
var plugins = {
	'all-property': postcssInitial,
	'any-link-pseudo-class': postcssPseudoClassAnyLink,
	'break-properties': postcssPageBreak,
	'case-insensitive-attributes': postcssAttributeCaseInsensitive,
	'color-functional-notation': postcssColorFunctionalNotation,
	'color-mod-function': postcssColorModFunction,
	'custom-media-queries': postcssCustomMedia,
	'custom-properties': postcssCustomProperties,
	'custom-selectors': postcssCustomSelectors,
	'dir-pseudo-class': postcssDirPseudoClass,
	'focus-visible-pseudo-class': postcssFocusVisible,
	'focus-within-pseudo-class': postcssFocusWithin,
	'font-variant-property': postcssFontVariant,
	'gap-properties': postcssGapProperties,
	'hexadecimal-alpha-notation': postcssColorHexAlpha,
	'image-set-function': postcssImageSetPolyfill,
	'lab-function': postcssLabFunction,
	'logical-properties-and-values': postcssLogical,
	'matches-pseudo-class': postcssSelectorMatches,
	'media-query-ranges': postcssMediaMinmax,
	'nesting-rules': postcssNesting,
	'not-pseudo-class': postcssSelectorNot,
	'overflow-property': postcssOverflowShorthand,
	'overflow-wrap-property': postcssReplaceOverflowWrap,
	'place-properties': postcssPlace,
	'rebeccapurple-color': postcssColorRebeccapurple,
	'system-ui-font-family': postcssFontFamilySystemUi
};

// return a list of features to be inserted before or after cssdb features
function getTransformedInsertions(insertions, placement) {
	return Object.keys(insertions).map(function (id) {
		return [].concat(insertions[id]).map(function (plugin) {
			return {
				[placement]: true,
				plugin,
				id
			};
		});
	}).reduce(function (array, feature) {
		return array.concat(feature);
	}, []);
}

// return a list of browsers that do not support the feature
function getUnsupportedBrowsersByFeature(feature) {
	var caniuseFeature = caniuse.features[feature];

	// if feature support can be determined
	if (caniuseFeature) {
		var stats = caniuse.feature(caniuseFeature).stats;

		// return an array of browsers and versions that do not support the feature
		var results = Object.keys(stats).reduce(function (browsers, browser) {
			return browsers.concat(Object.keys(stats[browser]).filter(function (version) {
				return stats[browser][version].indexOf('y') !== 0;
			}).map(function (version) {
				return `${browser} ${version}`;
			}));
		}, []);

		return results;
	} else {
		// otherwise, return that the feature does not work in any browser
		return ['> 0%'];
	}
}

// ids ordered by execution
var idsByExecutionOrder = ['custom-properties', 'custom-property-sets', 'image-set-function', 'logical-properties-and-values', 'nesting-rules', 'custom-media-queries', 'media-query-ranges', 'custom-selectors', 'case-insensitive-attributes', 'rebeccapurple-color', 'hexadecimal-alpha-notation', 'lab-function', 'color-mod-function', 'color-functional-notation', 'system-ui-font-family', 'font-variant-property', 'all-property', 'matches-pseudo-class', 'not-pseudo-class', 'any-link-pseudo-class', 'dir-pseudo-class', 'break-properties', 'gap-properties', 'overflow-property', 'overflow-wrap-property', 'place-properties', 'focus-visible-pseudo-class', 'focus-within-pseudo-class'];

var index = postcss.plugin('postcss-preset-env', function (opts) {
	// initialize options
	var features = Object(Object(opts).features);
	var insertBefore = Object(Object(opts).insertBefore);
	var insertAfter = Object(Object(opts).insertAfter);
	var browsers = Object(opts).browsers;
	var stage = 'stage' in Object(opts) ? opts.stage === false ? 5 : parseInt(opts.stage) || 0 : 2;
	var autoprefixerOptions = Object(opts).autoprefixer;

	var stagedAutoprefixer = autoprefixer(Object.assign({ browsers }, autoprefixerOptions));

	// polyfillable features (those with an available postcss plugin)
	var polyfillableFeatures = cssdb.concat(
	// additional features to be inserted before cssdb features
	getTransformedInsertions(insertBefore, 'insertBefore'),
	// additional features to be inserted after cssdb features
	getTransformedInsertions(insertAfter, 'insertAfter')).filter(
	// inserted features or features with an available postcss plugin
	function (feature) {
		return feature.insertBefore || feature.id in plugins;
	}).sort(
	// features sorted by execution order and then insertion order
	function (a, b) {
		return idsByExecutionOrder.indexOf(a.id) - idsByExecutionOrder.indexOf(b.id) || (a.insertBefore ? -1 : b.insertBefore ? 1 : 0) || (a.insertAfter ? 1 : b.insertAfter ? -1 : 0);
	}).map(
	// polyfillable features as an object
	function (feature) {
		// target browsers for the polyfill
		var unsupportedBrowsers = getUnsupportedBrowsersByFeature(feature.caniuse);

		return feature.insertBefore || feature.insertAfter ? {
			browsers: unsupportedBrowsers,
			plugin: feature.plugin,
			id: `${feature.insertBefore ? 'before' : 'after'}-${feature.id}`,
			stage: 6
		} : {
			browsers: unsupportedBrowsers,
			plugin: plugins[feature.id],
			id: feature.id,
			stage: feature.stage
		};
	});

	// staged features (those at or above the selected stage)
	var stagedFeatures = polyfillableFeatures.filter(function (feature) {
		return feature.id in features ? features[feature.id] : feature.stage >= stage;
	}).map(function (feature) {
		return {
			browsers: feature.browsers,
			plugin: typeof feature.plugin.process === 'function' ? features[feature.id] === true ? feature.plugin() : feature.plugin(features[feature.id]) : feature.plugin,
			id: feature.id
		};
	});

	return function (root, result) {
		// browsers supported by the configuration
		var supportedBrowsers = browserslist(browsers, {
			path: result.root.source && result.root.source.input && result.root.source.input.file,
			ignoreUnknownVersions: true
		});

		// features supported by the stage and browsers
		var supportedFeatures = stagedFeatures.filter(function (feature) {
			return supportedBrowsers.some(function (supportedBrowser) {
				return browserslist(feature.browsers, {
					ignoreUnknownVersions: true
				}).some(function (polyfillBrowser) {
					return polyfillBrowser === supportedBrowser;
				});
			});
		});

		// polyfills run in execution order
		var polyfills = supportedFeatures.reduce(function (promise, feature) {
			return promise.then(function () {
				return feature.plugin(result.root, result);
			});
		}, Promise.resolve()).then(function () {
			return stagedAutoprefixer(result.root, result);
		});

		return polyfills;
	};
});

module.exports = index;
