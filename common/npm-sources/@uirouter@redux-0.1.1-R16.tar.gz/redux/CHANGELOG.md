## 0.1.1 (2017-11-05)
[Compare `@uirouter/redux` versions 0.1.0 and 0.1.1](https://github.com/ui-router/redux/compare/0.1.0...0.1.1)

- Fix missing built scripts in npm package

## 0.1.0 (2017-10-31)
0.1.0

first release