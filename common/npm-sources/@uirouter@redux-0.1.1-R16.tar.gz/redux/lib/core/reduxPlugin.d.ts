import { UIRouter } from "@uirouter/core";
import { Store } from "redux";
import { ReduxPlugin } from "./interface";
export declare type ReduxPluginApplyFn = (router: UIRouter) => ReduxPlugin;
export declare function reduxPluginFactory(name: string, store: Store<any>): ReduxPluginApplyFn;
export declare const createReduxPlugin: (store: Store<any>) => ReduxPluginApplyFn;
