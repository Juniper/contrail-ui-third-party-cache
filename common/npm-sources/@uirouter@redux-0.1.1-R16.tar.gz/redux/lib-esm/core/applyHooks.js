import { RejectType } from '@uirouter/core';
import { FINISH_TRANSITION, IGNORED_TRANSITION, REDIRECTED_TRANSITION, START_TRANSITION, SUCCESS_TRANSITION, } from "./actions";
/** @hidden */
var hookResult = true;
/** @hidden */
var noop = function () { };
/**
 * Dispatch Redux event
 *
 * Creates a function that when called dispatches a Redux action with the transition info.
 *
 * @param event The event name
 * @param store The redux store
 * @param trans The Transition
 */
function dispatch(event, store, trans) {
    return function () {
        store.dispatch({ type: event, transition: trans });
    };
}
function handleTransitionError(trans, store) {
    return function (err) {
        var dispatcher;
        if (err.type === RejectType.SUPERSEDED && err.redirected === true) {
            dispatcher = dispatch(REDIRECTED_TRANSITION, store, trans);
        }
        else if ((err.type = RejectType.IGNORED)) {
            dispatcher = dispatch(IGNORED_TRANSITION, store, trans);
        }
        else {
            dispatcher = noop;
        }
        dispatcher();
    };
}
/**
 * Applies hooks to Transitions
 *
 * Registers hooks for every Transition and dispatches Redux events to sync it.
 *
 * @param router The Router instance
 * @param store The Redux store
 * @returns A function for removing the event listeners
 */
export function applyHooks(router, store) {
    var transitionService = router.transitionService;
    var removeHooksFunctions = [];
    var removeMainHook = transitionService.onBefore({}, function (trans) {
        // Create a hook for the ends of the transition
        var dispatchOnStart = dispatch(START_TRANSITION, store, trans);
        var dispatchOnFinish = dispatch(FINISH_TRANSITION, store, trans);
        var dispatchOnSuccess = dispatch(SUCCESS_TRANSITION, store, trans);
        removeHooksFunctions.push(trans.onStart({}, dispatchOnStart));
        removeHooksFunctions.push(trans.onFinish({}, dispatchOnFinish));
        removeHooksFunctions.push(trans.onSuccess({}, dispatchOnSuccess));
        trans.promise.then(noop, handleTransitionError(trans, store));
    });
    return function () {
        removeMainHook();
        removeHooksFunctions.forEach(function (fn) { return fn(); });
    };
}
//# sourceMappingURL=applyHooks.js.map