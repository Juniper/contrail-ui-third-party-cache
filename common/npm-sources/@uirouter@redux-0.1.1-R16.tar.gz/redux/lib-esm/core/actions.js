export var TRIGGER_TRANSITION = '@ui-router/TRIGGER_TRANSITION';
export var START_TRANSITION = '@ui-router/START_TRANSITION';
export var IGNORED_TRANSITION = '@ui-router/IGNORED_TRANSITION';
export var REDIRECTED_TRANSITION = '@ui-router/REDIRECTED_TRANSITION';
export var FINISH_TRANSITION = '@ui-router/FINISH_TRANSITION';
export var SUCCESS_TRANSITION = '@ui-router/SUCCESS_TRANSITION';
export var triggerTransition = function (to, params) {
    return {
        type: TRIGGER_TRANSITION,
        to: to,
        params: params,
    };
};
//# sourceMappingURL=actions.js.map