import { TRIGGER_TRANSITION } from './actions';
export default function createRouterMiddleware(router) {
    return function () { return function (next) { return function (action) {
        if (action.type !== TRIGGER_TRANSITION) {
            return next(action);
        }
        var to = action.to, params = action.params;
        router.stateService.go(to, params);
    }; }; };
}
//# sourceMappingURL=middleware.js.map