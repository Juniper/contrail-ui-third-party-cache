import { servicesPlugin, UIRouter } from "@uirouter/react";
import { ReactReduxContext } from "react-redux";
import * as React from "react";
import { useContext, useRef } from "react";
import { createReduxPlugin } from "../core";
export function ConnectedUIRouter(_a) {
    var children = _a.children, routerFromProps = _a.router, plugins = _a.plugins, config = _a.config, states = _a.states;
    var init = useRef(false);
    var store = useContext(ReactReduxContext).store;
    var router = useRef(routerFromProps);
    var reduxPlugin = useRef(createReduxPlugin(store));
    // let's initialise the plugins and set up the router
    if (init.current !== true) {
        // services plugin is necessary for UIRouter to function
        router.current.plugin(servicesPlugin);
        // apply all the plugins that are passed via props
        plugins.forEach(function (plugin) { return router.current.plugin(plugin); });
        // apply the newly created redux plugin
        router.current.plugin(reduxPlugin.current);
        if (config)
            config(router.current);
        (states || []).forEach(function (state) {
            return router.current.stateRegistry.register(state);
        });
        init.current = true;
    }
    return React.createElement(UIRouter, { router: router.current }, children);
}
//# sourceMappingURL=ConnectedUIRouter.js.map