import { UIRouterProps } from "@uirouter/react";
import * as React from "react";
interface ConnectedUIRouterProps extends UIRouterProps {
    children: React.ReactElement;
}
export declare function ConnectedUIRouter({ children, router: routerFromProps, plugins, config, states, }: ConnectedUIRouterProps): JSX.Element;
export {};
