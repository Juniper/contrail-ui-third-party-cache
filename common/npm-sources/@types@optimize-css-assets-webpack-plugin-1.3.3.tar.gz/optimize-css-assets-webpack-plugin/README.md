# Installation
> `npm install --save @types/optimize-css-assets-webpack-plugin`

# Summary
This package contains type definitions for optimize-css-assets-webpack-plugin (https://github.com/NMFR/optimize-css-assets-webpack-plugin).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/optimize-css-assets-webpack-plugin

Additional Details
 * Last updated: Sat, 10 Mar 2018 02:17:46 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by Armando Meziat <https://github.com/odnamrataizem>.
