import * as React from "react";
import {UIView} from "@uirouter/react";

export class Header extends React.Component<any,any> {
  render() {
    return (
      <h3>This header is in a named ui-view</h3>
    );
  }
}