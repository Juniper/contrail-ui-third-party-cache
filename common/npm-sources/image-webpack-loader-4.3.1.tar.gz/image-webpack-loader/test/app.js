require('./test.gif');
require('./test.jpg');
require('./test.png');
require('./test.svg');
require('./test.bmp');
