# null-loader

A loader that returns an empty module.
