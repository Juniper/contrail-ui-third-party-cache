# Installation
> `npm install --save @types/socket.io-client`

# Summary
This package contains type definitions for socket.io-client (http://socket.io/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/socket.io-client

Additional Details
 * Last updated: Tue, 14 Nov 2017 19:35:37 GMT
 * Dependencies: none
 * Global values: io

# Credits
These definitions were written by PROGRE <https://github.com/progre>, Damian Connolly <https://github.com/divillysausages>, Florent Poujol <https://github.com/florentpoujol>.
