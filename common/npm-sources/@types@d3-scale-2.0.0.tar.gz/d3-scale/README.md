# Installation
> `npm install --save @types/d3-scale`

# Summary
This package contains type definitions for D3JS d3-scale module (https://github.com/d3/d3-scale/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-scale

Additional Details
 * Last updated: Sat, 10 Feb 2018 21:44:46 GMT
 * Dependencies: d3-time
 * Global values: none

# Credits
These definitions were written by Tom Wanzek <https://github.com/tomwanzek>, Alex Ford <https://github.com/gustavderdrache>, Boris Yankov <https://github.com/borisyankov>.
