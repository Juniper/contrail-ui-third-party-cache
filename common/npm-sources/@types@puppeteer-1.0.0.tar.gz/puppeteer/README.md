# Installation
> `npm install --save @types/puppeteer`

# Summary
This package contains type definitions for puppeteer (https://github.com/GoogleChrome/puppeteer#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/puppeteer

Additional Details
 * Last updated: Tue, 23 Jan 2018 20:08:10 GMT
 * Dependencies: events, child_process, node
 * Global values: none

# Credits
These definitions were written by Marvin Hagemeister <https://github.com/marvinhagemeister>, Christopher Deutsch <https://github.com/cdeutsch>, jwbay <https://github.com/jwbay>.
