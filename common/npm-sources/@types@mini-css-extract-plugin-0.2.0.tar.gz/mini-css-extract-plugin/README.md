# Installation
> `npm install --save @types/mini-css-extract-plugin`

# Summary
This package contains type definitions for mini-css-extract-plugin (https://github.com/webpack-contrib/mini-css-extract-plugin).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mini-css-extract-plugin

Additional Details
 * Last updated: Fri, 23 Mar 2018 22:51:43 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by JounQin <https://github.com/JounQin>.
