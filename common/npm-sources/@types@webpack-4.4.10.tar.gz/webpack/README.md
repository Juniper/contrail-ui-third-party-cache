# Installation
> `npm install --save @types/webpack`

# Summary
This package contains type definitions for webpack (https://github.com/webpack/webpack).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack

Additional Details
 * Last updated: Wed, 15 Aug 2018 20:42:04 GMT
 * Dependencies: tapable, uglify-js, source-map, node
 * Global values: none

# Credits
These definitions were written by Qubo <https://github.com/tkqubo>, Benjamin Lim <https://github.com/bumbleblym>, Boris Cherny <https://github.com/bcherny>, Tommy Troy Lin <https://github.com/tommytroylin>, Mohsen Azimi <https://github.com/mohsen1>, Jonathan Creamer <https://github.com/jcreamer898>, Alan Agius <https://github.com/alan-agius4>, Spencer Elliott <https://github.com/elliottsj>, Jason Cheatham <https://github.com/jason0x43>, Dennis George <https://github.com/dennispg>, Christophe Hurpeau <https://github.com/christophehurpeau>, ZSkycat <https://github.com/ZSkycat>, John Reilly <https://github.com/johnnyreilly>.
