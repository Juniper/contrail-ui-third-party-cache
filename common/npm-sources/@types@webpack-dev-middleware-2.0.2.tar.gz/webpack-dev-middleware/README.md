# Installation
> `npm install --save @types/webpack-dev-middleware`

# Summary
This package contains type definitions for webpack-dev-middleware (https://github.com/webpack/webpack-dev-middleware).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack-dev-middleware

Additional Details
 * Last updated: Mon, 09 Jul 2018 20:32:27 GMT
 * Dependencies: webpack, loglevel, connect, memory-fs
 * Global values: none

# Credits
These definitions were written by Benjamin Lim <https://github.com/bumbleblym>, reduckted <https://github.com/reduckted>, Chris Abrams <https://github.com/chrisabrams>.
