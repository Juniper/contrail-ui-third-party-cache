import { set } from "./index";
export = set;
