import { isEqualWith } from "./index";
export = isEqualWith;
