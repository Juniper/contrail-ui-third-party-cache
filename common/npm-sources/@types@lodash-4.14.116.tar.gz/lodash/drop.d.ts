import { drop } from "./index";
export = drop;
