import { zipWith } from "./index";
export = zipWith;
