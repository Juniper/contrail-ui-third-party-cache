import { isUndefined } from "./index";
export = isUndefined;
