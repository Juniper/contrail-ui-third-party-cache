import { escapeRegExp } from "./index";
export = escapeRegExp;
