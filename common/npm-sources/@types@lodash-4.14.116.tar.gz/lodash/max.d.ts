import { max } from "./index";
export = max;
