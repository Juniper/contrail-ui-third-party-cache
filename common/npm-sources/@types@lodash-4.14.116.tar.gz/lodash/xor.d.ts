import { xor } from "./index";
export = xor;
