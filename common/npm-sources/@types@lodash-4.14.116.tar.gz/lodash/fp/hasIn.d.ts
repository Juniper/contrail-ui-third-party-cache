import { hasIn } from "../fp";
export = hasIn;
