import { round } from "../fp";
export = round;
