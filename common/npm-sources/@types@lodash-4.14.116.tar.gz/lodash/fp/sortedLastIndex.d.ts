import { sortedLastIndex } from "../fp";
export = sortedLastIndex;
