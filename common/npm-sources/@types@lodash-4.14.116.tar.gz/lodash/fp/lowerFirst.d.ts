import { lowerFirst } from "../fp";
export = lowerFirst;
