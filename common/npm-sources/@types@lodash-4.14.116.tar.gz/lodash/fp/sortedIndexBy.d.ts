import { sortedIndexBy } from "../fp";
export = sortedIndexBy;
