import { invokeArgsMap } from "../fp";
export = invokeArgsMap;
