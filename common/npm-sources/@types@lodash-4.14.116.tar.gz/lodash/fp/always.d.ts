import { always } from "../fp";
export = always;
