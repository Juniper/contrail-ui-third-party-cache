import { size } from "../fp";
export = size;
