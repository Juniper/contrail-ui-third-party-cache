import { partial } from "../fp";
export = partial;
