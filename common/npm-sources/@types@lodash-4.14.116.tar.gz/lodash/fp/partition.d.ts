import { partition } from "../fp";
export = partition;
