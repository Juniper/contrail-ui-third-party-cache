import { intersectionWith } from "../fp";
export = intersectionWith;
