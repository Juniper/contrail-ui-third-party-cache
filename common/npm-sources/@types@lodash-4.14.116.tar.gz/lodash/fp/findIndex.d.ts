import { findIndex } from "../fp";
export = findIndex;
