import { isMatch } from "../fp";
export = isMatch;
