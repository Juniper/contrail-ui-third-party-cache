import { pathEq } from "../fp";
export = pathEq;
