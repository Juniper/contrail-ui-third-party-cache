import { forIn } from "../fp";
export = forIn;
