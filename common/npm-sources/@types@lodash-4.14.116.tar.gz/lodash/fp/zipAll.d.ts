import { zipAll } from "../fp";
export = zipAll;
