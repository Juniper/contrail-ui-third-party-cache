import { castArray } from "../fp";
export = castArray;
