import { dropLast } from "../fp";
export = dropLast;
