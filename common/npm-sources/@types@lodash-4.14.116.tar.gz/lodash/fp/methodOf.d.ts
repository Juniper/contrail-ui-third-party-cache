import { methodOf } from "../fp";
export = methodOf;
