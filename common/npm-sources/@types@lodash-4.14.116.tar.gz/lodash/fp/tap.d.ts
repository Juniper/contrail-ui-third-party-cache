import { tap } from "../fp";
export = tap;
