import { pathOr } from "../fp";
export = pathOr;
