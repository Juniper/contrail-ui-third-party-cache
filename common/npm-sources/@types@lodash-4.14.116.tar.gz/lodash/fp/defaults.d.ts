import { defaults } from "../fp";
export = defaults;
