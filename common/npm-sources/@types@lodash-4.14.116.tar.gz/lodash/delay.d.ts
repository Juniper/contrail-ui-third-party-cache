import { delay } from "./index";
export = delay;
