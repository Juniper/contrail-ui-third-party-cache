import { ceil } from "./index";
export = ceil;
