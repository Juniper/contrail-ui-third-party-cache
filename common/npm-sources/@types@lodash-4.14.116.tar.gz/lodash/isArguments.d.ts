import { isArguments } from "./index";
export = isArguments;
