import { partial } from "./index";
export = partial;
