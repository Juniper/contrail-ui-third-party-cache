import { after } from "./index";
export = after;
