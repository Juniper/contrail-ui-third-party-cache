import { slice } from "./index";
export = slice;
