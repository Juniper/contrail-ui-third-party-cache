import { startsWith } from "./index";
export = startsWith;
