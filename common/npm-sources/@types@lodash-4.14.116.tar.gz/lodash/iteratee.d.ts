import { iteratee } from "./index";
export = iteratee;
