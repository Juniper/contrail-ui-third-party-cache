import { TransitionService } from '../transition/transitionService';
export declare const registerEagerResolvePath: (transitionService: TransitionService) => Function;
export declare const registerLazyResolveState: (transitionService: TransitionService) => Function;
