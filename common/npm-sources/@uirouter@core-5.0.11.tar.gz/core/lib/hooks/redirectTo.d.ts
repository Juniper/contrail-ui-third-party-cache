import { TransitionService } from "../transition/transitionService";
export declare const registerRedirectToHook: (transitionService: TransitionService) => Function;
