import { TransitionService } from '../transition/transitionService';
export declare const registerUpdateGlobalState: (transitionService: TransitionService) => Function;
