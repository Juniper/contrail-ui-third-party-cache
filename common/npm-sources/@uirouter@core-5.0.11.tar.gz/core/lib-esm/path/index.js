/** @module path */ /** for typedoc */
export * from "./pathNode";
export * from "./pathFactory";
//# sourceMappingURL=index.js.map