/**
 * @internalapi
 * @module vanilla
 */
/** */
export * from "./vanilla/index";
//# sourceMappingURL=vanilla.js.map