export * from "./view";
//# sourceMappingURL=index.js.map