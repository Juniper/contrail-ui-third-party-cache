/** @module resolve */ /** for typedoc */
export * from "./interface";
export * from "./resolvable";
export * from "./resolveContext";
//# sourceMappingURL=index.js.map