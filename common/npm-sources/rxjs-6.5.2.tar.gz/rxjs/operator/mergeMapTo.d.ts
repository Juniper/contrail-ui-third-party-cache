export * from 'rxjs-compat/operator/mergeMapTo';
