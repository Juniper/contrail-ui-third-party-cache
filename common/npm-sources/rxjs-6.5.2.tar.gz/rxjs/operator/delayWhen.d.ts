export * from 'rxjs-compat/operator/delayWhen';
