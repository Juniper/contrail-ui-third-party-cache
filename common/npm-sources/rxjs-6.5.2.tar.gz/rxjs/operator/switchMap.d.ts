export * from 'rxjs-compat/operator/switchMap';
