export * from 'rxjs-compat/operator/map';
