export * from 'rxjs-compat/operator/skipWhile';
