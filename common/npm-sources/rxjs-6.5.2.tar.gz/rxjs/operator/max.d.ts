export * from 'rxjs-compat/operator/max';
