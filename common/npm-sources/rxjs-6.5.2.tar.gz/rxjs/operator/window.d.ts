export * from 'rxjs-compat/operator/window';
