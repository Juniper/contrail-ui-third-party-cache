export * from 'rxjs-compat/operator/elementAt';
