export * from 'rxjs-compat/operator/concat';
