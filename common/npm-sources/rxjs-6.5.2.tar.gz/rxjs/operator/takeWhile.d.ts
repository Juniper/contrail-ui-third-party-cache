export * from 'rxjs-compat/operator/takeWhile';
