export * from 'rxjs-compat/operator/windowWhen';
