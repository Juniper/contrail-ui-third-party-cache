export * from 'rxjs-compat/operator/sample';
