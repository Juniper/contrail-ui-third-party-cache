export * from 'rxjs-compat/operator/take';
