export * from 'rxjs-compat/operator/every';
