export * from 'rxjs-compat/operator/switch';
