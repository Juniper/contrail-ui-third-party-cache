export * from 'rxjs-compat/operator/sequenceEqual';
