export * from 'rxjs-compat/operator/switchMapTo';
