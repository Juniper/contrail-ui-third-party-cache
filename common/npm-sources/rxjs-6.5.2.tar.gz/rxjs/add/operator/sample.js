"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs-compat/add/operator/sample");
//# sourceMappingURL=sample.js.map