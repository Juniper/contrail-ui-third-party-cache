export * from 'rxjs-compat/operators/sampleTime';
