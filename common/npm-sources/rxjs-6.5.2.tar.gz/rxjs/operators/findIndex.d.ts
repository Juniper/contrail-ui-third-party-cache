export * from 'rxjs-compat/operators/findIndex';
