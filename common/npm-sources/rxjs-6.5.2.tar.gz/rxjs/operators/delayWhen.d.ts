export * from 'rxjs-compat/operators/delayWhen';
