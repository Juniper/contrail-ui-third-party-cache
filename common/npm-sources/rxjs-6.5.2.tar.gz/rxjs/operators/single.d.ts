export * from 'rxjs-compat/operators/single';
