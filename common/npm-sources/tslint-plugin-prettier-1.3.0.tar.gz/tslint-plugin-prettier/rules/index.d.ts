declare const _default: {
    rulesDirectory: string;
};
export = _default;
