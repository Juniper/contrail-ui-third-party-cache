"use strict";
exports.__esModule = true;
var tslib_1 = require("tslib");
var assert = require("assert");
var utils = require("eslint-plugin-prettier");
var path = require("path");
var prettier = require("prettier");
var tslint = require("tslint");
// tslint:disable:max-classes-per-file no-use-before-declare
var Rule = /** @class */ (function (_super) {
    tslib_1.__extends(Rule, _super);
    function Rule() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Rule.prototype.apply = function (source_file) {
        return this.applyWithWalker(new Walker(source_file, this.ruleName, this.ruleArguments));
    };
    return Rule;
}(tslint.Rules.AbstractRule));
exports.Rule = Rule;
var Walker = /** @class */ (function (_super) {
    tslib_1.__extends(Walker, _super);
    function Walker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Walker.prototype.walk = function (source_file) {
        var _this = this;
        var rule_argument_1 = this.options[0];
        var options = {};
        switch (typeof rule_argument_1) {
            case 'object':
                options = rule_argument_1;
                break;
            case 'string': {
                try {
                    assert_existence_of_resolve_config_sync();
                }
                catch (_a) {
                    // istanbul ignore next
                    throw new Error("Require prettier@1.7.0+ to specify config file, but got prettier@" + prettier.version + ".");
                }
                var file_path = path.resolve(process.cwd(), rule_argument_1);
                var resolved_config = prettier.resolveConfig.sync(file_path);
                // istanbul ignore next
                if (resolved_config === null) {
                    throw new Error("Config file not found: " + file_path);
                }
                options = resolved_config;
                break;
            }
            default: {
                try {
                    assert_existence_of_resolve_config_sync();
                }
                catch (_b) {
                    // backward compatibility: use default options if no resolveConfig.sync()
                    // istanbul ignore next
                    break;
                }
                var resolved_config = prettier.resolveConfig.sync(source_file.fileName);
                if (resolved_config !== null) {
                    options = resolved_config;
                }
                break;
            }
        }
        var source = source_file.getFullText();
        var formatted = prettier.format(source, tslib_1.__assign({ parser: 'typescript' }, options));
        if (source === formatted) {
            return;
        }
        utils.generateDifferences(source, formatted).forEach(function (difference) {
            var operation = difference.operation, start = difference.offset, _a = difference.deleteText, delete_text = _a === void 0 ? '' : _a, _b = difference.insertText, insert_text = _b === void 0 ? '' : _b;
            var end = start + delete_text.length;
            var delete_code = utils.showInvisibles(delete_text);
            var insert_code = utils.showInvisibles(insert_text);
            switch (operation) {
                case 'insert':
                    _this.addFailureAt(start, 1, "Insert `" + insert_code + "`", tslint.Replacement.appendText(start, insert_text));
                    break;
                case 'delete':
                    _this.addFailure(start, end, "Delete `" + delete_code + "`", tslint.Replacement.deleteFromTo(start, end));
                    break;
                case 'replace':
                    _this.addFailure(start, end, "Replace `" + delete_code + "` with `" + insert_code + "`", tslint.Replacement.replaceFromTo(start, end, insert_text));
                    break;
                // istanbul ignore next
                default:
                    throw new Error("Unexpected operation '" + operation + "'");
            }
        });
    };
    return Walker;
}(tslint.AbstractWalker));
function assert_existence_of_resolve_config_sync() {
    // tslint:disable-next-line:strict-type-predicates
    assert(typeof prettier.resolveConfig.sync === 'function');
}
