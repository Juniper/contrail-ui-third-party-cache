import * as tslint from 'tslint';
import * as ts from 'typescript';
export declare class Rule extends tslint.Rules.AbstractRule {
    apply(source_file: ts.SourceFile): tslint.RuleFailure[];
}
