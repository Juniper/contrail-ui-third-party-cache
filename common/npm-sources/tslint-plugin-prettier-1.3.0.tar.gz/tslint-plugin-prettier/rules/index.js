"use strict";
module.exports = { rulesDirectory: '.' };
