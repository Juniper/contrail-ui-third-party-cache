# Installation
> `npm install --save @types/webpack-dev-server`

# Summary
This package contains type definitions for webpack-dev-server (https://github.com/webpack/webpack-dev-server).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack-dev-server

Additional Details
 * Last updated: Wed, 15 Aug 2018 20:42:04 GMT
 * Dependencies: webpack, http-proxy-middleware, express, serve-static, https, http, url
 * Global values: none

# Credits
These definitions were written by maestroh <https://github.com/maestroh>, Dave Parslow <https://github.com/daveparslow>, Zheyang Song <https://github.com/ZheyangSong>, Alan Agius <https://github.com/alan-agius4>, Artur Androsovych <https://github.com/arturovt>.
