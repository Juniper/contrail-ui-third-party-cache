# Installation
> `npm install --save @types/hard-source-webpack-plugin`

# Summary
This package contains type definitions for hard-source-webpack-plugin (https://github.com/mzgoddard/hard-source-webpack-plugin#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hard-source-webpack-plugin

Additional Details
 * Last updated: Mon, 02 Jul 2018 20:44:33 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by woitechen <https://github.com/woitechen>.
