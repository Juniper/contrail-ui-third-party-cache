# Installation
> `npm install --save @types/react-pointable`

# Summary
This package contains type definitions for react-pointable (https://github.com/MilllerTime/react-pointable).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-pointable

Additional Details
 * Last updated: Thu, 01 Jun 2017 05:18:36 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Stefan Fochler <https://github.com/istefo>.
