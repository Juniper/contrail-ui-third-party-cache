import { Command } from '@oclif/command';
export default class Generate extends Command {
    static description: string;
    static flags: {};
    static args: {
        name: string;
    }[];
    run(): Promise<void>;
}
