TypeScript is authored by:
* Aaron Holmes
* Abubaker Bashir
* Adam Freidin
* Adi Dahiya
* Ahmad Farid
* Akshar Patel
* Alex Eagle
* Alexander Kuvaev
* Alexander Rusakov 
* Ali Sabzevari
* Aliaksandr Radzivanovich
* Aluan Haddad 
* Anatoly Ressin 
* Anders Hejlsberg
* Andreas Martin
* Andrej Baran 
* Andrew Casey 
* Andrew Ochsner 
* Andrew Stegmaier 
* Andrew Z Allen
* András Parditka 
* Andy Hanson
* Anil Anar
* Anton Khlynovskiy 
* Anton Tolmachev
* Anubha Mathur 
* Arnav Singh
* Arthur Ozga
* Asad Saeeduddin
* Avery Morin
* Basarat Ali Syed
* Ben Duffield
* Ben Mosher 
* Benjamin Bock 
* Benny Neugebauer 
* Bill Ticehurst
* Blaine Bublitz 
* Blake Embrey
* @bootstraponline
* Bowden Kelly
* Brett Mayen
* Bryan Forbes
* Caitlin Potter
* @cedvdb
* Charles Pierce 
* Charly POLY 
* Chris Bubernak
* Christophe Vidal 
* Chuck Jazdzewski
* Colby Russell
* Colin Snover
* Cotton Hou 
* Cyrus Najmabadi
* Dafrok Zhang
* Dahan Gong
* Dan Corder
* Dan Quirk
* Daniel Hollocher
* Daniel Król 
* Daniel Lehenbauer
* Daniel Rosenwasser
* David Kmenta
* David Li
* David Sheldrick 
* David Souther
* Denis Nedelyaev
* Dick van den Brink
* Diogo Franco (Kovensky) 
* Dirk Bäumer
* Dirk Holtwick
* Dom Chen 
* Donald Pipowitch 
* Doug Ilijev
* @e-cloud
* Elisée Maurer
* Emilio García-Pumarino
* Eric Tsang
* Erik Edrosa
* Erik McClenney 
* Ethan Resnick 
* Ethan Rubio
* Evan Martin
* Evan Sebastian
* Eyas Sharaiha
* Fabian Cook 
* @falsandtru
* @flowmemo
* Frank Wallis
* Franklin Tse
* František Žiacik
* Gabe Moothart 
* Gabriel Isenberg
* Gilad Peleg
* Godfrey Chan 
* Graeme Wicksted
* Guilherme Oenning
* Guillaume Salles
* Guy Bedford
* Halasi Tamás 
* Harald Niesche
* Hendrik Liebau 
* Herrington Darkholme
* Homa Wong 
* Iain Monro
* Igor Novozhilov
* Ika 
* Ingvar Stepanyan
* Isiah Meadows
* Ivo Gabe de Wolff
* Iwata Hidetaka 
* Jakub Młokosiewicz 
* James Henry 
* James Whitney
* Jason Freeman
* Jason Jarrett 
* Jason Killian
* Jason Ramsay
* JBerger
* Jed Mao
* Jeffrey Morlan
* Jesse Schalken
* Jiri Tobisek
* Joe Chung 
* Joel Day 
* Joey Wilson
* Johannes Rieken
* John Vilk
* Jonathan Bond-Caron
* Jonathan Park
* Jonathan Toland
* Jonathan Turner
* Jonathon Smith
* Josh Abernathy 
* Josh Goldberg 
* Josh Kalderimis
* Josh Soref
* Juan Luis Boya García
* Julian Williams
* Justin Bay 
* Justin Johansson 
* K. Preißer
* Kagami Sascha Rosylight
* Kanchalai Tanglertsampan
* Kate Miháliková 
* Keith Mashinter
* Ken Howard
* Kenji Imamula
* Kevin Lang 
* Kitson Kelly 
* Klaus Meinhardt 
* Kyle Kelley
* Kārlis Gaņģis
* Lorant Pinter
* Lucien Greathouse
* Lukas Elmer 
* Magnus Hiie 
* Manish Giri
* Marin Marinov
* Marius Schulz 
* Martin Vseticka
* Masahiro Wakame
* Matt Bierner 
* Matt McCutchen
* Mattias Buelens
* Mattias Buelens 
* Max Deepfield
* Micah Zoltu
* Michael 
* Michael Bromley
* Mike Busyrev 
* Mine Starks 
* Mohamed Hegazy
* Mohsen Azimi 
* Myles Megyesi 
* Natalie Coley
* Nathan Shively-Sanders
* Nathan Yee
* Nicolas Henry
* Nima Zahedi
* Noah Chen 
* Noel Varanda 
* Noj Vek
* Oleg Mihailik
* Oleksandr Chekhovskyi
* Omer Sheikh 
* Oskar Segersva¨rd
* Patrick Zhong
* Paul Jolly
* Paul van Brenk
* @pcbro
* Pedro Maltez
* Perry Jiang
* Peter Burns
* Philip Bulley
* Piero Cangianiello
* @piloopin
* Prayag Verma
* @progre
* Punya Biswal
* Rado Kirov
* Raj Dosanjh
* Reiner Dolp 
* Richard Karmazín 
* Richard Knoll
* Richard Sentino
* Robert Coie
* Rohit Verma
* Ron Buckton
* Rostislav Galimsky 
* Rowan Wyborn
* Ryan Cavanaugh
* Ryohei Ikegami
* Sam El-Husseini 
* Sarangan Rajamanickam
* Sergey Rubanov
* Sergey Shandar 
* Sheetal Nandi
* Shengping Zhong
* Shyyko Serhiy
* Simon Hürlimann
* Slawomir Sadziak 
* Solal Pirelli
* Soo Jae Hwang 
* Stan Thomas
* Stanislav Sysoev
* Steve Lucco
* Sudheesh Singanamalla 
* Sébastien Arod
* @T18970237136
* @t_
* Tarik Ozket
* Tetsuharu Ohzeki
* Thomas Loubiou
* Tien Hoanhtien
* Tim Lancina 
* Tim Perry
* Tim Viiding-Spader
* Tingan Ho
* Todd Thomson
* togru
* Tomas Grubliauskas
* Torben Fitschen 
* @TravCav
* TruongSinh Tran-Nguyen
* Vadi Taslim 
* Vidar Tonaas Fauske
* Viktor Zozulyak
* Vilic Vane
* Vladimir Kurchatkin 
* Vladimir Matveev
* Wesley Wigham
* William Orr 
* York Yao
* @yortus
* Yuichi Nukiyama
* Zev Spitz
* Zhengbo Li