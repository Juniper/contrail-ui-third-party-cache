'use strict';

exports.__esModule = true;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _d3Timer = require('d3-timer');

var _Node = require('../Node');

var _Node2 = _interopRequireDefault(_Node);

var _mergeKeys = require('../core/mergeKeys');

var _mergeKeys2 = _interopRequireDefault(_mergeKeys);

var _types = require('../core/types');

var _transition = require('../core/transition');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } //  weak
/* eslint max-len: "off" */

var NodeGroup = function (_Component) {
  _inherits(NodeGroup, _Component);

  function NodeGroup() {
    var _temp, _this, _ret;

    _classCallCheck(this, NodeGroup);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _Component.call.apply(_Component, [this].concat(args))), _this), _this.state = {
      nodes: []
    }, _this.animate = function () {
      if (_this.unmounting) {
        return;
      }

      var pending = false;

      var nextNodeKeys = [];
      var length = _this.nodeKeys.length;

      for (var i = 0; i < length; i++) {
        var k = _this.nodeKeys[i];
        var n = _this.nodeHash[k];

        if (n.TRANSITION_SCHEDULES) {
          pending = true;
        }

        if (n.type === _types.LEAVE && !n.TRANSITION_SCHEDULES) {
          delete _this.nodeHash[k];
        } else {
          nextNodeKeys.push(k);
        }
      }

      if (!pending) {
        _this.interval.stop();
      }

      _this.nodeKeys = nextNodeKeys;
      _this.renderNodes();
    }, _this.nodeHash = {}, _this.nodeKeys = [], _this.interval = null, _this.unmounting = false, _temp), _possibleConstructorReturn(_this, _ret);
  }

  NodeGroup.prototype.componentDidMount = function componentDidMount() {
    this.updateNodes(this.props);
  };

  NodeGroup.prototype.componentWillReceiveProps = function componentWillReceiveProps(next) {
    if (next.data !== this.props.data) {
      this.updateNodes(next);
    }
  };

  NodeGroup.prototype.componentWillUnmount = function componentWillUnmount() {
    var _this2 = this;

    this.unmounting = true;

    if (this.interval) {
      this.interval.stop();
    }

    this.nodeKeys.forEach(function (key) {
      _transition.stop.call(_this2.nodeHash[key]);
    });
  };

  NodeGroup.prototype.updateNodes = function updateNodes(props) {
    var data = props.data,
        keyAccessor = props.keyAccessor,
        start = props.start,
        enter = props.enter,
        update = props.update,
        leave = props.leave;


    var currKeyIndex = {};
    var currNodeKeys = this.nodeKeys;
    var currNodeKeysLength = this.nodeKeys.length;

    for (var i = 0; i < currNodeKeysLength; i++) {
      currKeyIndex[currNodeKeys[i]] = i;
    }

    var nextKeyIndex = {};
    var nextNodeKeys = [];

    for (var _i = 0; _i < data.length; _i++) {
      var d = data[_i];
      var k = keyAccessor(d, _i);

      nextKeyIndex[k] = _i;
      nextNodeKeys.push(k);

      if (currKeyIndex[k] === undefined) {
        this.nodeHash[k] = new _Node2.default(k, d, _types.ENTER);
      }
    }

    for (var _i2 = 0; _i2 < currNodeKeysLength; _i2++) {
      var _k = currNodeKeys[_i2];
      var n = this.nodeHash[_k];

      if (nextKeyIndex[_k] !== undefined) {
        n.updateData(data[nextKeyIndex[_k]]);
        n.updateType(_types.UPDATE);
      } else {
        n.updateType(_types.LEAVE);
      }
    }

    this.nodeKeys = (0, _mergeKeys2.default)(currNodeKeys, currKeyIndex, nextNodeKeys, nextKeyIndex);

    for (var _i3 = 0; _i3 < this.nodeKeys.length; _i3++) {
      var _k2 = this.nodeKeys[_i3];
      var _n = this.nodeHash[_k2];
      var _d = _n.data;

      if (_n.type === _types.ENTER) {
        _n.setState(start(_d, nextKeyIndex[_k2]));
        _transition.transition.call(_n, enter(_d, nextKeyIndex[_k2]));
      } else if (_n.type === _types.LEAVE) {
        _transition.transition.call(_n, leave(_d, currKeyIndex[_k2]));
      } else {
        _transition.transition.call(_n, update(_d, nextKeyIndex[_k2]));
      }
    }

    if (!this.interval) {
      this.interval = (0, _d3Timer.interval)(this.animate);
    } else {
      this.interval.restart(this.animate);
    }

    this.renderNodes();
  };

  NodeGroup.prototype.renderNodes = function renderNodes() {
    var _this3 = this;

    this.setState(function () {
      return {
        nodes: _this3.nodeKeys.map(function (key) {
          return _this3.nodeHash[key];
        })
      };
    });
  };

  NodeGroup.prototype.render = function render() {
    var renderedChildren = this.props.children(this.state.nodes);
    return renderedChildren && _react2.default.Children.only(renderedChildren);
  };

  return NodeGroup;
}(_react.Component);

NodeGroup.defaultProps = {
  enter: function enter() {},
  update: function update() {},
  leave: function leave() {}
};
exports.default = NodeGroup;