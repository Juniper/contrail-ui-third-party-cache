'use strict';

exports.__esModule = true;
//  weak
/* eslint guard-for-in: "off", no-restricted-syntax: "off" */
// Node constructor used to manage transitions internally
// Basically a modified preact component (https://github.com/developit/preact)

function extend(obj, props) {
  for (var i in props) {
    obj[i] = props[i]; // eslint-disable-line no-param-reassign
  }

  return obj;
}

function Node(key, data, type) {
  this.key = key;
  this.data = data;
  this.type = type;
  this.state = {};
}

extend(Node.prototype, {
  setState: function setState(state) {
    var s = this.state;
    extend(s, typeof state === 'function' ? state(s) : state);
  },
  updateData: function updateData(data) {
    this.data = data;

    return this;
  },
  updateType: function updateType(type) {
    this.type = type;

    return this;
  }
});

exports.default = Node;