'use strict';

exports.__esModule = true;
exports.default = undefined;

var _Animate = require('./Animate');

var _Animate2 = _interopRequireDefault(_Animate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _Animate2.default; /* eslint-disable flowtype/require-valid-file-annotation */