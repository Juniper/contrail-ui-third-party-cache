'use strict';

exports.__esModule = true;
//  weak

var ENTER = exports.ENTER = 'ENTER';
var UPDATE = exports.UPDATE = 'UPDATE';
var LEAVE = exports.LEAVE = 'LEAVE';