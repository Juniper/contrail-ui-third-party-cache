"use strict";

exports.__esModule = true;
exports.default = stop;
//  weak

function stop() {
  var ts = this.TRANSITION_SCHEDULES;

  if (ts) {
    Object.keys(ts).forEach(function (s) {
      ts[s].timer.stop();
    });
  }
}