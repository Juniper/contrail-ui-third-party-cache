'use strict';

exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //  weak


exports.getInterpolator = getInterpolator;

exports.default = function (nameSpace, attr, value) {
  return getTween.call(this, nameSpace, attr, value);
};

var _d3Interpolate = require('d3-interpolate');

function getInterpolator(attr) {
  if (attr === 'transform') {
    return _d3Interpolate.interpolateTransformSvg;
  }

  return _d3Interpolate.interpolate;
}

function getTween(nameSpace, attr, value1) {
  return function tween() {
    var _this = this;

    var value0 = nameSpace ? this.state[nameSpace][attr] : this.state[attr];

    if (value0 === value1) {
      return null;
    }

    var i = getInterpolator(attr)(value0, value1);

    var stateTween = void 0;

    if (nameSpace === null) {
      stateTween = function stateTween(t) {
        _this.setState(function () {
          var _ref;

          return _ref = {}, _ref[attr] = i(t), _ref;
        });
      };
    } else {
      stateTween = function stateTween(t) {
        _this.setState(function (state) {
          var _extends2, _ref2;

          return _ref2 = {}, _ref2[nameSpace] = _extends({}, state[nameSpace], (_extends2 = {}, _extends2[attr] = i(t), _extends2)), _ref2;
        });
      };
    }

    return stateTween;
  };
}