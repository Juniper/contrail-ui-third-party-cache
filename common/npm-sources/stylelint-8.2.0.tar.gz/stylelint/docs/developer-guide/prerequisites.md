# Prerequisites to contributing

## Technical

-   [Node.js](https://nodejs.org/en/) 4.2.1+.
-   Latest [npm](https://www.npmjs.com/).

## Rules of thumb

1.  Never push directly to `master` (except when updating the CHANGELOG). If you need to change something — create PR, even if it's a one letter change.
