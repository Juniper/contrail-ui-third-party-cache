export { default } from './assignIn.js'
