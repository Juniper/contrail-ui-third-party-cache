# Tests
`npm install && npm run test`  