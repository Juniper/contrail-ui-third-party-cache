/**
 * @fileOverview Cross
 */
import React from 'react';
import { PRESENTATION_ATTRIBUTES } from '../util/ReactUtils';

function Cell() {
  return null;
}

Cell.propTypes = {
  ...PRESENTATION_ATTRIBUTES,
};
Cell.displayName = 'Cell';

export default Cell;
