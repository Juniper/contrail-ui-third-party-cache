import { version } from '../../package.json';
export default version;
