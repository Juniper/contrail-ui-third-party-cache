export declare function getComponentLocale(props: any, context: any, componentName: any, getDefaultLocale: any): any;
export declare function getLocaleCode(context: any): any;
