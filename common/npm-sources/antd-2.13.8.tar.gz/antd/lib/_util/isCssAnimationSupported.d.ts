declare function isCssAnimationSupported(): any;
export default isCssAnimationSupported;
