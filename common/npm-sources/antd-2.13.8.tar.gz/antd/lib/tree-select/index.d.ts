/// <reference types="react" />
import React from 'react';
import { TreeSelectProps } from './interface';
export { TreeSelectProps };
declare const _default: React.ComponentClass<TreeSelectProps>;
export default _default;
