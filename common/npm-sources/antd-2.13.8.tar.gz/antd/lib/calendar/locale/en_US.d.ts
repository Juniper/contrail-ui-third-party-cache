import en_US from '../../date-picker/locale/en_US';
export default en_US;
