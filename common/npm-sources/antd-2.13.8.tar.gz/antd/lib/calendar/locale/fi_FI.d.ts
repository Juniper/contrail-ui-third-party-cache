import fi_FI from '../../date-picker/locale/fi_FI';
export default fi_FI;
