# Installation
> `npm install --save @types/copy-webpack-plugin`

# Summary
This package contains type definitions for copy-webpack-plugin (https://github.com/kevlened/copy-webpack-plugin).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/copy-webpack-plugin

Additional Details
 * Last updated: Wed, 15 Aug 2018 20:42:04 GMT
 * Dependencies: webpack, minimatch
 * Global values: none

# Credits
These definitions were written by flying-sheep <https://github.com/flying-sheep>.
