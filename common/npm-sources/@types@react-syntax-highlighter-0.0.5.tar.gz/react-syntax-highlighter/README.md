# Installation
> `npm install --save @types/react-syntax-highlighter`

# Summary
This package contains type definitions for react-syntax-highlighter (https://github.com/conorhastings/react-syntax-highlighter).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-syntax-highlighter

Additional Details
 * Last updated: Fri, 02 Mar 2018 10:54:53 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Ivo Stratev <https://github.com/NoHomey>.
