'use strict';

exports.__esModule = true;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _d3Timer = require('d3-timer');

var _transition = require('../core/transition');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } //  weak
/* eslint max-len: "off" */

var Animate = function (_Component) {
  _inherits(Animate, _Component);

  function Animate() {
    var _temp, _this, _ret;

    _classCallCheck(this, Animate);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _Component.call.apply(_Component, [this].concat(args))), _this), _this.state = typeof _this.props.start === 'function' ? _this.props.start() : _this.props.start, _this.checkTransitionStatus = function () {
      if (!_this.TRANSITION_SCHEDULES) {
        _this.interval.stop();

        if (_this.props.show === false) {
          _this.renderNull = true;
          _this.setState(function (prevState) {
            return prevState;
          }); // force render as null
        }
      }
    }, _this.interval = null, _this.renderNull = true, _temp), _possibleConstructorReturn(_this, _ret);
  }

  Animate.prototype.componentWillMount = function componentWillMount() {
    if (this.props.show === true) {
      this.renderNull = false;
    }
  };

  Animate.prototype.componentDidMount = function componentDidMount() {
    var _props = this.props,
        enter = _props.enter,
        show = _props.show;


    if (enter && show === true) {
      _transition.transition.call(this, typeof enter === 'function' ? enter() : enter);
    }
  };

  Animate.prototype.componentWillReceiveProps = function componentWillReceiveProps(next) {
    var _this2 = this;

    var show = next.show,
        start = next.start,
        enter = next.enter,
        update = next.update,
        leave = next.leave;


    if (this.props.show === false && this.renderNull === true && show === true) {
      this.renderNull = false;

      this.setState(function () {
        return typeof start === 'function' ? start() : start;
      }, function () {
        if (enter) {
          _transition.transition.call(_this2, typeof enter === 'function' ? enter() : enter);
        }
      });
    } else if (this.props.show === true && show === false) {
      if (leave) {
        _transition.transition.call(this, typeof leave === 'function' ? leave() : leave);
        this.interval = (0, _d3Timer.interval)(this.checkTransitionStatus);
      } else {
        this.renderNull = true;
        this.setState(function (prevState) {
          return prevState;
        }); // force render as null
      }
    } else if (show === true && update) {
      if (this.interval) {
        this.interval.stop();
      }

      _transition.transition.call(this, typeof update === 'function' ? update() : update);
    }
  };

  Animate.prototype.componentWillUnmount = function componentWillUnmount() {
    if (this.interval) {
      this.interval.stop();
    }

    _transition.stop.call(this);
  };

  Animate.prototype.render = function render() {
    if (this.renderNull === true) {
      return null;
    }

    var renderedChildren = this.props.children(this.state);
    return renderedChildren && _react2.default.Children.only(renderedChildren);
  };

  return Animate;
}(_react.Component);

Animate.defaultProps = {
  show: true
};
exports.default = Animate;