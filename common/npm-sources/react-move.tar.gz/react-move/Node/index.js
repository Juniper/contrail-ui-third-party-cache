'use strict';

exports.__esModule = true;
exports.default = undefined;

var _Node = require('./Node');

var _Node2 = _interopRequireDefault(_Node);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _Node2.default; /* eslint-disable flowtype/require-valid-file-annotation */