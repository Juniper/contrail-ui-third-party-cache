'use strict';

exports.__esModule = true;
exports.default = undefined;

var _NodeGroup = require('./NodeGroup');

var _NodeGroup2 = _interopRequireDefault(_NodeGroup);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _NodeGroup2.default; /* eslint-disable flowtype/require-valid-file-annotation */