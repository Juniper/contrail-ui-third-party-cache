'use strict';

exports.__esModule = true;
exports.preset = undefined;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //  weak

exports.newId = newId;
exports.default = transition;

var _d3Timer = require('d3-timer');

var _tween = require('./tween');

var _tween2 = _interopRequireDefault(_tween);

var _schedule = require('./schedule');

var _schedule2 = _interopRequireDefault(_schedule);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function once(func) {
  var called = false;

  return function transitionEvent() {
    if (!called) {
      called = true;
      func.call(this);
    }
  };
}

var id = 0;

function newId() {
  return ++id;
}

// from https://github.com/d3/d3-ease/blob/master/src/linear.js
function linear(t) {
  return +t;
}

var preset = exports.preset = {
  time: null,
  delay: 0,
  duration: 250,
  ease: linear
};

function scheduleTransitions() {
  var _this = this;

  var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  var transitions = _extends({}, config);

  var events = transitions.events || {};
  delete transitions.events;

  // each event handler should be called only once
  Object.keys(events).forEach(function (d) {
    if (typeof events[d] !== 'function') {
      throw new Error('Event handlers must be a function');
    } else {
      events[d] = once(events[d]);
    }
  });

  var timing = transitions.timing || {};
  delete transitions.timing;

  Object.keys(transitions).forEach(function (stateKey) {
    var tweens = [];

    if (_typeof(transitions[stateKey]) === 'object' && Array.isArray(transitions[stateKey]) === false) {
      Object.keys(transitions[stateKey]).forEach(function (attr) {
        var val = transitions[stateKey][attr];

        if (Array.isArray(val)) {
          if (val.length === 1) {
            tweens.push(_tween2.default.call(_this, stateKey, attr, val[0]));
          } else {
            _this.setState(function (state) {
              var _extends2, _ref;

              return _ref = {}, _ref[stateKey] = _extends({}, state[stateKey], (_extends2 = {}, _extends2[attr] = val[0], _extends2)), _ref;
            });

            tweens.push(_tween2.default.call(_this, stateKey, attr, val[1]));
          }
        } else if (typeof val === 'function') {
          var getResonanceCustomTween = function getResonanceCustomTween() {
            var resonanceCustomTween = function resonanceCustomTween(t) {
              _this.setState(function (state) {
                var _extends3, _ref2;

                return _ref2 = {}, _ref2[stateKey] = _extends({}, state[stateKey], (_extends3 = {}, _extends3[attr] = val(t), _extends3)), _ref2;
              });
            };

            return resonanceCustomTween;
          };

          tweens.push(getResonanceCustomTween);
        } else {
          _this.setState(function (state) {
            var _extends4, _ref3;

            return _ref3 = {}, _ref3[stateKey] = _extends({}, state[stateKey], (_extends4 = {}, _extends4[attr] = val, _extends4)), _ref3;
          });
          // This assures any existing transitions are stopped
          tweens.push(_tween2.default.call(_this, stateKey, attr, val));
        }
      });
    } else {
      var val = transitions[stateKey];

      if (Array.isArray(val)) {
        if (val.length === 1) {
          tweens.push(_tween2.default.call(_this, null, stateKey, val[0]));
        } else {
          _this.setState(function () {
            var _ref4;

            return _ref4 = {}, _ref4[stateKey] = val[0], _ref4;
          });

          tweens.push(_tween2.default.call(_this, null, stateKey, val[1]));
        }
      } else if (typeof val === 'function') {
        var getResonanceCustomTween = function getResonanceCustomTween() {
          var resonanceCustomTween = function resonanceCustomTween(t) {
            _this.setState(function () {
              var _ref5;

              return _ref5 = {}, _ref5[stateKey] = val(t), _ref5;
            });
          };

          return resonanceCustomTween;
        };

        tweens.push(getResonanceCustomTween);
      } else {
        _this.setState(function () {
          var _ref6;

          return _ref6 = {}, _ref6[stateKey] = val, _ref6;
        });
        // This assures any existing transitions are stopped
        tweens.push(_tween2.default.call(_this, null, stateKey, val));
      }
    }

    var timingConfig = _extends({}, preset, timing, { time: (0, _d3Timer.now)() });
    (0, _schedule2.default)(_this, stateKey, newId(), timingConfig, tweens, events);
  });
}

function transition(config) {
  var _this2 = this;

  if (Array.isArray(config)) {
    config.forEach(function (c) {
      scheduleTransitions.call(_this2, c);
    });
  } else {
    scheduleTransitions.call(this, config);
  }
}