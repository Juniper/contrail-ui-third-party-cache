"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var path_1 = require("path");
var ts = require("typescript");
var Lint = require("tslint");
var Rule = /** @class */ (function (_super) {
    __extends(Rule, _super);
    function Rule() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Rule.prototype.apply = function (sourceFile) {
        var resolvedFile = path_1.resolve(sourceFile.fileName);
        imports.delete(resolvedFile);
        return this.applyWithWalker(new NoCircularImportsWalker(sourceFile, this.getOptions()));
    };
    Rule.FAILURE_STRING = 'circular import detected';
    Rule.metadata = {
        ruleName: 'no-circular-imports',
        description: 'Disallows circular imports.',
        rationale: (_a = ["\n        Circular dependencies cause hard-to-catch runtime exceptions."], _a.raw = ["\n        Circular dependencies cause hard-to-catch runtime exceptions."], Lint.Utils.dedent(_a)),
        optionsDescription: 'Not configurable.',
        options: null,
        optionExamples: ['true'],
        type: 'functionality',
        typescriptOnly: false
    };
    return Rule;
}(Lint.Rules.AbstractRule));
exports.Rule = Rule;
var imports = new Map();
var NoCircularImportsWalker = /** @class */ (function (_super) {
    __extends(NoCircularImportsWalker, _super);
    function NoCircularImportsWalker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    NoCircularImportsWalker.prototype.visitNode = function (node) {
        // export declarations seem to be missing from the current SyntaxWalker
        if (ts.isExportDeclaration(node)) {
            this.visitExportDeclaration(node);
            this.walkChildren(node);
        }
        else {
            _super.prototype.visitNode.call(this, node);
        }
    };
    NoCircularImportsWalker.prototype.visitExportDeclaration = function (node) {
        this.visitImportOrExportDeclaration(node);
    };
    NoCircularImportsWalker.prototype.visitImportDeclaration = function (node) {
        this.visitImportOrExportDeclaration(node);
        _super.prototype.visitImportDeclaration.call(this, node);
    };
    NoCircularImportsWalker.prototype.visitImportOrExportDeclaration = function (node) {
        if (!node.parent || !ts.isSourceFile(node.parent)) {
            return;
        }
        if (!node.moduleSpecifier) {
            return;
        }
        var thisFileName = node.parent.fileName;
        var resolvedThisFileName = path_1.resolve(thisFileName);
        if (!ts.isStringLiteral(node.moduleSpecifier)) {
            return;
        }
        var importFileName = node.moduleSpecifier.text;
        // TODO: does TSLint expose an API for this? it would be nice to use TSC's
        // resolveModuleNames to avoid doing this ourselves, and get support for
        // roots defined in tsconfig.json.
        var resolvedImportFileName = isImportFromNPMPackage(importFileName)
            ? importFileName
            : path_1.resolve(path_1.dirname(thisFileName), importFileName + '.ts');
        // add to import graph
        this.addToGraph(resolvedThisFileName, resolvedImportFileName);
        // check for cycles
        if (this.hasCycle(resolvedThisFileName, resolvedImportFileName)) {
            this.addFailure(this.createFailure(node.getStart(), node.getWidth(), Rule.FAILURE_STRING + ": " + this.getCycle(resolvedThisFileName, resolvedImportFileName).concat(resolvedThisFileName).map(function (_) { return path_1.basename(_); }).join(' -> ')));
        }
    };
    /**
     * TODO: don't rely on import name
     */
    NoCircularImportsWalker.prototype.addToGraph = function (thisFileName, importCanonicalName) {
        if (!imports.get(thisFileName)) {
            imports.set(thisFileName, new Set);
        }
        imports.get(thisFileName).add(importCanonicalName);
    };
    NoCircularImportsWalker.prototype.hasCycle = function (moduleName, startFromImportName) {
        return this.getCycle(moduleName, startFromImportName).length > 0;
    };
    NoCircularImportsWalker.prototype.getCycle = function (moduleName, startFromImportName, accumulator) {
        if (accumulator === void 0) { accumulator = []; }
        if (!imports.get(moduleName))
            return [];
        if (accumulator.indexOf(moduleName) !== -1)
            return accumulator;
        if (startFromImportName !== undefined && imports.has(startFromImportName)) {
            var c = this.getCycle(startFromImportName, undefined, accumulator.concat(moduleName));
            if (c.length)
                return c;
        }
        else {
            for (var _i = 0, _a = Array.from(imports.get(moduleName).values()); _i < _a.length; _i++) {
                var imp = _a[_i];
                var c = this.getCycle(imp, undefined, accumulator.concat(moduleName));
                if (c.length)
                    return c;
            }
        }
        return [];
    };
    return NoCircularImportsWalker;
}(Lint.RuleWalker));
function isImportFromNPMPackage(filename) {
    return !(filename.startsWith('.') || filename.startsWith('/') || filename.startsWith('~'));
}
var _a;
//# sourceMappingURL=noCircularImportsRule.js.map