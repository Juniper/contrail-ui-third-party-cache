"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const case1 = require("./case1");
case1;
//# sourceMappingURL=case1.1.js.map