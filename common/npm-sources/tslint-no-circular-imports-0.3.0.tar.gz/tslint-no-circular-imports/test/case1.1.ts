import * as case1 from './case1'
case1