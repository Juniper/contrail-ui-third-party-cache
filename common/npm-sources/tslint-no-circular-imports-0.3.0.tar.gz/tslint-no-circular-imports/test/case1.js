"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const case11 = require("./case1.1");
const case12 = require("./case1.2");
case11;
case12;
//# sourceMappingURL=case1.js.map