import * as case11 from './case1.1'
import * as case12 from './case1.2'
case11
case12