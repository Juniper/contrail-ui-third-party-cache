require('./_wks-define')('asyncIterator');
