var $export = require('./_export');

$export($export.S + $export.F, 'Object', { classof: require('./_classof') });
