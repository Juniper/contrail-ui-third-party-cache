# Example configs

This dir contains examples of `.stylelintrc` configuration file for several use cases.

* [Rules for `@if`/`@else` statements](./if-else.md)
