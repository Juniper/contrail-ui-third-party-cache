# Installation
> `npm install --save @types/copy-webpack-plugin`

# Summary
This package contains type definitions for copy-webpack-plugin (https://github.com/kevlened/copy-webpack-plugin).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/copy-webpack-plugin

Additional Details
 * Last updated: Sat, 10 Mar 2018 02:17:46 GMT
 * Dependencies: webpack, minimatch
 * Global values: none

# Credits
These definitions were written by flying-sheep <https://github.com/flying-sheep>.
