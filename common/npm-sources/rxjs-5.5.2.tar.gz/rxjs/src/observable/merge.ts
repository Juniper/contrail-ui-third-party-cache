import {  mergeStatic  } from '../operator/merge';

export const merge = mergeStatic;