import {  IntervalObservable  } from './IntervalObservable';

export const interval = IntervalObservable.create;