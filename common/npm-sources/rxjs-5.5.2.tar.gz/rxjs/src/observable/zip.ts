import {  zipStatic  } from '../operators/zip';

export const zip = zipStatic;
