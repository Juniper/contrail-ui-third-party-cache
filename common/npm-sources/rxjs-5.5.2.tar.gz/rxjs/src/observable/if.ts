import {  IfObservable  } from './IfObservable';

export const _if = IfObservable.create;