import {  UsingObservable  } from './UsingObservable';

export const using = UsingObservable.create;