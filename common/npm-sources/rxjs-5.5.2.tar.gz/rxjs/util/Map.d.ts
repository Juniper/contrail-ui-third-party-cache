export declare const Map: any;
