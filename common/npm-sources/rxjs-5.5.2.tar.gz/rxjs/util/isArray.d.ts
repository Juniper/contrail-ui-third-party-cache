export declare const isArray: (arg: any) => arg is any[];
