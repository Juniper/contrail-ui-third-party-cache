export declare const isArrayLike: <T>(x: any) => x is ArrayLike<T>;
