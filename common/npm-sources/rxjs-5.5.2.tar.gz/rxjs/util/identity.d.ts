export declare function identity<T>(x: T): T;
