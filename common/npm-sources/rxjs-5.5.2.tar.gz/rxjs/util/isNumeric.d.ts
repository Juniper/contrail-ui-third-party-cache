export declare function isNumeric(val: any): val is number;
