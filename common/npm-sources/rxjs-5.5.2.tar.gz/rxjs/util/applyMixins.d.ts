export declare function applyMixins(derivedCtor: any, baseCtors: any[]): void;
