import { Notification } from '../Notification';
export interface TestMessage {
    frame: number;
    notification: Notification<any>;
}
