# Installation
> `npm install --save @types/prop-types`

# Summary
This package contains type definitions for prop-types (https://github.com/reactjs/prop-types).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/prop-types

Additional Details
 * Last updated: Tue, 26 Sep 2017 00:11:47 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by DovydasNavickas <https://github.com/DovydasNavickas>.
