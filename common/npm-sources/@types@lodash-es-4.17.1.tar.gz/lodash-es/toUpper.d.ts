import { toUpper } from "lodash";
export default toUpper;
