import { pullAt } from "lodash";
export default pullAt;
