import { sortedIndexBy } from "lodash";
export default sortedIndexBy;
