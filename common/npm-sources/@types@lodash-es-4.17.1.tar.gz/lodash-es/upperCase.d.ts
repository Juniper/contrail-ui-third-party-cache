import { upperCase } from "lodash";
export default upperCase;
