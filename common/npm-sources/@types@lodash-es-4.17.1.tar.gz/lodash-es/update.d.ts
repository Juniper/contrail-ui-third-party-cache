import { update } from "lodash";
export default update;
