import { partial } from "lodash";
export default partial;
