import { divide } from "lodash";
export default divide;
