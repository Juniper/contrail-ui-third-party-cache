import { entriesIn } from "lodash";
export default entriesIn;
