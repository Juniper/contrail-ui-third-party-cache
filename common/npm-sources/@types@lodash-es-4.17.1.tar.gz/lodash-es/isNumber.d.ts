import { isNumber } from "lodash";
export default isNumber;
