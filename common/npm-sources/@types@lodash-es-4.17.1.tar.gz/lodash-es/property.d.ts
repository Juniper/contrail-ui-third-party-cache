import { property } from "lodash";
export default property;
