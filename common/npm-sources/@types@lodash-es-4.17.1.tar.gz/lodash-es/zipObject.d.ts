import { zipObject } from "lodash";
export default zipObject;
