# Installation
> `npm install --save @types/lodash-es`

# Summary
This package contains type definitions for lodash-es (http://lodash.com/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash-es

Additional Details
 * Last updated: Mon, 23 Jul 2018 23:44:11 GMT
 * Dependencies: lodash
 * Global values: none

# Credits
These definitions were written by Stephen Lautier <https://github.com/stephenlautier>, e-cloud <https://github.com/e-cloud>.
