import { toPath } from "lodash";
export default toPath;
