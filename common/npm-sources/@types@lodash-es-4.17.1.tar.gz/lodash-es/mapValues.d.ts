import { mapValues } from "lodash";
export default mapValues;
