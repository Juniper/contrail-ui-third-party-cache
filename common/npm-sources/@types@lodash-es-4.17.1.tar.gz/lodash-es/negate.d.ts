import { negate } from "lodash";
export default negate;
