import { isNative } from "lodash";
export default isNative;
