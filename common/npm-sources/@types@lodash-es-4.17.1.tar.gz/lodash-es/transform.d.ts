import { transform } from "lodash";
export default transform;
