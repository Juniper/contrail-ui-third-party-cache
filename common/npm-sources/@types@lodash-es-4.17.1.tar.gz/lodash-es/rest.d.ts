import { rest } from "lodash";
export default rest;
