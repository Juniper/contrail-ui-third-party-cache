import { forEachRight } from "lodash";
export default forEachRight;
