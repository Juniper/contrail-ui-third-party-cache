import { truncate } from "lodash";
export default truncate;
