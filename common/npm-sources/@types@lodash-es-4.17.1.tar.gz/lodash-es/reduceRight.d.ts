import { reduceRight } from "lodash";
export default reduceRight;
