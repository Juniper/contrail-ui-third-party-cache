import { upperFirst } from "lodash";
export default upperFirst;
