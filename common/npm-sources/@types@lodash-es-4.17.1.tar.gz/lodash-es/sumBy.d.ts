import { sumBy } from "lodash";
export default sumBy;
