import { partition } from "lodash";
export default partition;
