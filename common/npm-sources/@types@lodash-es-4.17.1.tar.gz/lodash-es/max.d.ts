import { max } from "lodash";
export default max;
