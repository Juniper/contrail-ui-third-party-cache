import { takeRight } from "lodash";
export default takeRight;
