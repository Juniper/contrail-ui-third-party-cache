import { min } from "lodash";
export default min;
