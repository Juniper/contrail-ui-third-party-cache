import { partialRight } from "lodash";
export default partialRight;
