import { stubObject } from "lodash";
export default stubObject;
