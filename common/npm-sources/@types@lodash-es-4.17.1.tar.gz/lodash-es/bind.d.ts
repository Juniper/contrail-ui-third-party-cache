import { bind } from "lodash";
export default bind;
