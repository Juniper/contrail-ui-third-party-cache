import { isBuffer } from "lodash";
export default isBuffer;
