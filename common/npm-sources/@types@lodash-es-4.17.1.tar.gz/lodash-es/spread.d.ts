import { spread } from "lodash";
export default spread;
