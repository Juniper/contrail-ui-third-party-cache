import { startCase } from "lodash";
export default startCase;
