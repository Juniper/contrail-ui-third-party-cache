import { meanBy } from "lodash";
export default meanBy;
