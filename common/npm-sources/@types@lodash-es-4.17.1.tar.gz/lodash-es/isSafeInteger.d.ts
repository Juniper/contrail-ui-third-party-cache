import { isSafeInteger } from "lodash";
export default isSafeInteger;
