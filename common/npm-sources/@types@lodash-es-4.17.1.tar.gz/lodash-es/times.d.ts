import { times } from "lodash";
export default times;
