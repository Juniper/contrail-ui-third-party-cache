import { trimEnd } from "lodash";
export default trimEnd;
