import { isBoolean } from "lodash";
export default isBoolean;
