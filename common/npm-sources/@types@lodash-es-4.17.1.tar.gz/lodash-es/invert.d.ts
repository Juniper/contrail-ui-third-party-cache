import { invert } from "lodash";
export default invert;
