import { padEnd } from "lodash";
export default padEnd;
