import { some } from "lodash";
export default some;
