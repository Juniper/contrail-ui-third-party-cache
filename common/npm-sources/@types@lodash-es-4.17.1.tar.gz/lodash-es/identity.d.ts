import { identity } from "lodash";
export default identity;
