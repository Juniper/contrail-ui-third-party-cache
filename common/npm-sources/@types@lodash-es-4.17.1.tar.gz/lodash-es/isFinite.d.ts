import { isFinite } from "lodash";
export default isFinite;
