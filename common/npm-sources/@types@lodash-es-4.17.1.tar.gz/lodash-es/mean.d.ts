import { mean } from "lodash";
export default mean;
