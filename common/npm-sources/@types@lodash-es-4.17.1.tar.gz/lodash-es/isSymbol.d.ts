import { isSymbol } from "lodash";
export default isSymbol;
