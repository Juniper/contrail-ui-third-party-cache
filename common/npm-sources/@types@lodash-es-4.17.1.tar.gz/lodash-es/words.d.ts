import { words } from "lodash";
export default words;
