import { forIn } from "lodash";
export default forIn;
