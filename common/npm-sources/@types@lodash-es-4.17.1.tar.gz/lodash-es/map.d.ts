import { map } from "lodash";
export default map;
