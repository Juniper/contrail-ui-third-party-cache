import { pull } from "lodash";
export default pull;
