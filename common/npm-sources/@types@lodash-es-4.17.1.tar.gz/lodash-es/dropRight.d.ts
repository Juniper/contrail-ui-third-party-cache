import { dropRight } from "lodash";
export default dropRight;
