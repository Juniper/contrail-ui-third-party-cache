import { floor } from "lodash";
export default floor;
