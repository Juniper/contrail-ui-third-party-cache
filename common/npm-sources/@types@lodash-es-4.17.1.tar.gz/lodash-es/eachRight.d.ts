import { eachRight } from "lodash";
export default eachRight;
