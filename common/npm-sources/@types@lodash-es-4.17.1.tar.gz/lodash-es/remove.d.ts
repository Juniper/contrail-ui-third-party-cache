import { remove } from "lodash";
export default remove;
