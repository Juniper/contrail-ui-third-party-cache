import { lowerFirst } from "lodash";
export default lowerFirst;
