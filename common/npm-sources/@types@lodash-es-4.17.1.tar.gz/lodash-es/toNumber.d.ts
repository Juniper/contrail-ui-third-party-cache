import { toNumber } from "lodash";
export default toNumber;
