import { bindAll } from "lodash";
export default bindAll;
