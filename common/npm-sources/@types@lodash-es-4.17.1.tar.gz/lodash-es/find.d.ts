import { find } from "lodash";
export default find;
