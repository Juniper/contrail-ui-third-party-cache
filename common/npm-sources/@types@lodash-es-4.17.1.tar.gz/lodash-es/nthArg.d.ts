import { nthArg } from "lodash";
export default nthArg;
