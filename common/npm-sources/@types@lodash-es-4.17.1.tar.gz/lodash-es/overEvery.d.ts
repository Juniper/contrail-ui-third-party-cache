import { overEvery } from "lodash";
export default overEvery;
