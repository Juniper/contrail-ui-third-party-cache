import { entries } from "lodash";
export default entries;
