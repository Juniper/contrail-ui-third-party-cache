import { lastIndexOf } from "lodash";
export default lastIndexOf;
