import { debounce } from "lodash";
export default debounce;
