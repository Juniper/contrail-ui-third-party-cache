import { create } from "lodash";
export default create;
