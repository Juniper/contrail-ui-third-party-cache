import { gte } from "lodash";
export default gte;
