import { isInteger } from "lodash";
export default isInteger;
