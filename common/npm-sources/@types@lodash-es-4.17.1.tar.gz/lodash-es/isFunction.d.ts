import { isFunction } from "lodash";
export default isFunction;
