import { hasIn } from "lodash";
export default hasIn;
