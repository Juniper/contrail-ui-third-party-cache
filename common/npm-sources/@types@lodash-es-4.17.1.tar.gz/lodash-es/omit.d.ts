import { omit } from "lodash";
export default omit;
