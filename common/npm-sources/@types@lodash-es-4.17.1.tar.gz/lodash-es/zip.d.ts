import { zip } from "lodash";
export default zip;
