import { cond } from "lodash";
export default cond;
