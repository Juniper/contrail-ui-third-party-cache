import { throttle } from "lodash";
export default throttle;
