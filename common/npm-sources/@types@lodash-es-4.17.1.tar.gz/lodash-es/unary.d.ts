import { unary } from "lodash";
export default unary;
