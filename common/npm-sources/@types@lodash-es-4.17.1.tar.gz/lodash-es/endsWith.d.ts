import { endsWith } from "lodash";
export default endsWith;
