import { parseInt } from "lodash";
export default parseInt;
