import { reduce } from "lodash";
export default reduce;
