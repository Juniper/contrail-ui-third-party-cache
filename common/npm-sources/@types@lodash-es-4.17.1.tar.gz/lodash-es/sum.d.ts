import { sum } from "lodash";
export default sum;
