import { toSafeInteger } from "lodash";
export default toSafeInteger;
