import { get } from "lodash";
export default get;
