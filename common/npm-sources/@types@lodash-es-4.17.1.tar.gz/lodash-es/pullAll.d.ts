import { pullAll } from "lodash";
export default pullAll;
