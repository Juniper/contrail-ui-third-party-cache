import { isMap } from "lodash";
export default isMap;
