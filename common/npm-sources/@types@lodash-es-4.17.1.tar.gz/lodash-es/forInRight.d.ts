import { forInRight } from "lodash";
export default forInRight;
