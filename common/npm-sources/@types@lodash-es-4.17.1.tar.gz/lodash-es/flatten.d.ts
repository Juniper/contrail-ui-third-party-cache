import { flatten } from "lodash";
export default flatten;
