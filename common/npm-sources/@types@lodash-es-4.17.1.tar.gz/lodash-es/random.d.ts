import { random } from "lodash";
export default random;
