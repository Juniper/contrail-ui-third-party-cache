import { trim } from "lodash";
export default trim;
