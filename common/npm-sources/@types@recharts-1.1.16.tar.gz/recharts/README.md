# Installation
> `npm install --save @types/recharts`

# Summary
This package contains type definitions for Recharts ( http://recharts.org/ ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/recharts

Additional Details
 * Last updated: Tue, 26 Mar 2019 17:22:08 GMT
 * Dependencies: @types/react, @types/recharts-scale, @types/d3-shape
 * Global values: none

# Credits
These definitions were written by Raphael Mueller <https://github.com/rapmue>, Roy Xue <https://github.com/royxue>, Zheyang Song <https://github.com/ZheyangSong>, Rich Baird <https://github.com/richbai90>, Dan Torberg <https://github.com/caspeco-dan>, Peter Keuter <https://github.com/pkeuter>, Jamie Saunders <https://github.com/jrsaunde>, Harry Cruse <https://github.com/crusectrl>, Andrew Palugniok <https://github.com/apalugniok>, Robert Stigsson <https://github.com/RobertStigsson>, Kosaku Kurino <https://github.com/kousaku-maron>, Leon Ng <https://github.com/iflp>.
