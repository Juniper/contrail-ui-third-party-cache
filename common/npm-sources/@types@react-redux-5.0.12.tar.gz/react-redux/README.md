# Installation
> `npm install --save @types/react-redux`

# Summary
This package contains type definitions for react-redux (https://github.com/rackt/react-redux).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-redux

Additional Details
 * Last updated: Sat, 28 Oct 2017 00:24:49 GMT
 * Dependencies: react, redux
 * Global values: none

# Credits
These definitions were written by Qubo <https://github.com/tkqubo>, Thomas Hasner <https://github.com/thasner>, Kenzie Togami <https://github.com/kenzierocks>, Curits Layne <https://github.com/clayne11>, Frank Tan <https://github.com/tansongyang>, Nicholas Boll <https://github.com/nicholasboll>, Dibyo Majumdar <https://github.com/mdibyo>, Prashant Deva <https://github.com/pdeva>.
