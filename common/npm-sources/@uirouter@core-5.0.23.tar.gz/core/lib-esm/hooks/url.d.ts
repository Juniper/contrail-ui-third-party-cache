import { TransitionService } from '../transition/transitionService';
export declare const registerUpdateUrl: (transitionService: TransitionService) => Function;
