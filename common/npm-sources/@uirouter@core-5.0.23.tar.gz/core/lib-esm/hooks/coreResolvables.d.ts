/** @internalapi @module hooks */ /** */
import { Transition } from '../transition/transition';
import { TransitionService } from '../transition/transitionService';
export declare const registerAddCoreResolvables: (transitionService: TransitionService) => Function;
export declare const treeChangesCleanup: (trans: Transition) => void;
