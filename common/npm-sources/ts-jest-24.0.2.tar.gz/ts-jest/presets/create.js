module.exports = require('../dist/config/create-jest-preset').createJestPreset
