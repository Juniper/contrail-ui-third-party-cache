module.exports = require('..').jsWithTs
