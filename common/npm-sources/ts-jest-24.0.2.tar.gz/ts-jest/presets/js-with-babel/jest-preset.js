module.exports = require('..').jsWithBabel
