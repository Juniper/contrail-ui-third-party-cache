import { TsJestPresets } from '../dist/config/create-jest-preset'

export const defaults: TsJestPresets
export const jsWithTs: TsJestPresets
export const jsWithBabel: TsJestPresets
