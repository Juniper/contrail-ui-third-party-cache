module.exports = require('..').defaults
