#!/usr/bin/env node

require('./dist/cli').processArgv()
