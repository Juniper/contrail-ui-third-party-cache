module.exports = require('./presets/default/jest-preset')
