# Installation
> `npm install --save @types/react-router`

# Summary
This package contains type definitions for React Router (https://github.com/ReactTraining/react-router).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-router

Additional Details
 * Last updated: Thu, 09 Nov 2017 09:57:16 GMT
 * Dependencies: react, history
 * Global values: none

# Credits
These definitions were written by Sergey Buturlakin <https://github.com/sergey-buturlakin>, Yuichi Murata <https://github.com/mrk21>, Václav Ostrožlík <https://github.com/vasek17>, Nathan Brown <https://github.com/ngbrown>, Alex Wendland <https://github.com/awendland>, Kostya Esmukov <https://github.com/KostyaEsmukov>, John Reilly <https://github.com/johnnyreilly>, Karol Janyst <https://github.com/LKay>, Dovydas Navickas <https://github.com/DovydasNavickas>, Tanguy Krotoff <https://github.com/tkrotoff>, Huy Nguyen <https://github.com/huy-nguyen>, Jérémy Fauvel <https://github.com/grmiade>, Daniel Roth <https://github.com/DaIgeb>, Egor Shulga <https://github.com/egorshulga>.
