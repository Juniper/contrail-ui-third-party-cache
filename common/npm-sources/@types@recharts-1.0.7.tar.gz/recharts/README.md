# Installation
> `npm install --save @types/recharts`

# Summary
This package contains type definitions for Recharts (http://recharts.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/recharts

Additional Details
 * Last updated: Thu, 30 Nov 2017 21:46:01 GMT
 * Dependencies: react, d3-shape
 * Global values: none

# Credits
These definitions were written by Maarten Mulders <https://github.com/mthmulders>, Raphael Mueller <https://github.com/rapmue>, Roy Xue <https://github.com/royxue>, Zheyang Song <https://github.com/ZheyangSong>.
