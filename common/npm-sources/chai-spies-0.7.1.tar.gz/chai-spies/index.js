module.exports = require('./lib/spy');
