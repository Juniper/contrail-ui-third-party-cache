"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var buffer_1 = require("../../operator/buffer");
rxjs_1.Observable.prototype.buffer = buffer_1.buffer;
//# sourceMappingURL=buffer.js.map