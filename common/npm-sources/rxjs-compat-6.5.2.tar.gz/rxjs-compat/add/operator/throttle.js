"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var throttle_1 = require("../../operator/throttle");
rxjs_1.Observable.prototype.throttle = throttle_1.throttle;
//# sourceMappingURL=throttle.js.map