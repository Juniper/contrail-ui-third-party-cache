"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var debounce_1 = require("../../operator/debounce");
rxjs_1.Observable.prototype.debounce = debounce_1.debounce;
//# sourceMappingURL=debounce.js.map