"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var skip_1 = require("../../operator/skip");
rxjs_1.Observable.prototype.skip = skip_1.skip;
//# sourceMappingURL=skip.js.map