"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var concat_1 = require("../../operator/concat");
rxjs_1.Observable.prototype.concat = concat_1.concat;
//# sourceMappingURL=concat.js.map