"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var max_1 = require("../../operator/max");
rxjs_1.Observable.prototype.max = max_1.max;
//# sourceMappingURL=max.js.map