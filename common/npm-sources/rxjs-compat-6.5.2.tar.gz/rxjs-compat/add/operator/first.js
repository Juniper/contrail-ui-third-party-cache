"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var first_1 = require("../../operator/first");
rxjs_1.Observable.prototype.first = first_1.first;
//# sourceMappingURL=first.js.map