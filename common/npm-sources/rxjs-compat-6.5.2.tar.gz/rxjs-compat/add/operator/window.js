"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var window_1 = require("../../operator/window");
rxjs_1.Observable.prototype.window = window_1.window;
//# sourceMappingURL=window.js.map