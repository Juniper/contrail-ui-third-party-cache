"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var retry_1 = require("../../operator/retry");
rxjs_1.Observable.prototype.retry = retry_1.retry;
//# sourceMappingURL=retry.js.map