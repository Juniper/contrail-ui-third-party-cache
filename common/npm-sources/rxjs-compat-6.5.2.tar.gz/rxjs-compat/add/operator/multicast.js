"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var multicast_1 = require("../../operator/multicast");
rxjs_1.Observable.prototype.multicast = multicast_1.multicast;
//# sourceMappingURL=multicast.js.map