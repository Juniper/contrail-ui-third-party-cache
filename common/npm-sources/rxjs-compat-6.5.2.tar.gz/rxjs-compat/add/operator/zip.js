"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var zip_1 = require("../../operator/zip");
rxjs_1.Observable.prototype.zip = zip_1.zipProto;
//# sourceMappingURL=zip.js.map