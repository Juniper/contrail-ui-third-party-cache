"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var materialize_1 = require("../../operator/materialize");
rxjs_1.Observable.prototype.materialize = materialize_1.materialize;
//# sourceMappingURL=materialize.js.map