"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var distinct_1 = require("../../operator/distinct");
rxjs_1.Observable.prototype.distinct = distinct_1.distinct;
//# sourceMappingURL=distinct.js.map