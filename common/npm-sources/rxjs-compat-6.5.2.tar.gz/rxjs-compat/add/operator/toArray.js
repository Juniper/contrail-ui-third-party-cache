"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var toArray_1 = require("../../operator/toArray");
rxjs_1.Observable.prototype.toArray = toArray_1.toArray;
//# sourceMappingURL=toArray.js.map