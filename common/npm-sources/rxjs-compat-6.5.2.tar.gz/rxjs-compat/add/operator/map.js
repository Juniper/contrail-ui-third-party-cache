"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var map_1 = require("../../operator/map");
rxjs_1.Observable.prototype.map = map_1.map;
//# sourceMappingURL=map.js.map