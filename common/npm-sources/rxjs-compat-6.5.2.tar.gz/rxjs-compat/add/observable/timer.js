"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.timer = rxjs_1.timer;
//# sourceMappingURL=timer.js.map