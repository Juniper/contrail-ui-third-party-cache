"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.pairs = rxjs_1.pairs;
//# sourceMappingURL=pairs.js.map