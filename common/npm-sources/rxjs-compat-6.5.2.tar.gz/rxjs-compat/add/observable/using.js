"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.using = rxjs_1.using;
//# sourceMappingURL=using.js.map