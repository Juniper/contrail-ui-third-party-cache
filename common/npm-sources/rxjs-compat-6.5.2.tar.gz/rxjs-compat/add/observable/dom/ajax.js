"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var ajax_1 = require("rxjs/ajax");
rxjs_1.Observable.ajax = ajax_1.ajax;
//# sourceMappingURL=ajax.js.map