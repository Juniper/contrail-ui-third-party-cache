"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.concat = rxjs_1.concat;
//# sourceMappingURL=concat.js.map