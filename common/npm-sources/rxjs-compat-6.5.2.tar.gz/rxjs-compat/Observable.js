"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.Observable = rxjs_1.Observable;
//# sourceMappingURL=Observable.js.map