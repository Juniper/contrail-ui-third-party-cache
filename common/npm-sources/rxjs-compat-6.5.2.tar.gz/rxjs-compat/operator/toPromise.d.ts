import { Observable } from 'rxjs';
export declare const toPromise: typeof Observable.prototype.toPromise;
