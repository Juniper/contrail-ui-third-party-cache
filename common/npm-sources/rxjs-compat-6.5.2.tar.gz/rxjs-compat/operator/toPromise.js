"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
// HACK: this is here for backward compatability
// TODO(benlesh): remove this in v6.
exports.toPromise = rxjs_1.Observable.prototype.toPromise;
//# sourceMappingURL=toPromise.js.map