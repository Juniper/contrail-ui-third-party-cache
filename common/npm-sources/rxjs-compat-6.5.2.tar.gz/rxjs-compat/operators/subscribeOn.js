"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var operators_1 = require("rxjs/operators");
exports.subscribeOn = operators_1.subscribeOn;
//# sourceMappingURL=subscribeOn.js.map