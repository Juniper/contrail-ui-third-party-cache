# Installation
> `npm install --save @types/react-router-config`

# Summary
This package contains type definitions for react-router-config (https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-router-config

Additional Details
 * Last updated: Tue, 26 Sep 2017 00:18:08 GMT
 * Dependencies: react, react-router, history
 * Global values: none

# Credits
These definitions were written by François Nguyen <https://github.com/lith-light-g>.
