/*

  This test is here to confirm that assetNameRegExp option will apply
  only to the names of the files exported byt ExtractTextPlugin

*/

require('./a_optimize-me.css');
require('./b_optimize-me.css');
require('./c.css');
