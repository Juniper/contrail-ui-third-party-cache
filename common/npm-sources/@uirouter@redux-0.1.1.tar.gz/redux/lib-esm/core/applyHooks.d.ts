/**
  * @module core
  */ /** */
import { UIRouter } from '@uirouter/core';
import { Store } from 'redux';
/**
 * Applies hooks to Transitions
 *
 * Registers hooks for every Transition and dispatches Redux events to sync it.
 *
 * @param router The Router instance
 * @param store The Redux store
 * @returns A function for removing the event listeners
 */
export declare function applyHooks(router: UIRouter, store: Store<any>): Function;
