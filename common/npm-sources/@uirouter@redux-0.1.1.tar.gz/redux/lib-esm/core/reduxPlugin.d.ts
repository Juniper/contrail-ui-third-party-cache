import { UIRouter } from '@uirouter/core';
import { Store } from 'redux';
import { ReduxPlugin } from './interface';
export declare function reduxPluginFactory(name: string, store: Store<any>): (router: UIRouter) => ReduxPlugin;
export declare const createReduxPlugin: (store: Store<any>) => (router: UIRouter) => ReduxPlugin;
