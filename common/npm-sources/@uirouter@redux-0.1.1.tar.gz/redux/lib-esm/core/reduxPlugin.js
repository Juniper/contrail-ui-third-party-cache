import { applyHooks } from './applyHooks';
export function reduxPluginFactory(name, store) {
    return function (router) {
        // sync should return function to deregister hooks
        var removeHooks = applyHooks(router, store);
        function dispose(router) {
            removeHooks();
        }
        return { name: name, store: store, dispose: dispose };
    };
}
export var createReduxPlugin = function (store) {
    return reduxPluginFactory('redux', store);
};
//# sourceMappingURL=reduxPlugin.js.map