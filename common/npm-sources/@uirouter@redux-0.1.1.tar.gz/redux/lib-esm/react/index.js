export * from './ConnectedUIRouter';
//# sourceMappingURL=index.js.map