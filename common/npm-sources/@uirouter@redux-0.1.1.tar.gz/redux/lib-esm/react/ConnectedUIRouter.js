var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { servicesPlugin, UIRouter } from '@uirouter/react';
import * as PropTypes from 'prop-types';
import * as React from 'react';
import { createReduxPlugin } from '../core';
var ConnectedUIRouter = /** @class */ (function (_super) {
    __extends(ConnectedUIRouter, _super);
    function ConnectedUIRouter(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.reduxPlugin = createReduxPlugin(context.store);
        _this.router = props.router;
        _this.router.plugin(servicesPlugin);
        props.plugins.forEach(function (plugin) { return _this.router.plugin(plugin); });
        _this.router.plugin(_this.reduxPlugin);
        if (props.config)
            props.config(_this.router);
        (props.states || []).forEach(function (state) {
            return _this.router.stateRegistry.register(state);
        });
        return _this;
    }
    ConnectedUIRouter.prototype.render = function () {
        var children = this.props.children;
        return React.createElement(UIRouter, { router: this.router }, children);
    };
    ConnectedUIRouter.contextTypes = {
        store: PropTypes.object,
    };
    return ConnectedUIRouter;
}(React.Component));
export { ConnectedUIRouter };
//# sourceMappingURL=ConnectedUIRouter.js.map