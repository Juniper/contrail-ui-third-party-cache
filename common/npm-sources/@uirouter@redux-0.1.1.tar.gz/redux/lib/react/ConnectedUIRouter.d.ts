/// <reference types="react" />
import { UIRouterProps } from '@uirouter/react';
import * as React from 'react';
export declare class ConnectedUIRouter extends React.Component<UIRouterProps, any> {
    reduxPlugin: any;
    router: any;
    static contextTypes: {
        store: any;
    };
    constructor(props: any, context: any);
    render(): JSX.Element;
}
