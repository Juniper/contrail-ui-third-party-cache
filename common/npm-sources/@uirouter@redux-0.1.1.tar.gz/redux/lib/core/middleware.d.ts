import { UIRouter } from '@uirouter/core';
export default function createRouterMiddleware(router: UIRouter): () => (next: any) => (action: any) => any;
