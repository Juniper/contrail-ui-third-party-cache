export declare const TRIGGER_TRANSITION = "@ui-router/TRIGGER_TRANSITION";
export declare const START_TRANSITION = "@ui-router/START_TRANSITION";
export declare const IGNORED_TRANSITION = "@ui-router/IGNORED_TRANSITION";
export declare const REDIRECTED_TRANSITION = "@ui-router/REDIRECTED_TRANSITION";
export declare const FINISH_TRANSITION = "@ui-router/FINISH_TRANSITION";
export declare const triggerTransition: (to: any, params: any) => {
    type: string;
    to: any;
    params: any;
};
