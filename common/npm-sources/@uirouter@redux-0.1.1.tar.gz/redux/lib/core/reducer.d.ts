export declare const routerReducer: (state: {
    transitioning: boolean;
    last: {};
}, action: any) => {
    transitioning: boolean;
    last: any;
};
