# Installation
> `npm install --save @types/recharts`

# Summary
This package contains type definitions for Recharts (http://recharts.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/recharts

Additional Details
 * Last updated: Mon, 18 Jun 2018 22:47:06 GMT
 * Dependencies: react, d3-shape
 * Global values: none

# Credits
These definitions were written by Maarten Mulders <https://github.com/mthmulders>, Raphael Mueller <https://github.com/rapmue>, Roy Xue <https://github.com/royxue>, Zheyang Song <https://github.com/ZheyangSong>, Rich Baird <https://github.com/richbai90>, Dan Torberg <https://github.com/caspeco-dan>, Peter Keuter <https://github.com/pkeuter>, Jamie Saunders <https://github.com/jrsaunde>.
