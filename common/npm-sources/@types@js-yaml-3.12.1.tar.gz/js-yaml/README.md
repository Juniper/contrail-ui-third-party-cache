# Installation
> `npm install --save @types/js-yaml`

# Summary
This package contains type definitions for js-yaml ( https://github.com/nodeca/js-yaml ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/js-yaml

Additional Details
 * Last updated: Tue, 02 Apr 2019 23:17:33 GMT
 * Dependencies: none
 * Global values: jsyaml

# Credits
These definitions were written by Bart van der Schoor <https://github.com/Bartvds>, Sebastian Clausen <https://github.com/sclausen>.
