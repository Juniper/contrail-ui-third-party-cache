const { start } = require('./viewer');

module.exports = {
  start,
  BundleAnalyzerPlugin: require('./BundleAnalyzerPlugin')
};
