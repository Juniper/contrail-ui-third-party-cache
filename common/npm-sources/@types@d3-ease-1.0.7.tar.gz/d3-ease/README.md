# Installation
> `npm install --save @types/d3-ease`

# Summary
This package contains type definitions for D3JS d3-ease module (https://github.com/d3/d3-ease/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-ease

Additional Details
 * Last updated: Thu, 04 May 2017 22:35:19 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Tom Wanzek <https://github.com/tomwanzek>, Alex Ford <https://github.com/gustavderdrache>, Boris Yankov <https://github.com/borisyankov>.
