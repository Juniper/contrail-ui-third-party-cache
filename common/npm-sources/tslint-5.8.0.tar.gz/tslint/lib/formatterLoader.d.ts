import { FormatterConstructor } from "./index";
export declare function findFormatter(name: string | FormatterConstructor, formattersDirectory?: string): FormatterConstructor | undefined;
