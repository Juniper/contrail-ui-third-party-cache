/**
 * @reactapi
 * @module components
 */ /** */
import * as React from 'react';
import { Component } from 'react';
import * as PropTypes from 'prop-types';
import { UIRouterReact, ReactStateDeclaration } from '../index';
export declare const UIRouterProvider: React.ProviderExoticComponent<React.ProviderProps<UIRouterReact>>, UIRouterConsumer: React.ExoticComponent<React.ConsumerProps<UIRouterReact>>;
export interface UIRouterProps {
    plugins?: any[];
    states?: ReactStateDeclaration[];
    config?: (router: UIRouterReact) => void;
    router?: UIRouterReact;
}
export interface UIRouterState {
    id?: number;
    loaded?: boolean;
    component?: string;
    props?: any;
}
/** @hidden */
export declare const InstanceOrPluginsMissingError: Error;
/** @hidden */
export declare const UIRouterInstanceUndefinedError: Error;
export declare class UIRouter extends Component<UIRouterProps, UIRouterState> {
    static propTypes: {
        plugins: PropTypes.Requireable<((...args: any[]) => any)[]>;
        states: PropTypes.Requireable<object[]>;
        config: PropTypes.Requireable<(...args: any[]) => any>;
        children: PropTypes.Validator<PropTypes.ReactElementLike>;
        router: PropTypes.Requireable<object>;
    };
    router: UIRouterReact;
    constructor(props: any, context: any);
    render(): JSX.Element;
}
