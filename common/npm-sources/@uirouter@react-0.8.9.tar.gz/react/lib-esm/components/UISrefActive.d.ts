/**
 * @reactapi
 * @module components
 */ /** */
import * as React from 'react';
import { UIRouterReact } from '../index';
import { UIViewAddress } from './UIView';
export interface UISrefActiveProps {
    parentUIView: UIViewAddress;
    addStateInfoToParentActive: Function;
    router: UIRouterReact;
    class?: string;
    exact?: Boolean;
    children?: any;
    className?: string;
}
export interface UISrefActiveState {
    state: {
        name?: string;
        [key: string]: any;
    };
    params: Object;
    hash: string;
}
export declare const StateNameMustBeAStringError: Error;
/** @internalapi */
export declare const UISrefActiveProvider: React.ProviderExoticComponent<React.ProviderProps<Function>>, UISrefActiveConsumer: React.ExoticComponent<React.ConsumerProps<Function>>;
export declare const UISrefActive: (props: any) => JSX.Element;
