/**
 * @reactapi
 * @module components
 */ /** */
import * as React from 'react';
import { ClassType, ClassicComponentClass, ComponentClass, SFC, StatelessComponent } from 'react';
import { ViewContext, Transition, StateParams } from '@uirouter/core';
import { UIRouterReact } from '../index';
/** @internalapi */
export interface UIViewAddress {
    context: ViewContext;
    fqn: string;
}
/**
 * Interface for [[InjectedProps.resolves]]
 *
 * This Typescript interface shows what fields are available on the `resolves` field.
 */
export interface UIViewResolves {
    /**
     * Any key/value pair defined by a state's resolve
     *
     * If a state defines any [[ReactStateDeclaration.resolve]]s, they will be found on this object.
     */
    [key: string]: any;
    /**
     * The `StateParams` for the `Transition` that activated the component
     *
     * This is an alias for:
     * ```js
     * let $stateParams = $transition$.params("to");
     * ```
     */
    $stateParams: StateParams;
    /** The `Transition` that activated the component */
    $transition$: Transition;
}
/**
 * Function type for [[UIViewProps.render]]
 *
 * If the `render` function prop is provided, the `UIView` will use it instead of rendering the component by itself.
 * @internalapi
 */
export declare type RenderPropCallback = (Component: StatelessComponent<any> | ComponentClass<any> | ClassicComponentClass<any>, Props: any) => JSX.Element | null;
export interface UIViewInjectedProps {
    transition?: Transition;
    resolves?: UIViewResolves;
    className?: string;
    style?: Object;
}
/** Component Props for `UIView` */
export interface UIViewProps {
    router?: UIRouterReact;
    parentUIView?: UIViewAddress;
    name?: string;
    className?: string;
    style?: Object;
    render?: RenderPropCallback;
}
/** Component State for `UIView` */
export interface UIViewState {
    id?: number;
    loaded?: boolean;
    component?: string | SFC<any> | ClassType<any, any, any> | ComponentClass<any>;
    props?: any;
}
export declare const TransitionPropCollisionError: Error;
/** @internalapi */
export declare const UIViewProvider: React.ProviderExoticComponent<React.ProviderProps<UIViewAddress>>, UIViewConsumer: React.ExoticComponent<React.ConsumerProps<UIViewAddress>>;
export declare class UIView extends React.Component<UIViewProps, any> {
    static displayName: string;
    static __internalViewComponent: React.ComponentClass<UIViewProps>;
    render(): JSX.Element;
}
