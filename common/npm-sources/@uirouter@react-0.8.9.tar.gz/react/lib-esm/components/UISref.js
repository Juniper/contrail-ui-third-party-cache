var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/**
 * @reactapi
 * @module components
 */ /** */
import * as React from 'react';
import { Component, cloneElement } from 'react';
import * as PropTypes from 'prop-types';
import * as _classNames from 'classnames';
import { extend, isFunction } from '@uirouter/core';
import { UIRouterConsumer } from '../index';
import { UIViewConsumer } from './UIView';
import { UIRouterInstanceUndefinedError } from './UIRouter';
import { UISrefActiveConsumer } from './UISrefActive';
var classNames = _classNames;
var Sref = /** @class */ (function (_super) {
    __extends(Sref, _super);
    function Sref() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.getOptions = function () {
            var parent = _this.props.parentUIView;
            var parentContext = (parent && parent.context) || _this.props.router.stateRegistry.root();
            var defOpts = { relative: parentContext, inherit: true };
            return extend(defOpts, _this.props.options || {});
        };
        _this.handleClick = function (e) {
            var childOnClick = _this.props.children.props.onClick;
            if (isFunction(childOnClick)) {
                childOnClick(e);
            }
            if (!e.defaultPrevented && !(e.button == 1 || e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                var params = _this.props.params || {};
                var to = _this.props.to;
                var options = _this.getOptions();
                _this.props.router.stateService.go(to, params, options);
            }
        };
        return _this;
    }
    Sref.prototype.componentWillMount = function () {
        var addStateInfo = this.props.addStateInfoToParentActive;
        this.deregister = typeof addStateInfo === 'function' ? addStateInfo(this.props.to, this.props.params) : function () { };
        var router = this.props.router;
        if (typeof router === 'undefined') {
            throw UIRouterInstanceUndefinedError;
        }
    };
    Sref.prototype.componentWillUnmount = function () {
        this.deregister();
    };
    Sref.prototype.render = function () {
        var params = this.props.params || {}, to = this.props.to, options = this.getOptions();
        var childrenProps = this.props.children.props;
        var props = Object.assign({}, childrenProps, {
            onClick: this.handleClick,
            href: this.props.router.stateService.href(to, params, options),
            className: classNames(this.props.className, childrenProps.className),
        });
        return cloneElement(this.props.children, props);
    };
    Sref.propTypes = {
        router: PropTypes.object.isRequired,
        parentUIView: PropTypes.object,
        addStateInfoToParentActive: PropTypes.func,
        children: PropTypes.element.isRequired,
        to: PropTypes.string.isRequired,
        params: PropTypes.object,
        options: PropTypes.object,
        className: PropTypes.string,
    };
    return Sref;
}(Component));
export var UISref = function (props) { return (React.createElement(UIRouterConsumer, null, function (router) { return (React.createElement(UIViewConsumer, null, function (parentUIView) { return (React.createElement(UISrefActiveConsumer, null, function (addStateInfo) { return (React.createElement(Sref, __assign({}, props, { router: router, parentUIView: parentUIView, addStateInfoToParentActive: addStateInfo }))); })); })); })); };
UISref.displayName = 'UISref';
//# sourceMappingURL=UISref.js.map