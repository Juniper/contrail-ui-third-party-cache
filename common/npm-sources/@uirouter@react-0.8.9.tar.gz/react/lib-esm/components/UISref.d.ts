/// <reference types="react" />
import { TransitionOptions } from '@uirouter/core';
import { UIRouterReact } from '../index';
import { UIViewAddress } from './UIView';
export interface UISrefProps {
    router: UIRouterReact;
    addStateInfoToParentActive: Function;
    parentUIView: UIViewAddress;
    children?: any;
    to: string;
    params?: {
        [key: string]: any;
    };
    options?: TransitionOptions;
    className?: string;
}
export declare const UISref: (props: any) => JSX.Element;
