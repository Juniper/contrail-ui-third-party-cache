var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a;
/**
 * @reactapi
 * @module components
 */ /** */
import * as React from 'react';
import { Component, cloneElement } from 'react';
import * as PropTypes from 'prop-types';
import * as _classNames from 'classnames';
import { UIRouterConsumer } from '../index';
import { UIRouterInstanceUndefinedError } from './UIRouter';
import { UIViewConsumer } from './UIView';
var classNames = _classNames;
export var StateNameMustBeAStringError = new Error('State name provided to <UISref {to}> must be a string.');
/** @internalapi */
export var UISrefActiveProvider = (_a = React.createContext(undefined), _a.Provider), UISrefActiveConsumer = _a.Consumer;
var SrefActive = /** @class */ (function (_super) {
    __extends(SrefActive, _super);
    function SrefActive() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // keep track of states to watch and their activeClasses
        _this.states = [];
        _this.activeClasses = {};
        _this.state = {
            activeClasses: '',
        };
        _this.addStateInfo = function (stateName, stateParams) {
            var activeClass = _this.props.class;
            var deregister = _this.addState(stateName, stateParams, activeClass);
            var addStateInfo = _this.props.addStateInfoToParentActive;
            _this.updateActiveClasses();
            if (typeof addStateInfo === 'function') {
                var parentDeregister_1 = addStateInfo(stateName, stateParams);
                return function () {
                    deregister();
                    parentDeregister_1();
                };
            }
            return deregister;
        };
        _this.addState = function (stateName, stateParams, activeClass) {
            var stateService = _this.props.router.stateService;
            var parent = _this.props.parentUIView;
            var stateContext = (parent && parent.context) || _this.props.router.stateRegistry.root();
            var state = stateService.get(stateName, stateContext);
            var stateHash = _this.createStateHash(stateName, stateParams);
            var stateInfo = {
                state: state || { name: stateName },
                params: stateParams,
                hash: stateHash,
            };
            _this.states.push(stateInfo);
            _this.activeClasses[stateHash] = activeClass;
            return function () {
                var idx = _this.states.indexOf(stateInfo);
                if (idx !== -1)
                    _this.states.splice(idx, 1);
            };
        };
        _this.createStateHash = function (state, params) {
            if (typeof state !== 'string') {
                throw StateNameMustBeAStringError;
            }
            return params && typeof params === 'object' ? state + JSON.stringify(params) : state;
        };
        _this.getActiveClasses = function () {
            var activeClasses = [];
            var stateService = _this.props.router.stateService;
            var exact = _this.props.exact;
            _this.states.forEach(function (s) {
                var state = s.state, params = s.params, hash = s.hash;
                if (!exact && stateService.includes(state.name, params))
                    activeClasses.push(_this.activeClasses[hash]);
                if (exact && stateService.is(state.name, params))
                    activeClasses.push(_this.activeClasses[hash]);
            });
            return classNames(activeClasses);
        };
        _this.updateActiveClasses = function () {
            var activeClasses = _this.state.activeClasses;
            var newActiveClasses = _this.getActiveClasses();
            if (activeClasses !== newActiveClasses) {
                _this.setState({
                    activeClasses: _this.getActiveClasses(),
                });
            }
        };
        return _this;
    }
    SrefActive.prototype.componentWillMount = function () {
        var _this = this;
        var router = this.props.router;
        if (typeof router === 'undefined') {
            throw UIRouterInstanceUndefinedError;
        }
        // register callback for state change
        this.deregister = router.transitionService.onSuccess({}, function () { return _this.updateActiveClasses(); });
    };
    SrefActive.prototype.componentWillUnmount = function () {
        this.deregister();
    };
    SrefActive.prototype.render = function () {
        var activeClasses = this.state.activeClasses;
        var className = this.props.className;
        var children = activeClasses.length > 0
            ? cloneElement(this.props.children, Object.assign({}, this.props.children.props, {
                className: classNames(className, this.props.children.props.className, activeClasses),
            }))
            : this.props.children;
        return React.createElement(UISrefActiveProvider, { value: this.addStateInfo }, children);
    };
    SrefActive.propTypes = {
        parentUIView: PropTypes.object,
        addStateInfoToParentActive: PropTypes.func,
        router: PropTypes.object.isRequired,
        class: PropTypes.string.isRequired,
        children: PropTypes.element.isRequired,
        className: PropTypes.string,
    };
    return SrefActive;
}(Component));
export var UISrefActive = function (props) { return (React.createElement(UIRouterConsumer, null, function (router) { return (React.createElement(UIViewConsumer, null, function (parentUIView) { return (React.createElement(UISrefActiveConsumer, null, function (addStateInfo) { return (React.createElement(SrefActive, __assign({}, props, { router: router, parentUIView: parentUIView, addStateInfoToParentActive: addStateInfo }))); })); })); })); };
UISrefActive.displayName = 'UISrefActive';
//# sourceMappingURL=UISrefActive.js.map