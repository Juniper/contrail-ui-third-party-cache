# Installation
> `npm install --save @types/uglifyjs-webpack-plugin`

# Summary
This package contains type definitions for uglifyjs-webpack-plugin (https://github.com/webpack-contrib/uglifyjs-webpack-plugin).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/uglifyjs-webpack-plugin

Additional Details
 * Last updated: Thu, 22 Mar 2018 21:28:50 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by Rene Vajkay <https://github.com/vajkayrene>.
