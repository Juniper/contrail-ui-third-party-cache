# Installation
> `npm install --save @types/d3-chord`

# Summary
This package contains type definitions for D3JS d3-chord module (https://github.com/d3/d3-chord/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped.git/tree/master/types/d3-chord

Additional Details
 * Last updated: Wed, 23 May 2018 23:09:39 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Tom Wanzek <https://github.com/tomwanzek>, Alex Ford <https://github.com/gustavderdrache>, Boris Yankov <https://github.com/borisyankov>.
