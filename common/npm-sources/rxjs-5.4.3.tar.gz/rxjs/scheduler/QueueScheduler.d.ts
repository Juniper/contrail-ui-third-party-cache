import { AsyncScheduler } from './AsyncScheduler';
export declare class QueueScheduler extends AsyncScheduler {
}
