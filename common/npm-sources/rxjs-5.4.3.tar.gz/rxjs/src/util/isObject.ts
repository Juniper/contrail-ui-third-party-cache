export function isObject(x: any): x is Object {
  return x != null && typeof x === 'object';
}
