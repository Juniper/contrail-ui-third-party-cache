import {  RangeObservable  } from './RangeObservable';

export const range = RangeObservable.create;