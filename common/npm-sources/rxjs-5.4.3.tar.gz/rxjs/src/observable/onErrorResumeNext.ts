import { onErrorResumeNextStatic } from '../operator/onErrorResumeNext';

export const onErrorResumeNext = onErrorResumeNextStatic;
