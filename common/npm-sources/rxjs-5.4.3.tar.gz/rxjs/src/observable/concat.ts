import {  concatStatic  } from '../operator/concat';

export const concat = concatStatic;