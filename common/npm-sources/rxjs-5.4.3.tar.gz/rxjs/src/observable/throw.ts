import {  ErrorObservable  } from './ErrorObservable';

export const _throw = ErrorObservable.create;