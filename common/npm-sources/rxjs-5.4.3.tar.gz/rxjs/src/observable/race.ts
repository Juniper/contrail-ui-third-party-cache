import { raceStatic } from '../operator/race';

export const race = raceStatic;
