import {  BoundNodeCallbackObservable  } from './BoundNodeCallbackObservable';

export const bindNodeCallback = BoundNodeCallbackObservable.create;