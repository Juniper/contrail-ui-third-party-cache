import {  zipStatic  } from '../operator/zip';

export const zip = zipStatic;