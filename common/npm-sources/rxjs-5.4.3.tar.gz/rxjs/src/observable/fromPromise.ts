import {  PromiseObservable  } from './PromiseObservable';

export const fromPromise = PromiseObservable.create;