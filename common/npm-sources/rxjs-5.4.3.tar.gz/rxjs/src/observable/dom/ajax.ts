import {  AjaxObservable, AjaxCreationMethod  } from './AjaxObservable';

export const ajax: AjaxCreationMethod = AjaxObservable.create;