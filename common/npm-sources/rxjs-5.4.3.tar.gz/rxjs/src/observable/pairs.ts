import {  PairsObservable  } from './PairsObservable';

export const pairs = PairsObservable.create;