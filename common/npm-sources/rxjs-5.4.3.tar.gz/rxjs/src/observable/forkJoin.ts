import {  ForkJoinObservable  } from './ForkJoinObservable';

export const forkJoin = ForkJoinObservable.create;