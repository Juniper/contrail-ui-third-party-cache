export declare const rxSubscriber: any;
/**
 * @deprecated use rxSubscriber instead
 */
export declare const $$rxSubscriber: any;
