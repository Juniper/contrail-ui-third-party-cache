export declare function isFunction(x: any): x is Function;
