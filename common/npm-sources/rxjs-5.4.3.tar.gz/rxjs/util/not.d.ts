export declare function not(pred: Function, thisArg: any): Function;
