export declare function isPromise<T>(value: any | Promise<T>): value is Promise<T>;
