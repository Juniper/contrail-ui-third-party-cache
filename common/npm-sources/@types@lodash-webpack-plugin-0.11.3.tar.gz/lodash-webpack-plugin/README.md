# Installation
> `npm install --save @types/lodash-webpack-plugin`

# Summary
This package contains type definitions for lodash-webpack-plugin (https://github.com/lodash/lodash-webpack-plugin#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash-webpack-plugin

Additional Details
 * Last updated: Sat, 10 Mar 2018 02:17:46 GMT
 * Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by Benjamin Lim <https://github.com/bumbleblym>.
