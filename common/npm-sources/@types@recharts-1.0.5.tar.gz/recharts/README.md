# Installation
> `npm install --save @types/recharts`

# Summary
This package contains type definitions for Recharts (http://recharts.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/recharts

Additional Details
 * Last updated: Thu, 09 Nov 2017 09:57:17 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Maarten Mulders <https://github.com/mthmulders>, Raphael Mueller <https://github.com/rapmue>, Roy Xue <https://github.com/royxue>.
